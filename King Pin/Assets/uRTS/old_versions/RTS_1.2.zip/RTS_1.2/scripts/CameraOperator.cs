﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CameraOperator : MonoBehaviour {

	public Texture2D selectionHighlight = null;
	public static Rect selection = new Rect(0,0,0,0);
	private Vector3 startClick = -Vector3.one;
	
	static private Vector3 destinationClick = -Vector3.one;
	
	private static Vector3 moveToDestination = Vector3.zero;
	private static List<string> passables = new List<string>() { "Terrain" };
	
	private bool isSelectByClickRunning = false;
	
	
	
	private GameObject tGo = null;
	
	static private BattleSystem bs;
	static private Diplomacy dip;

	
	// Update is called once per frame
	void Start() {
		bs = GameObject.Find("Terrain").GetComponent<BattleSystem>();
		dip = GameObject.Find("Terrain").GetComponent<Diplomacy>();
	}
	
	
	void Update () {
		CheckCamera();

	}
	
	private void CheckCamera()
	{
	
		if(Input.GetMouseButtonDown(0))
		{
			startClick = Input.mousePosition;
			if(isSelectByClickRunning==true){
				
			}
			else{
				StartCoroutine(SelectByClick(startClick,0));
			}
		//	SelectByClick(startClick);
		}
			
		else if(Input.GetMouseButtonUp(0))
		{
			if(selection.width != 0){
				if(selection.height != 0){
					SelectByRect();
				}
			}
			startClick = -Vector3.one;
			selection = new Rect(0,0,0,0);
		}
		
		if(Input.GetMouseButton(0))
			selection = new Rect(startClick.x,InvertMouseY(startClick.y), Input.mousePosition.x - startClick.x, InvertMouseY(Input.mousePosition.y) - InvertMouseY(startClick.y));
			
			if(selection.width < 0)
			{
				selection.x += selection.width;
				selection.width = -selection.width;
			}
			if(selection.height < 0)
			{
				selection.y += selection.height;
				selection.height = -selection.height;
			}
			
			
		if(Input.GetMouseButtonUp(1))
		{
			destinationClick = Input.mousePosition;
			
			if(isSelectByClickRunning==true){
				
			}
			else{
				StartCoroutine(SelectByClick(destinationClick,1));
			
				GetDestination();
			
				StartCoroutine(SetDestinations());
			
			}
			
			
		}
		
		
		
	}
	
	private void OnGUI()
	{
		GUI.color = new Color(1, 1 ,1 ,0.5f);
		GUI.DrawTexture(selection, selectionHighlight);
	}
	
	public static float InvertMouseY(float y)
	{
		//return y;
		return Screen.height - y;
	}
	

	
	public static void GetDestination()
	{
		
	
			RaycastHit hit;
			Ray r = Camera.main.ScreenPointToRay(destinationClick);
			
			if(Physics.Raycast(r,out hit))
			{
				while (!passables.Contains(hit.transform.gameObject.name))
				{
					//if(!Physics.Raycast(hit.point+r.direction*0.1f, r.direction, out hit))
					if(!Physics.Raycast(hit.transform.position, r.direction, out hit))
						break;
				}
				
				
			}
			if(hit.transform!=null)
				moveToDestination = hit.point;
	
	}
	
	public IEnumerator SetDestinations()
//	public static void SetDestinations()
	{
		
		while(isSelectByClickRunning==true)
		{
			yield return new WaitForSeconds(0.1f);
		}
		
		GameObject[] objects = GameObject.FindGameObjectsWithTag( "Unit" );
		int objectsLength = objects.Length;
		//print(moveToDestination);
		
		bool proceedToWar = false;
		
		
		if(tGo != null){
		   UnitPars tGoPars = tGo.GetComponent<UnitPars>();
		   if(tGoPars.nation!=dip.playerNation){
		     if(dip.warNoticeWarning==true){
				print("Attacking the object will lead to War!");
				dip.warNoticeWarning=false;
				StartCoroutine("ResetWarNotice");
			  }
			  else
			  {	
				StopCoroutine("ResetWarNotice");
				proceedToWar = true;
				dip.SetRelation(dip.playerNation, tGoPars.nation, 1);
				
			  }
			}
			else{
				proceedToWar = true;
			}
		}
		
		
		for(int i=0;i<objectsLength;i++){
			    
				GameObject go = objects[i];
				UnitPars goPars = go.GetComponent<UnitPars>();
			//	ManualControl goUo = go.GetComponent<ManualControl>();
				NavMeshAgent goNav = go.GetComponent<NavMeshAgent>();
				
				// if UnitPars is attached to gameobject
				if(goPars != null){
					if(goNav != null){
						if(goPars.isSelected){
							
							
							if(goPars.isOnBS==true){
								
								
							}
							
							goPars.failedDist = 0;
							if(tGo != null){
							
								if(proceedToWar == true){
									
									
									goPars.strictApproachMode = true;
									goPars.target = tGo;
									tGo.GetComponent<UnitPars>().noAttackers = tGo.GetComponent<UnitPars>().noAttackers+1;
									tGo.GetComponent<UnitPars>().attackers.Add(go);
									tGo.GetComponent<UnitPars>().isApproachable = true;
									goPars.isApproaching = true;
								}
							}
							else{
								if(goPars.target != null){
									goPars.target.GetComponent<UnitPars>().noAttackers = goPars.target.GetComponent<UnitPars>().noAttackers-1;
									goPars.target.GetComponent<UnitPars>().attackers.Remove(go);
									goPars.target = null;
								}
								goPars.strictApproachMode = false;
								goPars.onManualControl = true;
								
								goPars.isMovingMC = true;
								bs.UnSetSearching(go);
								goPars.manualDestination = moveToDestination;
								goNav.SetDestination(moveToDestination);
							}
							
							
							
						//	else{
						//		goNav.SetDestination(moveToDestination);
						//	}
							
						}
					}
				}
				
				
		}
		
		tGo = null;
		yield return new WaitForSeconds(0.02f);
	
	}
	
	
	public IEnumerator SelectByClick(Vector3 clickPos, int clickMode) 
	//public static void SelectByClick(Vector3 clickPos)
	{
	//		RaycastHit hit;
	        isSelectByClickRunning = true;
			Ray r = Camera.main.ScreenPointToRay(clickPos);
			
			
			
			GameObject[] objects = GameObject.FindGameObjectsWithTag( "Unit" );
			
			int objectsLength = objects.Length;
			
			//Ray world vector
			Vector3 rayDirection = r.direction;
			
			
			float distFromRay = 0.0f;
			
			int loopNum = 0;
			
			
			for(int i=0;i<objectsLength;i++){
			    
			    loopNum = loopNum+1;
			    if(loopNum>500){
			    	loopNum = 0;
			    	yield return new WaitForSeconds(0.1f);
			    }
			    
				GameObject go = objects[i];
				UnitPars goPars = go.GetComponent<UnitPars>();
			//	ManualControl goUo = go.GetComponent<ManualControl>();
				
			
				
				// if ManualControl is attached to gameobject
				if(goPars != null){
				
					//Camera world vector
					Vector3 camVec = Camera.main.transform.position;
					
					//GameObject world vector
					Vector3 goVec = go.transform.position;
				
	
				
				
					distFromRay=Vector3.Distance(rayDirection*(goVec - camVec).magnitude , goVec - camVec);
					
					if(clickMode==0){
						if(goPars.nation==dip.playerNation){
							goPars.strictApproachMode = false;
							goPars.isSelected = false;
						}
						
					}
			//		go.renderer.material.color = Color.white;
					
					
					if(distFromRay < goPars.rEnclosed){
						if(clickMode==0){
							if(goPars.nation==dip.playerNation){
								goPars.isSelected = true;
							}
						}
						else if(clickMode==1){
							tGo = go;
						}
			//			go.renderer.material.color = Color.red;
						
					}
				}
			
				
			}
			
			if(clickMode==1){
		//		tGo = null;
			}
			
			yield return new WaitForSeconds(0.02f);
		    isSelectByClickRunning = false;
		    
			
		
	}
	
	public static void SelectByRect()
	{
		GameObject[] objects = GameObject.FindGameObjectsWithTag( "Unit" );
			
			int objectsLength = objects.Length;

			
			
			for(int i=0;i<objectsLength;i++){
			    
				GameObject go = objects[i];
				UnitPars goPars = go.GetComponent<UnitPars>();
		//		ManualControl goUo = go.GetComponent<ManualControl>();
				Vector3 goPos = go.transform.position;
				
				// if ManualControl is attached to gameobject
				if(goPars != null){
					Vector3 camPos = Camera.main.WorldToScreenPoint(goPos);
					camPos.y = CameraOperator.InvertMouseY(camPos.y);
				
					
					if(selection.Contains(camPos)){
						if(goPars.nation==dip.playerNation){
							goPars.isSelected = true;
						}
			//			go.renderer.material.color = Color.red;
					}
				}
				
			}
	
	}
	
	public IEnumerator ResetWarNotice()
	{
		yield return new WaitForSeconds(8.0f);
		dip.warNoticeWarning = true;
	}
	
	
	
}
