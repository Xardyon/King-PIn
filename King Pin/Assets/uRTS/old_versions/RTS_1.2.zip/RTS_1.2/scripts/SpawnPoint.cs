﻿using UnityEngine;
using System.Collections;

public class SpawnPoint : MonoBehaviour {

public GameObject box;
//public GameObject fakeObject;
public bool readynow = true;
public float timestep = 0.01f;
public int count = 0;
public int numberOfObjects = 10000;
public float size = 1.0f;

//public int assignDiplomacy = 1;

public bool addToBS = true;
//public bool createFakeObject = false;

private GameObject objTerrain;

void Starter() {

}

void Start () {
	StartCoroutine(MakeBox());
}
 
//function Update () {

//}
 
public IEnumerator MakeBox(){

 objTerrain =  GameObject.Find("Terrain");
 
// Diplomacy diplScript = objTerrain.GetComponent<Diplomacy>();
 BattleSystem bsScript = objTerrain.GetComponent<BattleSystem>();
 
 
/*if(createFakeObject == true){
 	for(int i=0;i<2;i=i+1){
 		GameObject cubeSpawn = (GameObject)Instantiate(fakeObject, new Vector3(-9999999999999.99f-9999.99f*Random.Range(-1.0f,1.0f),-9999999999999.99f-9999.99f*Random.Range(-1.0f,1.0f),-9999999999999.99f-9999.99f*Random.Range(-1.0f,1.0f)), transform.rotation);
 		cubeSpawn.GetComponent<UnitPars>().isFakeObject = true;
 		cubeSpawn.GetComponent<UnitPars>().isReady = true;
 		bsScript.unitsBuffer.Add(cubeSpawn);
 	}
 }*/
 
 
 for(int i=0;i<numberOfObjects;i=i+1){
 	readynow=false;
 	yield return new WaitForSeconds(timestep);
 	GameObject go = (GameObject)Instantiate(box, new Vector3(transform.position.x+Random.Range(-size,size)+5,transform.position.y,transform.position.z+Random.Range(-size,size)), transform.rotation);
 
    bsScript.AddSelfHealer(go);
    
    UnitPars goPars = go.GetComponent<UnitPars>();
    goPars.isReadyBeg = false;
    goPars.rEnclosed = go.GetComponent<MeshRenderer>().renderer.bounds.extents.magnitude;
    
    bsScript.unitsBuffer.Add(go);
    
//    int iNations = cubeSpawnPars.nation;
 //   bool isAdded = false;
  //  for(int jNations = 1; jNations < 3; jNations++){
  //  	if(jNations!=iNations){
  //  		if((diplScript.relations[iNations][jNations] == 1)&&(isAdded==false)){
   // 			cubeSpawnPars.statusBS = 3;
    			
   // 			isAdded=true;
  //  		}
  //  	}
  //  }
    
 //   if(addToBS==true){
 //   	objTerrain.GetComponent<BattleSystem>().unitsBuffer.Add(cubeSpawn);
 //   }
    
    

    
    
    
 	readynow=true;
 	count = count+1;
 
 

 }
}



}