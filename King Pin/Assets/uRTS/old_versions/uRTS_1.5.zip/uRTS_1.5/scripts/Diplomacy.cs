﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Diplomacy : MonoBehaviour {
	
	public int numberNations = 2;
	public int playerNation = 1;
	
	public bool warNoticeWarning = true;
//	public List<bool> warWarnings = new List<bool>();
	
	
	public List<List<int>> relations = new List<List<int>>();
	
	
	/////////// relation values and meanings //////////////////
	// relations[i,j] = 0; - peace
	// relations[i,j] = 1; - war
	// relations[i,j] = 2; - slavery
	// relations[i,j] = 3; - mastery
	// relations[i,j] = 4; - alliance
	///////////////////////////////////////////////////////////
	
	////////// unitPars statusBS values and meanings //////////
	// statusBS = 0; - is not on BS
	// statusBS = 1; - is on BS
	// statusBS = 2; - remove from BS
	// statusBS = 3; - set to BS
	///////////////////////////////////////////////////////////
	
	// Use this for initialization
	void Start () {
	  /*  for(int i=0;i<=numberNations;i++){
	    	
	    	warWarnings.Add(true);
	    	if((i==0)||(i==playerNation)){
	    		warWarnings[i] = false;
	    	}
	    	if(warNoticeWarning==false){
	    		warWarnings[i] = false;
	    	}
	    }*/

		for(int i=0;i<=numberNations;i++){
			relations.Add(new List<int> { 0 });
	
		}
		
		
		for(int i=0;i<=numberNations;i++){
			for(int j=0;j<numberNations;j++){
				relations[i].Add(0);
			}
		}
		
		
		
        SetAllPeace();
	
	}
	
	// Update is called once per frame
	void Update () {
	
		if (Input.GetKeyDown (KeyCode.F))
		{
			SetRelation(1, 2, 1);
	//		SetRelation(1, 3, 1);
			print("war");
		}
		if (Input.GetKeyDown (KeyCode.P))
		{
			SetRelation(1, 2, 0);
	//		SetRelation(1, 3, 0);
			print("peace");
		}
	
	}
	
	public void SetAllPeace(){
		for (int i = 0; i <= numberNations; i++){
			for (int j = 0; j <= numberNations; j++){
				if(i!=j){
					relations[i][j] = 0;
				}
			}
		}
		print("peace");
	}
	
	public void SetAllWar(){
		for (int i = 0; i <= numberNations; i++){
			for (int j = 0; j <= numberNations; j++){
				if(i!=j){
					relations[i][j] = 1;
				}
			}
		}
		print("war");
	}
	
	public void SetRelation(int firstNation, int secondNation, int relation){
		if((firstNation!=secondNation) && (relation!=relations[firstNation][secondNation])){
	    	if(relation == 2){
	    		relations[firstNation][secondNation] = 2;
	    		relations[secondNation][firstNation] = 3;
	    	}
	    	else if(relation == 3){
	    		relations[firstNation][secondNation] = 3;
	    		relations[secondNation][firstNation] = 2;
	    	}
			else{
				relations[firstNation][secondNation] = relation;
				relations[secondNation][firstNation] = relation;
			}
			
			
			
			if(relation == 1){
			    warNoticeWarning = false;
			//	if(firstNation==playerNation){
			//		warWarnings[secondNation] = false;
			//	}
			//	else if(secondNation==playerNation){
			//		warWarnings[firstNation] = false;
			//	}
				foreach(GameObject go in GameObject.FindGameObjectsWithTag("Unit"))
				{
				
					
					UnitPars goPars = go.GetComponent<UnitPars>();
					
					BattleSystem bs = this.gameObject.GetComponent<BattleSystem>();
					
					if((goPars.prepareMovingMC==false)&&(goPars.isMovingMC==false)){
						if(goPars.nation == firstNation){
							bs.ResetSearching(go);
						}
						else if(goPars.nation == secondNation){
							bs.ResetSearching(go);
						}
					}
					
				
    				
    				
				}
			}
			else{
				warNoticeWarning = true;
			//	if(firstNation==playerNation){
			//		warWarnings[secondNation] = true;
			//	}
			//	else if(secondNation==playerNation){
			//		warWarnings[firstNation] = true;
			//	}
				foreach(GameObject go in GameObject.FindGameObjectsWithTag("Unit"))
				{
				
					
					UnitPars goPars = go.GetComponent<UnitPars>();
    		
    					
    				BattleSystem bs = this.gameObject.GetComponent<BattleSystem>();
    				
    				if((goPars.prepareMovingMC==false)&&(goPars.isMovingMC==false)){
    				// remove enemy targets on peace
    					
						if(goPars.nation == firstNation){
    					//	bs.UnSetSearching(go);
    						bs.ResetSearching(go);
    					}
    					else if(goPars.nation == secondNation){
    					//	bs.UnSetSearching(go);
    						bs.ResetSearching(go);
    					}
    				}
    				
    				if(goPars.strictApproachMode == true){
    					GameObject target = goPars.target;
    						if(target != null){
    							UnitPars tgPars = target.GetComponent<UnitPars>();
    							if(tgPars.nation != goPars.nation){
    							
    								
    								if(goPars.nation == firstNation){
    									goPars.strictApproachMode = false;
    								}
    								else if(goPars.nation == secondNation){
    									goPars.strictApproachMode = false;
    								}
    							}
    						}
    				}
    		
				}
			}
		}
	}
	
	public IEnumerator Invoke(){
	
		bool invokeEnd = false;
		while(invokeEnd == false){
		
			if(invokeEnd == false){
				SetAllPeace();
			}
			
			invokeEnd = true;
			yield return new WaitForSeconds(0.5f);
		}
	
	}
}
