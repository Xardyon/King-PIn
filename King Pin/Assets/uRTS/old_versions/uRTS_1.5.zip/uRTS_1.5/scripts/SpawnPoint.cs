﻿using UnityEngine;
using System.Collections;

public class SpawnPoint : MonoBehaviour {

public GameObject model;

public bool readynow = true;
public float timestep = 0.01f;
public int count = 0;
public int numberOfObjects = 100;
public float size = 1.0f;

public int nation = 1;


public bool addToBS = true;

private GameObject objTerrain;

void Starter() {

}

void Start () {
	StartCoroutine(MakeBox());
}

 
public IEnumerator MakeBox(){

 objTerrain =  GameObject.Find("Terrain");
 
 BattleSystem bsScript = objTerrain.GetComponent<BattleSystem>();
 
 
 
 for(int i=0;i<numberOfObjects;i=i+1){
 	readynow=false;
 	yield return new WaitForSeconds(timestep);
 
    Vector3 randomPosition = transform.localPosition + (Quaternion.Euler(0, -90, 0) * transform.forward * 5) + new Vector3(Random.Range(-size,size), 0.0f, Random.Range(-size,size));
    Quaternion randomRotation = Quaternion.Euler( 0f, Random.Range(0f, 360f) , 0f);
 

    GameObject go = (GameObject)Instantiate(model, randomPosition, randomRotation);
    
    UnitPars goPars = go.GetComponent<UnitPars>();
    goPars.isReadyBeg = true;
    goPars.rEnclosed = go.GetComponent<MeshRenderer>().renderer.bounds.extents.magnitude;
    goPars.nation = nation;
    
    if(go.GetComponent<SpawnPoint>() != null){
    	go.GetComponent<SpawnPoint>().nation = nation;
    }
    
    bsScript.AddSelfHealer(go);
    
    bsScript.unitsBuffer.Add(go);
    

    
    
    
 	readynow=true;
 	count = count+1;
 
 

 }
}



}