﻿using UnityEngine;
using System.Collections;

public class RTSCamera : MonoBehaviour {
	
	public float fov = 60.0f;
	public float fovmax = 90.0f;

	public float min =30.0f;
	
	public float ScrollSpeed = 15.0f;

	public float ScrollEdge = 0.01f;

 

//	private int HorizontalScroll = 1;

//	private int VerticalScroll = 1;

//	private int DiagonalScroll = 1;

 

	public float PanSpeed = 10.0f;

 

	public Vector2 ZoomRange = new Vector2(-5.0f,5.0f);

	public float CurrentZoom = 0.0f;

	public float ZoomSpeed = 1.0f;

	public float ZoomRotation = 1.0f;

	public float rotationSpeed = 1.0f;

//	private Vector3 InitPos;

//	private Vector3 InitRotation;
	
	public float minCamHeight = 65.0f;

	public float maxCamHeight = 75.0f;
	
	// Use this for initialization
	void Start () {
//		InitPos = transform.position;

//    	InitRotation = transform.eulerAngles;
    
 	//	Camera.main.transform.position.y = Terrain.activeTerrain.SampleHeight(camera.transform.position)+70;
 	
 		minCamHeight = 65.0f;
		maxCamHeight = 75.0f;
	}
	
	// Update is called once per frame
	void Update () {
		
		if ( Input.GetKey("mouse 2") )

    	{

        

    	}
    	
    	else

    	{

        	if ( Input.GetKey("d") || Input.mousePosition.x >= Screen.width * (1 - ScrollEdge) )

        	{
        	
				transform.Translate(new Vector3(
					Time.deltaTime * ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
        			0.0f,
        			Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
        		Space.World);
        
        	}

        	else if ( Input.GetKey("a") || Input.mousePosition.x <= Screen.width * ScrollEdge )

        	{
				transform.Translate(new Vector3(
					Time.deltaTime * -ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
					0.0f,
					Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World);
       
       	    }

        

        	if ( Input.GetKey("w") || Input.mousePosition.y >= Screen.height * (1 - ScrollEdge) )

        	{

            	transform.Translate(new Vector3(
            		Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
            		0.0f,
            		Time.deltaTime * ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
            	Space.World);
         
        	}

        	else if ( Input.GetKey("s") || Input.mousePosition.y <= Screen.height * ScrollEdge )

        	{
				transform.Translate(new Vector3(
					Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
					0.0f,
					Time.deltaTime * -ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World);
 
        	}

    	}
    	
    	Vector3 fwd = transform.TransformDirection (Vector3.forward);
    	
    	if (Input.GetAxis("Mouse ScrollWheel")> 0){
		
			transform.Translate(new Vector3(
				2*Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
	
		
			if(Camera.main.transform.rotation.eulerAngles.x <= 180.0f){
			if (Physics.Raycast (transform.position, fwd, 50.0f)) {
				transform.Translate(new Vector3(
				2*Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * -ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
			}
			}
			if(Camera.main.transform.rotation.eulerAngles.x >= 180.0f){
			if (!(Physics.Raycast (transform.position, -fwd, 150.0f))) {
				transform.Translate(new Vector3(
				2*Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * -ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
		  
			}
	    }


		}
		
		if (Input.GetAxis("Mouse ScrollWheel")< 0){
	
		
			transform.Translate(new Vector3(
				2*Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * -ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)), 
				Space.World
			
			);
		

        
        	if(Camera.main.transform.rotation.eulerAngles.x >= 180.0f){
			if (Physics.Raycast (transform.position, -fwd, 50.0f)) {
	    
				transform.Translate(new Vector3(
				2*Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
			}
			}	
		
			if(Camera.main.transform.rotation.eulerAngles.x <= 180.0f){
			if (!(Physics.Raycast (transform.position, fwd, 150.0f))) {
		
				transform.Translate(new Vector3(
				2*Time.deltaTime * ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * -ScrollSpeed *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * ScrollSpeed *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
			}
		}
		


		}
		
		// ROTATION

    	if (Input.GetMouseButton(1)){
			float h = rotationSpeed * Input.GetAxis ("Mouse X");
			float v = rotationSpeed * Input.GetAxis ("Mouse Y");
			transform.Rotate (0, h, 0, Space.World);

			transform.Rotate (v, 0, 0);

			if((Camera.main.transform.rotation.eulerAngles.x >= 90) &&(Camera.main.transform.rotation.eulerAngles.x <= 180)){
	
				transform.Rotate (-v, 0, 0);
			}
			if(((Camera.main.transform.rotation.eulerAngles.x >= 180)&&(Camera.main.transform.rotation.eulerAngles.x <= 270))||(Camera.main.transform.rotation.eulerAngles.x < 0) ){
	
				transform.Rotate (-v, 0, 0);
			}


    		if((Camera.main.transform.rotation.eulerAngles.z >= 160)&&(Camera.main.transform.rotation.eulerAngles.z <= 200)){
    			transform.Rotate (-v, 0, 0);
    		}
		}
		
		
	}
}
