﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UnitPars : MonoBehaviour {
	
	public int statusBS = 1;
	[HideInInspector] public bool isFakeObject = false;
	public bool isMovable = true;
	
	public bool onManualControl = false;
	
	public bool isArcher = false;
	public GameObject arrow = null;
	
	[HideInInspector] public Vector3 prevPos = Vector3.zero;
	[HideInInspector] public float prevTime = 0.0f;
	
	public float velArrow = 20.0f;
	
    public bool isReadyBeg = false;
    public bool isReadyEnd = false;
	public bool isApproaching = false;
	public bool strictApproachMode = false;
	public bool isAttacking = false;

	public bool isApproachable = true;
	public bool isAttackable = true;
	public bool onTargetSearch = false;
	public bool isHealing = false;
	public bool isImmune = false;
	public bool isDying = false;
	public bool isSinking = false;
	
//	public Vector3 movVelocity;
	
	
	
	public GameObject target = null;
	public List<GameObject> attackers = new List<GameObject>();
	
	public int noAttackers = 0;
	public int maxAttackers = 3;
	public int maxStrictAttackers = 3;
	
	public float stopDistIn = 2.0f;
	public float stopDistOut = 2.5f;
	
	
	
	[HideInInspector] public float prevR;
	public int failedR = 0;
	public int critFailedR = 10;
	
	public float attackWaiter = 3.0f;
	[HideInInspector] public float timeMark = 0.0f;
	
	public float health = 100.0f;
	public float maxHealth = 100.0f;
	public float selfHealFactor = 10.0f;
	
	public float strength = 10.0f;
	public float defence = 10.0f;
	

	
	[HideInInspector] public int deathCalls = 0;
	public int maxDeathCalls = 5;
	
	[HideInInspector] public int sinkCalls = 0;
	public int maxSinkCalls = 5;
	
	[HideInInspector] public int unsetCalls = 0;
	[HideInInspector] public int maxUnsetCalls = 5;
	
	
	
	[HideInInspector] public bool changeMaterial = true;
	[HideInInspector] public int animationMode = 100;
	
	public int nation = 1;
	
// MC options
    
    public bool isSelected = false;
	public bool prepareMovingMC = false;
	public bool isMovingMC = false;
	
	public bool isOnBS = false;
	
	
    [HideInInspector] public float prevDist = 0.0f;
    [HideInInspector] public int failedDist = 0;
    public int critFailedDist = 10;
	
	public Vector3 manualDestination;
	
	public float rEnclosed = 0.0f;	
	
	
	
	
	
	



	// Use this for initialization
	void Start () {
	
	}
	

}
