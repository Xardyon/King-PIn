﻿using UnityEngine;
using System.Collections;

public class SpawnPoint : MonoBehaviour {

public GameObject box;

public bool readynow = true;
public float timestep = 0.01f;
public int count = 0;
public int numberOfObjects = 10000;
public float size = 1.0f;


public bool addToBS = true;

private GameObject objTerrain;

void Starter() {

}

void Start () {
	StartCoroutine(MakeBox());
}

 
public IEnumerator MakeBox(){

 objTerrain =  GameObject.Find("Terrain");
 
 BattleSystem bsScript = objTerrain.GetComponent<BattleSystem>();
 
 
 
 for(int i=0;i<numberOfObjects;i=i+1){
 	readynow=false;
 	yield return new WaitForSeconds(timestep);
 	GameObject go = (GameObject)Instantiate(box, new Vector3(transform.position.x+Random.Range(-size,size)+5,transform.position.y,transform.position.z+Random.Range(-size,size)), transform.rotation);
 
    bsScript.AddSelfHealer(go);
    
    UnitPars goPars = go.GetComponent<UnitPars>();
    goPars.isReadyBeg = true;
    goPars.rEnclosed = go.GetComponent<MeshRenderer>().renderer.bounds.extents.magnitude;
    
    bsScript.unitsBuffer.Add(go);
    

    
    
    
 	readynow=true;
 	count = count+1;
 
 

 }
}



}