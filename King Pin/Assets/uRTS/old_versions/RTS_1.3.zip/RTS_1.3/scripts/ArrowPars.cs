﻿using UnityEngine;
using System.Collections;

public class ArrowPars : MonoBehaviour {
	
	public GameObject target = null;
	public float carriedDamage = 0.0f;
	
	public bool damageApplied = false;
	public bool destrStarted = false;
	
	public float oldVelocity = 1.0f;
	
	// Use this for initialization
	void Start () {
		oldVelocity = rigidbody.velocity.sqrMagnitude;
	//	transform.Rotate(0,0,-90, Space.World);
	}
	
	// Update is called once per frame
	void Update () {
	 //   Vector3 velocity = (rigidbody.velocity).normalized;
	    
	//    Vector3 forward = new Vector3(target.transform.x,)
	    
	//    transform.LookAt(target.transform.position);
	
	    transform.LookAt((rigidbody.velocity).normalized+transform.position);
	    
		//transform.Rotate(, Space.World);
		if(destrStarted == false){
		 if(damageApplied == false){
			if(target != null){
				float goDist = (target.transform.position - transform.position).sqrMagnitude;
			
				UnitPars targPars = target.GetComponent<UnitPars>();
				if(goDist < targPars.rEnclosed*targPars.rEnclosed){
					targPars.health = targPars.health - carriedDamage;
					damageApplied = true;
		//			Destroy(this.gameObject);
			
				}
		
		
			}
		 }
		
	//	 if (rigidbody.velocity.sqrMagnitude < 0.000001f) {
   //    	destrStarted = true;
   //     	StartCoroutine("DestrPhase");
    //	 }
   // 	 oldVelocity = rigidbody.velocity.sqrMagnitude;
    	}
    	
    	if(transform.position.y<-1.0f){
    		Destroy(this.gameObject);
    	}
		
		
		
	}
	
	public IEnumerator DestrPhase(){
		yield return new WaitForSeconds(1.0f);
		Destroy(this.gameObject);
	}
}
