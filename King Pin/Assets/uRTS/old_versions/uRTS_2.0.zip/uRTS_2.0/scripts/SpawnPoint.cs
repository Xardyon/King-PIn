﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SpawnPoint : MonoBehaviour {

public GameObject model;

public bool readynow = true;
public float timestep = 0.01f;
public int count = 0;
public int numberOfObjects = 100;
public float size = 1.0f;

public int nation = 1;


public bool addToBS = true;

public bool isLocked = false;

private GameObject objTerrain;

public bool useAutoRespawn = false;
public int autoRespawnThreshold = 50;

private Scores sc = null;
private Diplomacy dip = null;

private RTSMaster rtsm = null;

[HideInInspector] public bool isManualPosition = false;
[HideInInspector] public List<Vector3> manualPosition = new List <Vector3>();
[HideInInspector] public List<Quaternion> manualRotation = new List <Quaternion>();


public void Starter() {
	StartCoroutine(MakeBox());
}

void Start () {
 //   manualPosition = new List <Vector3>();
	StartCoroutine(MakeBox());
}

 
public IEnumerator MakeBox(){
	 yield return new WaitForSeconds(timestep);
	 
	 objTerrain =  GameObject.Find("Terrain");
     rtsm = GameObject.Find("RTS Master").GetComponent<RTSMaster>();
     
	 BattleSystem bsScript = objTerrain.GetComponent<BattleSystem>();
	 sc = objTerrain.GetComponent<Scores>();
	 dip = objTerrain.GetComponent<Diplomacy>();
	 
	 Economy ec = null;
	 while(ec == null){
	    ec = objTerrain.GetComponent<Economy>();
	    if(ec == null){
	    	yield return new WaitForSeconds(0.2f);
	    }
	 }
	 
	 
//	 print("aa");
 
 
	 while(true){
         if(isLocked == false){
		//	 for(int i=0;i<numberOfObjects;i=i+1){
			 int i = 0;
			 count = 0;
			 
			 int costIron = model.GetComponent<UnitPars>().costIron;
			 int costGold = model.GetComponent<UnitPars>().costGold;
			 int costLumber = model.GetComponent<UnitPars>().costLumber;
			 int costPopulation = model.GetComponent<UnitPars>().costPopulation;

			 
			 while(i<numberOfObjects){
			    if(
			    	(ec.iron[nation-1] - costIron >= 0) &&
			    	(ec.gold[nation-1] - costGold >= 0) &&
			    	(ec.lumber[nation-1] - costLumber >= 0) &&
			    	(ec.population[nation-1] - costPopulation >= 0)
			    ){
			        yield return new WaitForSeconds(timestep);
					i++;
					
					ec.iron[nation-1] = ec.iron[nation-1] - costIron;
			    	ec.gold[nation-1] = ec.gold[nation-1] - costGold;
			    	ec.lumber[nation-1] = ec.lumber[nation-1] - costLumber;
			    	ec.population[nation-1] = ec.population[nation-1] - costPopulation;
			    	
			    	if((nation-1)==0){
						ec.textIron.text = (ec.iron[0]).ToString();
						ec.textGold.text = (ec.gold[0]).ToString();
						ec.textLumber.text = (ec.lumber[0]).ToString();
						ec.textPopulation.text = (ec.population[0]).ToString();
			    	}
					
					readynow=false;
					
	
					float rand1 = Random.Range(-size,size);
					float rand2 = Random.Range(-size,size);
	
 
					Vector3 randomPosition = Vector3.zero;
	
	
					randomPosition = transform.localPosition + (Quaternion.Euler(0, -90, 0) * transform.forward * 5) + new Vector3(rand1, 0f, rand2);    
		            
		            float randAngle = Random.Range(0f, 360f);
					Quaternion randomRotation = Quaternion.Euler( 0f, randAngle , 0f);
                    
                    GameObject go = null;
                    if(isManualPosition == false){
						go = (GameObject)Instantiate(model, randomPosition, randomRotation);
						
						
						
					//	AddToRtsMasterLists(ref go);
							
						
					}
					else{
					//    print(i);
					//    print(numberOfObjects);
					    Vector3 pos = manualPosition[0];
					    randAngle = manualRotation[0].eulerAngles.y;
						go = (GameObject)Instantiate(model, pos, manualRotation[0]);
						
						manualPosition.RemoveAt(0);
						manualRotation.RemoveAt(0);
						
						if(manualPosition.Count<1){
					//	if(i == numberOfObjects-1){
							isManualPosition = false;
						}
					//	AddToRtsMasterLists(ref go);
							
						
					}
					UnitPars goPars = null;
	
					SpriteLoader sl = null;
	
					if(go.GetComponent<SpriteLoader>() != null){
						sl = go.GetComponent<SpriteLoader>();
		
						go.transform.position = go.transform.position - new Vector3(0f,0.5f*sl.spriteSize,0f);
					}
	
					if(go.GetComponent<UnitPars>() != null){
						goPars = go.GetComponent<UnitPars>();
						goPars.isReadyBeg = true;
						goPars.rEnclosed = go.GetComponent<MeshRenderer>().renderer.bounds.extents.magnitude;
						if(goPars.isBuilding == true){
							goPars.rEnclosed = 0.6f*goPars.rEnclosed;
						}
						goPars.nation = nation;
					}
	
					if(go.GetComponent<SpawnPoint>() != null){
						go.GetComponent<SpawnPoint>().nation = nation;
					}
	
					if(goPars != null){
						bsScript.AddSelfHealer(go);
	
						bsScript.unitsBuffer.Add(go);
	
						if(goPars.isBuilding == false){
							sc.nUnits[nation-1] = sc.nUnits[nation-1]+1;
						}
						else{
							sc.nBuildings[nation-1] = sc.nBuildings[nation-1]+1;
						}
						
						rtsm.numberOfUnitTypes[nation-1][goPars.rtsUnitId] = rtsm.numberOfUnitTypes[nation-1][goPars.rtsUnitId] + 1;
						if(goPars.rtsUnitId == 15){
							rtsm.resourcesCollection.workers.Add(go);
							rtsm.resourcesCollection.up_workers.Add(goPars);
							rtsm.resourcesCollection.nav_workers.Add(go.GetComponent<NavMeshAgent>());
							rtsm.resourcesCollection.sl_workers.Add(go.GetComponent<SpriteLoader>());
							rtsm.resourcesCollection.workers_resType.Add(-1);
							rtsm.resourcesCollection.workers_resAmount.Add(0);
						}
						else if(goPars.rtsUnitId == 2){
							rtsm.resourcesCollection.sawmills.Add(go);
							rtsm.resourcesCollection.up_sawmills.Add(goPars);
							rtsm.resourcesCollection.sawmillsPos.Add(
							    go.transform.position + RotAround(-go.transform.rotation.eulerAngles.y+180f,(new Vector3(0f,0f,goPars.rEnclosed)),(new Vector3(0f,1f,0f)))
							);
							
						}
						else if(goPars.rtsUnitId == 5){
							rtsm.resourcesCollection.mines.Add(go);
							rtsm.resourcesCollection.up_mines.Add(goPars);
							rtsm.resourcesCollection.minesPos.Add(
							    go.transform.position + RotAround(-go.transform.rotation.eulerAngles.y,(new Vector3(0f,0f,goPars.rEnclosed)),(new Vector3(0f,1f,0f)))
							);
							//rtsm.resourcesCollection.minesResource.Add(200);
							int neigh = rtsm.resourcePoint.kd_allResLocations.FindNearest(go.transform.position,1);
							float r = (rtsm.resourcePoint.allResLocations[neigh] - go.transform.position).magnitude;
							int resAmount = rtsm.resourcePoint.resAmount[neigh];
							int resToAdd = (int)((1f-0.6f*(r/7f))*resAmount);
							if(resToAdd < 500){
								resToAdd = 500;
								if(resToAdd>resAmount){
									resToAdd = resAmount;
								}
							}
					//		print(resToAdd);
							rtsm.resourcesCollection.minesResource.Add(resToAdd);
							goPars.resourceType = rtsm.resourcePoint.resTypes[neigh];
							goPars.remainingResources = resToAdd;
							rtsm.resourcesCollection.minesResourceType.Add(rtsm.resourcePoint.resTypes[neigh]);
							rtsm.resourcesCollection.minesResPoints.Add(neigh);
							
						}
						else if(goPars.rtsUnitId == 0){
							rtsm.resourcesCollection.castle.Add(go);
							rtsm.resourcesCollection.up_castle.Add(goPars);
							rtsm.resourcesCollection.castlePos.Add(
							    go.transform.position + RotAround(-go.transform.rotation.eulerAngles.y+90f,(new Vector3(0f,0f,goPars.rEnclosed)),(new Vector3(0f,1f,0f)))
							);
							
						}
						
					}
	
	
	
					readynow=true;
					count = count+1;
                }
                else{
					yield return new WaitForSeconds(1.0f);
                }
 

			 }
			 
			 isLocked = true;
		 }
		 yield return new WaitForSeconds(1.0f);
		 
		 if(nation != dip.playerNation){
		 	CheckAutoRespawn();
		 }
 
	}



}

// public void AddToRtsMasterLists(ref GameObject go){
// 	if(model == rtsm.castlePrefab){
// 		rtsm.castleList.Add(go);
// 	}
// 	else if(model == rtsm.barracksPrefab){
// 		rtsm.barracksList.Add(go);
// 	}
// 	else if(model == rtsm.farmPrefab){
// 		rtsm.farmList.Add(go);
// 	}
// 	else if(model == rtsm.laboratoryPrefab){
// 		rtsm.laboratoryList.Add(go);
// 	}
// 	else if(model == rtsm.minePrefab){
// 		rtsm.mineList.Add(go);
// 	}
// 	else if(model == rtsm.factoryPrefab){
// 		rtsm.factoryList.Add(go);
// 	}
// 	else if(model == rtsm.stablesPrefab){
// 		rtsm.stablesList.Add(go);
// 	}
// 	else if(model == rtsm.windmillPrefab){
// 		rtsm.windmillList.Add(go);
// 	}
// 	else if(model == rtsm.towerPrefab){
// 		rtsm.towerList.Add(go);
// 	}
// }


public void CheckAutoRespawn(){
	
	if(this.gameObject.GetComponent<UnitPars>() != null){
		if(this.gameObject.GetComponent<UnitPars>().isBuilding == true){
			if(sc.nUnits[nation-1]<autoRespawnThreshold*sc.nBuildings[nation-1]){
				if(isLocked == true){
					numberOfObjects = 30;
					isLocked = false;
				}
			}
		}
	}
	
}




Vector3 RotAround(float rotAngle, Vector3 original, Vector3 direction){
	    
	    
	    
	    Vector3 cross1 = Vector3.Cross(original,direction);
	    
	    Vector3 pr = Vector3.Project(original,direction);
	    Vector3 pr2 = original - pr;
	    
	    
	    Vector3 cross2 = Vector3.Cross(pr2,cross1);
	    
	    Vector3 rotatedVector = (Quaternion.AngleAxis( rotAngle, cross2)*pr2)+pr;
	    
	
		return rotatedVector;
	
	}




}