﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class RTSMaster : MonoBehaviour {
 
 
// buildings    
//     public GameObject castlePrefab = null;
//     public GameObject barracksPrefab = null;
//     public GameObject farmPrefab = null;
//     public GameObject laboratoryPrefab = null;
//     public GameObject minePrefab = null;
//     public GameObject factoryPrefab = null;
//     public GameObject stablesPrefab = null;
//     public GameObject windmillPrefab = null;
//     
//     public GameObject towerPrefab = null;
    
    public List<GameObject> rtsUnitTypePrefabs = new List<GameObject>();
    
    public List<List<int>> numberOfUnitTypes = new List<List<int>>();
    public List<List<int>> unitTypeLocking = new List<List<int>>();
    
    
//     [HideInInspector] public List<GameObject> castleList = new List<GameObject>();
//     [HideInInspector] public List<GameObject> barracksList = new List<GameObject>();
//     [HideInInspector] public List<GameObject> farmList = new List<GameObject>();
//     [HideInInspector] public List<GameObject> laboratoryList = new List<GameObject>();
//     [HideInInspector] public List<GameObject> mineList = new List<GameObject>();
//     [HideInInspector] public List<GameObject> factoryList = new List<GameObject>();
//     [HideInInspector] public List<GameObject> stablesList = new List<GameObject>();
//     [HideInInspector] public List<GameObject> windmillList = new List<GameObject>();
// 
//     [HideInInspector] public List<GameObject> towerList = new List<GameObject>();
    
    
    
//    public int activeCastleMenuId = 1;
    
    public BuildDiplomacyMenu buildDiplomacyMenu = null;
    public Scores scores = null;
    public Diplomacy diplomacy = null;
    public BuildMark buildMark = null;
    public Economy economy = null;
    public ResourcesCollection resourcesCollection = null;
    public CreateForest createForest = null;
    public BattleSystem battleSystem = null;
    public ResourcePoint resourcePoint = null;
    public CameraOperator cameraOperator = null;
    
    
	// Use this for initialization
	void Awake () {
	    diplomacy = GameObject.Find("Terrain").GetComponent<Diplomacy>();
	    int NN = diplomacy.numberNations;
	    
	    numberOfUnitTypes = new List<List<int>>();
	    unitTypeLocking = new List<List<int>>();
	    
	    for(int i=0;i<NN;i++){
	        numberOfUnitTypes.Add(new List<int>());
	        unitTypeLocking.Add(new List<int>());
	
			for(int j=0;j<rtsUnitTypePrefabs.Count;j++){
				numberOfUnitTypes[i].Add(0);
				unitTypeLocking[i].Add(0);
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
