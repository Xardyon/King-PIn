﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BuildMark : MonoBehaviour {
    
 //   public GameObject goTerrain = null;
    
    
    public GameObject projector = null;
    public GameObject nationCentre = null;
    private SpawnPoint sp = null;
    
    private Terrain ter = null;
    
    private float xTer = 0f;
    private float zTer = 0f;
    
    private int baseRes = 0;
    
    private float markRadius = 10f;
    private float norm_markRadius;
    
    private float highestSteepness = 0f;
    
    [HideInInspector] public bool buildingAllowed = false;
    
    private float townRadius = 150f;
    
    private BattleSystem bs;
    
    public GameObject objectToSpawn = null;
    public UnitPars up_objectToSpawn = null;
    [HideInInspector] public int objectToSpawnId = 0;
    
    private float rEnclosed = 0f;
    
    private RTSMaster rtsm = null;
    
    private int nLeftClicks = 0;
    
    private List<GameObject> projectorFixed = new List<GameObject>();
    private List<Vector3> spawnLocations = new List<Vector3>();
    private List<Quaternion> spawnRotations = new List<Quaternion>();
    
    
    
    
    public void ActivateProjector(){
        rEnclosed = objectToSpawn.GetComponent<MeshRenderer>().renderer.bounds.extents.magnitude;
    	projector.SetActive(true);
    	projector.GetComponent<Projector>().orthographicSize = rEnclosed;
    }
    void Awake(){
    	rtsm = GameObject.Find("RTS Master").GetComponent<RTSMaster>();
    	rtsm.buildMark = this;
    }
    
	// Use this for initialization
	void Start () {
	    
	    
	    bs = GameObject.Find("Terrain").GetComponent<BattleSystem>();
	    sp = nationCentre.GetComponent<SpawnPoint>();
		ter = Terrain.activeTerrain;
		xTer = ter.terrainData.size.x;
		zTer = ter.terrainData.size.z;
		
		baseRes = ter.terrainData.baseMapResolution;
		norm_markRadius = markRadius/xTer;
	}
	
	// Update is called once per frame
	void LateUpdate () {
	    
	    float height = 0f;
		RaycastHit hit;
             Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
             if (ter.collider.Raycast (ray, out hit, 10000f)) {
                 height = ter.SampleHeight(hit.point);
             }
        
        projector.transform.position = new Vector3(hit.point.x, height+20f, hit.point.z);
        
        float ttx = hit.point.x/xTer;
        float ttz = hit.point.z/zTer;
        
        float tileXbase = ttx*baseRes;
        float tileZbase = ttz*baseRes;
        float delta_tileRadius = norm_markRadius*baseRes;
        
        int tilexmin = (int)(tileXbase - delta_tileRadius);
        int tilexmax = (int)(tileXbase + delta_tileRadius);
        int tilezmin = (int)(tileZbase - delta_tileRadius);
        int tilezmax = (int)(tileZbase + delta_tileRadius);
        
        highestSteepness = 0f;
        
        for(int i=tilexmin; i<=tilexmax; i++){
        	if(i>=0){
        		if(i<baseRes){
        			for(int j=tilezmin; j<=tilezmax; j++){
        				if(j>=0){
							if(j<baseRes){
							
						// if inside the circle		
								if(
									((1f*i/baseRes-ttx)*(1f*i/baseRes-ttx))+
									((1f*j/baseRes-ttz)*(1f*j/baseRes-ttz))
									 <
									norm_markRadius*norm_markRadius
								){
									if(highestSteepness < ter.terrainData.GetSteepness(1f*i/baseRes, 1f*j/baseRes)){
										highestSteepness = ter.terrainData.GetSteepness(1f*i/baseRes, 1f*j/baseRes);
									}
								}
							
								
							}
						}	
        			}
        		}
        	}
        }
    //    print(delta_tileRadius);
        
        
    //    print(highestSteepness);
        if(highestSteepness > 30f){
        	projector.GetComponent<Projector>().material.color = Color.red;
        	buildingAllowed = false;
        }
        else if(
			(hit.point-rtsm.resourcesCollection.treePositions[
				rtsm.resourcesCollection.kd_treePositions.FindNearest(hit.point,1)
			]).sqrMagnitude < rEnclosed*rEnclosed
        ){
        	projector.GetComponent<Projector>().material.color = Color.red;
        	buildingAllowed = false;
        }
        else{
        	projector.GetComponent<Projector>().material.color = Color.green;
        	buildingAllowed = true;
        }
        
        
        
        if(nationCentre != null){
            if((up_objectToSpawn.rtsUnitId != 2) && (up_objectToSpawn.rtsUnitId != 5)){
				if((hit.point-nationCentre.transform.position).sqrMagnitude>townRadius*townRadius){
					projector.GetComponent<Projector>().material.color = Color.red;
					buildingAllowed = false;
				}
        	}
        	else if(up_objectToSpawn.rtsUnitId == 5){
        	    int neigh = rtsm.resourcePoint.kd_allResLocations.FindNearest(hit.point,1);
        		if((rtsm.resourcePoint.allResLocations[neigh] - hit.point).sqrMagnitude>49f){
        			projector.GetComponent<Projector>().material.color = Color.red;
					buildingAllowed = false;
        		}
        	}
        }
        
        if(bs != null){
        	int ucount = bs.unitss.Count;
        	for(int ii=0; ii<ucount; ii++){
        		if(bs.unitssUP[ii].isBuilding == true){
        		    float stopDistOut = (bs.unitssUP[ii].rEnclosed + rEnclosed)*(bs.unitssUP[ii].rEnclosed + rEnclosed);
        		    //24f*bs.unitssUP[ii].stopDistOut*bs.unitssUP[ii].stopDistOut;
        			if((hit.point-bs.unitss[ii].transform.position).sqrMagnitude<stopDistOut){
						projector.GetComponent<Projector>().material.color = Color.red;
						buildingAllowed = false;
					}
        		}
        	}
        }
        
        
        if(Input.GetMouseButtonDown(0)){
        	if(buildingAllowed == true){
        		
        		UnitPars objectToSpawnPars = objectToSpawn.GetComponent<UnitPars>();
        	
        	// if continuous building (fence)	
        		if(objectToSpawnPars.rtsUnitId == 9){
        			nLeftClicks = nLeftClicks+1;
        			if(nLeftClicks == 1){
        				projectorFixed.Add((GameObject)Instantiate(projector, projector.transform.position, projector.transform.rotation));
        				spawnLocations.Add(hit.point);
        				spawnRotations.Add(projector.transform.rotation);
        			}
        			else if(nLeftClicks == 2){
        				
        				nLeftClicks = 0;
        				sp.model = objectToSpawn;
        				
        				objectToSpawn.GetComponent<NavMeshAgent>().radius = 0.5f*rEnclosed;
        				
        				sp.numberOfObjects = 0;
        				
        				if(projectorFixed.Count>1){
        					spawnRotations[0] = spawnRotations[1];
        				}
        				
        				for(int i=0;i<projectorFixed.Count;i++){
        				    
        				    sp.isManualPosition = true;
        				    
							sp.manualPosition.Add(spawnLocations[i]);
							sp.manualRotation.Add(spawnRotations[i]);
							sp.numberOfObjects = sp.numberOfObjects+1;
							
							
        				    
        				    
        					
        				}
        				
        				sp.isLocked = false;
        				
        				for(int i=0;i<projectorFixed.Count;i++){
        					Destroy(projectorFixed[i].gameObject);
        					
        				}
        				
        				
        				projectorFixed.Clear();
        				spawnLocations.Clear();
        				spawnRotations.Clear();
        				
        				
        				projector.SetActive(false);
        				this.enabled = false;
        				
        			}
        		}
        	// if regular building made in single click	
        		else{
        			BuildBuilding(hit.point);
        			
        		// mines resources	
        			
        		}
        		
        	}
        }
        else if(Input.GetMouseButtonDown(1)){
        	projector.SetActive(false);
        	this.enabled = false;
        	if(nLeftClicks == 1){
        		for(int i=0;i<projectorFixed.Count;i++){
					Destroy(projectorFixed[i].gameObject);
				}
        	}
        }
        
        
        if(nLeftClicks == 1){
            int nProjectorFixed = projectorFixed.Count;
        	if(
        		(projectorFixed[nProjectorFixed-1].transform.position - projector.transform.position).sqrMagnitude
        		>
        		rEnclosed*rEnclosed
        		
        	  ){
        			
        			
        			spawnLocations.Add(hit.point);
        			spawnRotations.Add(Quaternion.LookRotation(projectorFixed[nProjectorFixed-1].transform.position - projector.transform.position));
        			projectorFixed.Add((GameObject)Instantiate(projector, projector.transform.position, projector.transform.rotation));
        			
        	}
        }
        
        
        
  //      print(ter.terrainData.GetSteepness(ttx, ttz));
        
	}
	
	void BuildBuilding(Vector3 pos){
		        sp.isManualPosition = true;
        		sp.manualPosition.Add(pos);
        		sp.manualRotation.Add(Quaternion.Euler( 0f, Random.Range(0f, 360f) , 0f));
        		sp.numberOfObjects = 1;
        		sp.model = objectToSpawn;
        		sp.isLocked = false;
        		
        		projector.SetActive(false);
        		this.enabled = false;

	}
}
