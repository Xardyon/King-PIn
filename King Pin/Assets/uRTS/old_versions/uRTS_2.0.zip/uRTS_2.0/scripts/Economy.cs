﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;




public class Economy : MonoBehaviour {
    public List<int> iron = new List<int>();
    public List<int> gold = new List<int>();
    public List<int> lumber = new List<int>();
    public List<int> population = new List<int>();
    
    [HideInInspector] public Text textIron = null;
    [HideInInspector] public Text textGold = null;
    [HideInInspector] public Text textLumber = null;
    [HideInInspector] public Text textPopulation = null;
    
    [HideInInspector] public Diplomacy dip = null;
    [HideInInspector] public int numNations = 0;
    
    private RTSMaster rtsm = null;
    
    private List<int> populationDifference = new List<int>();
    
    
    
    void Awake(){
    	rtsm = GameObject.Find("RTS Master").GetComponent<RTSMaster>();
    	rtsm.economy = this;
    }
    
	// Use this for initialization
	void Start () {
		
		dip = GameObject.Find("Terrain").GetComponent<Diplomacy>();
		numNations = dip.numberNations;
	    
	    for(int i=0;i<numNations;i++){
			iron.Add(20000);
			gold.Add(40000);
			lumber.Add(20000);
			population.Add(1500);
			populationDifference.Add(0);
		}
		
		StartCoroutine(UpdateTaxes());
		StartCoroutine(IncreasePopulation());
		
		
	}
	
	
	IEnumerator UpdateTaxes(){
		while(
			(textIron == null)&&
			(textGold == null)&&
			(textLumber == null)
		){
			yield return new WaitForSeconds(0.2f);
		}
		
		while(true){
		    for(int i=0;i<numNations;i++){
		        populationDifference[i] = population[i] - (rtsm.numberOfUnitTypes[i][11]+rtsm.numberOfUnitTypes[i][12]);
		        
				iron[i] = iron[i] + populationDifference[i];
				gold[i] = gold[i] + 2*populationDifference[i];
				lumber[i] = lumber[i] + populationDifference[i];
			}
			
			if(
				(textIron != null)&&
				(textGold != null)&&
				(textLumber != null)
			){
				textIron.text = iron[0].ToString();
				textGold.text = gold[0].ToString();
				textLumber.text = lumber[0].ToString();
			}
			
		
		
			yield return new WaitForSeconds(90f);
		}
	}
	
	IEnumerator IncreasePopulation(){
	    while(
			(textPopulation == null)
		){
			yield return new WaitForSeconds(0.2f);
		}
		
	    while(true){
	        for(int i=0;i<numNations;i++){
	            if(population[i] < (5*rtsm.numberOfUnitTypes[i][3]+20)){
					population[i] = population[i]+1;
				}
				populationDifference[i] = population[i] - (rtsm.numberOfUnitTypes[i][11]+rtsm.numberOfUnitTypes[i][12]);
			}
			
			if((textPopulation != null)){
				textPopulation.text = population[0].ToString();
				if(populationDifference[0] < 0){
					textPopulation.color = new Color(0.79f,0.22f,0.22f,1f);
				}
				else{
					textPopulation.color = new Color(0.61f,0.50f,0.13f,1f);
				}
			}
		
			yield return new WaitForSeconds(3f);
		}
	}
	
	
	
}
