﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;


public class FbLogin : MonoBehaviour {

    public GameObject UIFBIsLoggedIn;
    public GameObject UIFBNotLoggedIn;
    public GameObject UIFBAvatar;
    public GameObject UIFBUserName;
    
    private Dictionary<string, string> profile = null;
    
    void Awake(){
		FB.Init(SetInit, OnHideUnity);
    }
    
    
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	private void SetInit()                                                                       
	{                                                                                            
	//	Debug.Log("FB Init done");                                                                  
		              
		if (FB.IsLoggedIn)                                                                       
		{           
		    DealWithFBMenus(true);                                                                             
			Debug.Log("Already logged in");                                                    
			                                                                      
		}   
		else{
			DealWithFBMenus(false);   
		//	FBlogin();
		}                                                                                     
	}                                                                                            

	private void OnHideUnity(bool isGameShown)                                                   
	{                                                                                            
		                                                          
		if (!isGameShown)                                                                        
		{                                                                                        
			                                     
			Time.timeScale = 0;                                                                  
		}                                                                                        
		else                                                                                     
		{                                                                                        
			                              
			Time.timeScale = 1;                                                                  
		}                                                                                        
	}
	
	public void FBlogin(){
		FB.Login("email", AuthCallback);
	}
	
	void AuthCallback(FBResult result){
		if(FB.IsLoggedIn){
	//		Debug.Log("FB Login worked");
			DealWithFBMenus(true);
		}
		else{
			Debug.Log("FB Login fail");
			DealWithFBMenus(false);
		}
	}
	
	void DealWithFBMenus(bool isLoggedIn){
		if(isLoggedIn){
			UIFBIsLoggedIn.SetActive(true);
			UIFBNotLoggedIn.SetActive(false);
			
			FB.API (Util.GetPictureURL("me", 128, 128), Facebook.HttpMethod.GET, DealWithProfilePicture);
			FB.API ("/me?fields=id,first_name", Facebook.HttpMethod.GET, DealWithUserName);
		}
		else{
			UIFBIsLoggedIn.SetActive(false);
			UIFBNotLoggedIn.SetActive(true);
		}
		
	}
	
	void DealWithProfilePicture(FBResult result){
		
		if(result.Error != null){
			Debug.Log("problem with getting profile picture");
			
			FB.API (Util.GetPictureURL("me", 128, 128), Facebook.HttpMethod.GET, DealWithProfilePicture);
			return;
		}
		
		Image UserAvatar = UIFBAvatar.GetComponent<Image>();
		UserAvatar.sprite = Sprite.Create (result.Texture, new Rect(0,0,128,128), new Vector2(0,0));
		
	}
	
	void DealWithUserName(FBResult result){
		if(result.Error != null){
			Debug.Log("problem with getting profile name");
			
			FB.API ("/me?fields=id,first_name", Facebook.HttpMethod.GET, DealWithUserName);
			return;
		}
		profile = Util.DeserializeJSONProfile(result.Text);
		
		Text UserMsg = UIFBUserName.GetComponent<Text>();
		UserMsg.text = "Hello, " + profile["first_name"];
	}
	
	public void ShareWithFriends(){
		FB.Feed (
			
			linkCaption: "Why not check out yourself what's happening in the Lands of Eightrivers?",
			picture: "https://dl.dropboxusercontent.com/u/248943005/toer/aa_s.png",
			linkName: "Eightrivers has interesting tales to tell",
			link: "http://apps.facebook.com" + FB.AppId + "/?challenge_brag=" + (FB.IsLoggedIn ? FB.UserId : "guest")
			
		);
	}
	
	public void InviteFriends(){
		FB.AppRequest(
			message: "Hey, try out this game",
			title: "Invite your friends to join you"
		);
	}
	
	
}
