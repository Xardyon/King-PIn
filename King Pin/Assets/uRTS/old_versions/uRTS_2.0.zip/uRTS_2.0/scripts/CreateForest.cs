﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CreateForest : MonoBehaviour {

[HideInInspector] public GameObject model;

[HideInInspector] public bool readynow = true;
[HideInInspector] public float timestep = 0.01f;
[HideInInspector] public int count = 0;
public int numberOfPlants = 10000;
[HideInInspector] public float size = 1.0f;

[HideInInspector] public int nation = 1;


[HideInInspector] public bool addToBS = true;

private GameObject objTerrain;

private Terrain terrain = null;

public Texture2D bark = null;
public Texture2D leaf = null;
public Texture2D leafBack = null;

private RTSMaster rtsm = null;

[HideInInspector] public List<TreeInstance> treeList = new List<TreeInstance>();

[HideInInspector] public List<Vector3> treePos2D = new List<Vector3>();
private KDTree kd_treePos2D = null;



void Awake(){
	rtsm = GameObject.Find("RTS Master").GetComponent<RTSMaster>();
    rtsm.createForest = this;
}

void Starter() {

}

void Start () {

	SpawnTrees();

//	StartCoroutine(MakeBox());
}





void SpawnTrees(){
    if( !terrain ){
		terrain = Terrain.activeTerrain;
	}
	
	int nPrototypes = 1;
	
	TreePrototype[] tps = new TreePrototype[nPrototypes];
	for(int i=0; i<nPrototypes; i++) {
		tps[i] = new TreePrototype();
		
	}
	
//	terrain.terrainData.treePrototypes;

	bark = Resources.Load<Texture2D>("trees/Spruce/Bark_Tex");
    leaf = Resources.Load<Texture2D>("trees/Spruce/Leaf_Tex");
    leafBack = Resources.Load<Texture2D>("trees/Spruce/LeafBack_Tex");
    

    bark.mipMapBias = -0.5f;
    leaf.mipMapBias = -10.5f;
    leafBack.mipMapBias = -10.5f;
    
    
    Mesh mesh0 = Resources.Load<Mesh>("trees/Spruce/Spruce Part 0_M");
//    Mesh mesh1 = Resources.Load<Mesh>("treeMeshes/Leaf Part 0_M");
//    Mesh mesh2 = Resources.Load<Mesh>("treeMeshes/LeafBack Part 0_M");
    
//	TangentSolver(mesh0);
//	TangentSolver(mesh1);
//	TangentSolver(mesh2);
    

	
	tps[0].prefab = new GameObject("Spruce");
//	Resources.Load<GameObject>("trees/Spruce/Spruce Part 0");
//	tps[1].prefab = Resources.Load<GameObject>("treeMeshes/Leaf Part 0");
//	tps[2].prefab = Resources.Load<GameObject>("treeMeshes/LeafBack Part 0");
	
	
	tps[0].prefab.AddComponent<MeshFilter>().mesh = mesh0;
//	tps[1].prefab.GetComponent<MeshFilter>().mesh = mesh1;
//	tps[2].prefab.GetComponent<MeshFilter>().mesh = mesh2;
	
	
	Material mat = Resources.Load<Material>("treeMeshes/Leaf_Mat");
	List<Material> mats = new List<Material>();
	
	mats.Add(Resources.Load<Material>("trees/Spruce/Spruce_Mat"));
	mats.Add(Resources.Load<Material>("trees/Spruce/_leaf_Mat"));
	mats.Add(Resources.Load<Material>("trees/Spruce/_leafBack_Mat"));
	
	
	mats[0].mainTexture = bark;
	mats[1].mainTexture = leaf;
	mats[2].mainTexture = leafBack;
	
	
//	mat.mainTexture.mipMapBias = 10.5f;
	tps[0].prefab.AddComponent<MeshRenderer>().materials = mats.ToArray();
	
	
//	mat = Resources.Load<Material>("treeMeshes/Leaf_Mat");
//	mat.mainTexture.mipMapBias = 10.5f;
//	tps[2].prefab.GetComponent<MeshRenderer>().material = Resources.Load<Material>("treeMeshes/LeafBack_Mat");
	
	
//	tps[1].prefab.GetComponent<MeshRenderer>().material.mainTexture.mipMapBias = 0.5f;
//	tps[2].prefab.GetComponent<MeshRenderer>().material.mainTexture.mipMapBias = 0.5f;
	
	terrain.terrainData.treePrototypes = tps;
	
	
	
	
	Color cl1 = new Color(0.8f,0.8f,0.8f,1f);
	Color cl2 = new Color(0.6f,0.6f,0.6f,1f);
	Color cl3 = new Color(0.4f,0.4f,0.4f,1f);
	
	int baseRes = terrain.terrainData.baseMapResolution;
	
	PerlinNoise pnoise = new PerlinNoise();
	float[][] pn = pnoise.GeneratePerlinNoise(baseRes, baseRes, 8);
	
	
	
	int kk = 0;
	for(int i=0; i<numberOfPlants; i++){
	
	    float rand1 = Random.Range(0f,1f);
 		float rand2 = Random.Range(0f,1f);
 		
 		float rand3 = Random.Range(-1f,1f);
 		
 		int ix = (int)(rand1*baseRes);
 		int iz = (int)(rand2*baseRes);
 		
 		
 		if(pn[ix][iz]>0.5f){
 		    kk = kk+1;
			float height = Terrain.activeTerrain.SampleHeight(new Vector3(rand1*terrain.terrainData.size.x,0f,rand2*terrain.terrainData.size.x));
		    
		    

			Vector3 treePos = new Vector3(rand1,(height-1f)/terrain.terrainData.size.y,rand2);
			
			
			Vector3 new_treePos2D = new Vector3(rand1*terrain.terrainData.size.x,0f,rand2*terrain.terrainData.size.x);
			
			
			if(kk<2){
			
				treePos2D.Add(new Vector3(rand1*terrain.terrainData.size.x,0f,rand2*terrain.terrainData.size.x));
			
			
			
			
				rtsm.resourcesCollection.treePositions.Add(new Vector3(rand1*terrain.terrainData.size.x,(height-1f),rand2*terrain.terrainData.size.x));
				rtsm.resourcesCollection.treeHealth.Add(500);
		
				for(int j=0; j<nPrototypes; j++) {
					TreeInstance tree = new TreeInstance();
					tree.color = cl1;
					tree.heightScale    = 0.5f+0.025f*rand3;
					if(j==0){
						tree.lightmapColor  = cl2;
					}
					else{
						tree.lightmapColor  = cl3;
					}
					tree.position       = treePos;
					tree.prototypeIndex = j;
					tree.widthScale     = 0.5f+0.025f*rand3;
					treeList.Add(tree);
				}
			}
			else{
			    kd_treePos2D = KDTree.MakeFromPoints(treePos2D.ToArray());
			    int neighId = kd_treePos2D.FindNearest(new_treePos2D,1);
			    
				if((treePos2D[neighId]-new_treePos2D).sqrMagnitude > 90f)
				{
							
					treePos2D.Add(new Vector3(rand1*terrain.terrainData.size.x,0f,rand2*terrain.terrainData.size.x));
			
			
			
			
					rtsm.resourcesCollection.treePositions.Add(new Vector3(rand1*terrain.terrainData.size.x,(height-1f),rand2*terrain.terrainData.size.x));
					rtsm.resourcesCollection.treeHealth.Add(500);
		
					for(int j=0; j<nPrototypes; j++) {
						TreeInstance tree = new TreeInstance();
						tree.color = cl1;
						tree.heightScale    = 0.5f+0.025f*rand3;
						if(j==0){
							tree.lightmapColor  = cl2;
						}
						else{
							tree.lightmapColor  = cl3;
						}
						tree.position       = treePos;
						tree.prototypeIndex = j;
						tree.widthScale     = 0.5f+0.025f*rand3;
						treeList.Add(tree);
					}

				}
			}
     	}
	}
	
	
	terrain.terrainData.treeInstances = new TreeInstance[ treeList.Count ];
	terrain.terrainData.treeInstances = treeList.ToArray();
	
	
	rtsm.resourcesCollection.kd_treePositions = KDTree.MakeFromPoints(rtsm.resourcesCollection.treePositions.ToArray());
	
}


public void RefreshTrees(){
	terrain.terrainData.treeInstances = new TreeInstance[ treeList.Count ];
	terrain.terrainData.treeInstances = treeList.ToArray();
	
	rtsm.resourcesCollection.kd_treePositions = KDTree.MakeFromPoints(rtsm.resourcesCollection.treePositions.ToArray());

}















 





private static void TangentSolver(Mesh theMesh)
     {
         int vertexCount = theMesh.vertexCount;
         Vector3[] vertices = theMesh.vertices;
         Vector3[] normals = theMesh.normals;
         Vector2[] texcoords = theMesh.uv;
         int[] triangles = theMesh.triangles;
         int triangleCount = triangles.Length / 3;
         Vector4[] tangents = new Vector4[vertexCount];
         Vector3[] tan1 = new Vector3[vertexCount];
         Vector3[] tan2 = new Vector3[vertexCount];
         int tri = 0;
         for (int i = 0; i < (triangleCount); i++)
         {
             int i1 = triangles[tri];
             int i2 = triangles[tri + 1];
             int i3 = triangles[tri + 2];
 
             Vector3 v1 = vertices[i1];
             Vector3 v2 = vertices[i2];
             Vector3 v3 = vertices[i3];
 
             Vector2 w1 = texcoords[i1];
             Vector2 w2 = texcoords[i2];
             Vector2 w3 = texcoords[i3];
 
             float x1 = v2.x - v1.x;
             float x2 = v3.x - v1.x;
             float y1 = v2.y - v1.y;
             float y2 = v3.y - v1.y;
             float z1 = v2.z - v1.z;
             float z2 = v3.z - v1.z;
 
             float s1 = w2.x - w1.x;
             float s2 = w3.x - w1.x;
             float t1 = w2.y - w1.y;
             float t2 = w3.y - w1.y;
 
             float r = 1.0f / (s1 * t2 - s2 * t1);
             Vector3 sdir = new Vector3((t2 * x1 - t1 * x2) * r, (t2 * y1 - t1 * y2) * r, (t2 * z1 - t1 * z2) * r);
             Vector3 tdir = new Vector3((s1 * x2 - s2 * x1) * r, (s1 * y2 - s2 * y1) * r, (s1 * z2 - s2 * z1) * r);
 
             tan1[i1] += sdir;
             tan1[i2] += sdir;
             tan1[i3] += sdir;
 
             tan2[i1] += tdir;
             tan2[i2] += tdir;
             tan2[i3] += tdir;
 
             tri += 3;
         }
 
         for (int i = 0; i < (vertexCount); i++)
         {
             Vector3 n = normals[i];
             Vector3 t = tan1[i];
 
             // Gram-Schmidt orthogonalize
             Vector3.OrthoNormalize(ref n, ref t);
 
             tangents[i].x = t.x;
             tangents[i].y = t.y;
             tangents[i].z = t.z;
 
             // Calculate handedness
             tangents[i].w = 1f;
             //-Vector3.Dot(Vector3.Cross(n, t), tan2[i]);
             //!(Vector3.Dot(Vector3.Cross(n, t), tan2[i]) < 0.0) ? -1.0f : 1.0f;
         }
         theMesh.tangents = tangents;
     }



}