﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ReturnObject : MonoBehaviour {
    
    Economy ec = null;
    
	// Use this for initialization
	void Start () {
		ec = GameObject.Find("Terrain").GetComponent<Economy>();
		
		if(this.gameObject.name == "TextIron"){
			ec.textIron = this.gameObject.GetComponent<Text>();
		}
		else if(this.gameObject.name == "TextGold"){
			ec.textGold = this.gameObject.GetComponent<Text>();
		}
		else if(this.gameObject.name == "TextWood"){
			ec.textLumber = this.gameObject.GetComponent<Text>();
		}
		else if(this.gameObject.name == "TextPopulation"){
			ec.textPopulation = this.gameObject.GetComponent<Text>();
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
