﻿using UnityEngine;
using System.Collections;

public class UIGameObjects : MonoBehaviour {
  //  public GameObject 
	// Use this for initialization
	void Start () {
	
	}
	
	
}
