﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ScrollCountController : MonoBehaviour {
	public int counter = 1;
	
	private Text txt = null;
	public SpawnPoint spawner = null;
	
	public GameObject model = null;
	
	// Use this for initialization
	void Start () {
		counter = 1;
		txt = this.gameObject.GetComponent<Text>();
		if(txt != null){
			txt.text = counter.ToString();
		}
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetAxis("Mouse ScrollWheel")> 0){
			counter = counter+1;
			if(counter>255){
				counter = 1;
			}
			
			if(txt != null){
				txt.text = counter.ToString();
			}
			
		}
		
		if (Input.GetAxis("Mouse ScrollWheel")< 0){
		    counter = counter-1;
			if(counter<1){
				counter = 255;
			}
			
			if(txt != null){
				txt.text = counter.ToString();
			}
		}
	}
	
	
	public void StartSpawnng(){
		spawner = GameObject.Find("Terrain").GetComponent<SelectionMark>().selectedGoPars[0].gameObject.GetComponent<SpawnPoint>();
		if(spawner != null){
			spawner.numberOfObjects = counter;
			spawner.isLocked = false;
			if(model != null){
				spawner.model = model;
			}
		}
		counter = 1;
		if(txt != null){
			txt.text = counter.ToString();
		}
		spawner = null;
	}
	
}
