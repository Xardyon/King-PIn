﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
//using UnityEngine.Events;
//using UnityEngine.EventSystems;

public class BuildDiplomacyMenu : MonoBehaviour {

    private GameObject mainCanvas = null;
    private GameObject diplomacyButton = null;
    private GameObject diplomacyMenu = null;
    
    private List<GameObject> diplomacy_Nations_List = new List<GameObject>();
    private List<GameObject> nation_Menu_Options_List = new List<GameObject>();
    private List<GameObject> text_nation_Menu_Options_List = new List<GameObject>();
    
    
    private string war_Option_String = ", prepare to die";
    private string peace_Option_String = "Lets live in peace, ";
    
    
    public Diplomacy dip = null;
    public RTSMaster rtsm = null;
    
    private int numberNations = 0;
    private int playerNation = 0;
    
    private int jj = 0;
    
    private CameraOperator camop = null;
    private RTSCamera rtscam = null;
    
 //   private EventTrigger eventTrigger = null;
    
//    [SerializeField]
//    private CameraOperator camopS = null;
    
    public GameObject activeScreenG = null;
    
//     public GameObject knightModel = null;
//     public GameObject archerModel = null;
    
    [HideInInspector] public List<GameObject> models = new List<GameObject>();
    
    [HideInInspector] public List<GameObject> building_models = new List<GameObject>();
    [HideInInspector] public List<GameObject> factory_models = new List<GameObject>();
    
    
    private BuildMark bm = null;
    
    [HideInInspector] public List<List<GameObject>> pMenus_in = new List<List<GameObject>>();
 	private List<List<Button>> bt_pMenus_in = new List<List<Button>>();
 	
 	[HideInInspector] public List<List<GameObject>> pMenus_out = new List<List<GameObject>>();
 	private List<List<Button>> bt_pMenus_out = new List<List<Button>>();
 	
 	private List<GameObject> list_uPropMenus = new List<GameObject>();
 	private List<Button> list_bt_propButtonIn = new List<Button>();
 	private List<Button> list_bt_propButtonOut = new List<Button>();
 	
 	private List<GameObject> list_bCounter = new List<GameObject>();

    
    
	// Use this for initialization
	void Start () {
	    bm = GameObject.Find("Terrain").GetComponent<BuildMark>();
	    rtsm = GameObject.Find("RTS Master").GetComponent<RTSMaster>();
	    
	    
	    rtsm.buildDiplomacyMenu = this;
	    
	//    models.Add(knightModel);
	//    models.Add(archerModel);
	    
	    building_models = new List<GameObject>();
	    building_models.Add(rtsm.rtsUnitTypePrefabs[15]);
	    for(int i=0;i<8;i++){
	    	building_models.Add(rtsm.rtsUnitTypePrefabs[i+1]);
	    }
	    for(int i=0;i<2;i++){
	    	factory_models.Add(rtsm.rtsUnitTypePrefabs[i+9]);
	    }
	    for(int i=0;i<4;i++){
	    	models.Add(rtsm.rtsUnitTypePrefabs[i+11]);
	    }
	    
		BuildMenu();
		
		
		
		string[] icons = new string[4];
		icons[0] = "archer_ico";
		icons[1] = "swordsman_ico";
		icons[2] = "archer_ico";
		icons[3] = "knight_ico";
		
		
		
		BuildingPropertiesMenu(icons,1,2);
		
//		AddBuildingPropertiesMenuItem(models[0], icons[0], 2, 1);
//		AddBuildingPropertiesMenuItem(models[3], icons[3], 3, 1);
		
		string[] building_icons = new string[9];
		
		building_icons[0] = "worker_ico";
		
		building_icons[1] = "barracks_ico";
		building_icons[2] = "sawmill_ico";
		building_icons[3] = "farm_ico";
		building_icons[4] = "laboratory_ico";
		building_icons[5] = "mine_ico";
		building_icons[6] = "factory_ico";
		building_icons[7] = "stables_ico";
		building_icons[8] = "windmill_ico";
		
		
		
		BuildingPropertiesMenu(building_icons,2,1);
		
		string[] factory_icons = new string[2];
		factory_icons[0] = "fence_ico";
		factory_icons[1] = "tower_ico";
		
		BuildingPropertiesMenu(factory_icons,3,2);
		
// 		BuildingPropertiesMenu(building_icons,3,6);
// 		BuildingPropertiesMenu(building_icons,4,7);
// 		BuildingPropertiesMenu(building_icons,5,8);
		
	//	AddBuildingPropertiesMenuItem(building_icons[2], 2, 2);
		AddBuildingPropertiesMenuItem(building_models[1], building_icons[1], 0, 2);
		AddBuildingPropertiesMenuItem(building_models[2], building_icons[2], 1, 2);
		AddBuildingPropertiesMenuItem(building_models[3], building_icons[3], 2, 2);
		AddBuildingPropertiesMenuItem(building_models[4], building_icons[4], 3, 2);
		AddBuildingPropertiesMenuItem(building_models[5], building_icons[5], 4, 2);
		
		
		
		BuildingMineLabel();
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void BuildMenu(){
	    dip = GameObject.Find("Terrain").GetComponent<Diplomacy>();
	    
	    numberNations = dip.numberNations;
	    playerNation = dip.playerNation;
		mainCanvas = this.gameObject;
		
		
		diplomacyButton = new GameObject("DiplomacyButton");
		AddChild(diplomacyButton, mainCanvas);
		RectTransform rt_diplomacyButton = diplomacyButton.AddComponent<RectTransform>();
		
		diplomacyButton.layer = LayerMask.NameToLayer("UI");
		
		rt_diplomacyButton.anchorMin = new Vector2(1f,0f);
		rt_diplomacyButton.anchorMax = new Vector2(1f,0f);
		
		rt_diplomacyButton.anchoredPosition = new Vector2(-83.5f,15f);
		rt_diplomacyButton.sizeDelta = new Vector2(162.5f,29f);
		
		
		diplomacyButton.AddComponent<CanvasRenderer>();
		
		Image im_diplomacyButton = diplomacyButton.AddComponent<Image>();
		Button but_diplomacyButton = diplomacyButton.AddComponent<Button>();
		
		im_diplomacyButton.color = new Color(0.23f,0.11f,0.0f,1f);
		
		
		
		GameObject text_diplomacyButton = new GameObject("Text");
		text_diplomacyButton.layer = LayerMask.NameToLayer("UI");
		AddChild(text_diplomacyButton, diplomacyButton);
		RectTransform rt_text_diplomacyButton = text_diplomacyButton.AddComponent<RectTransform>();
		
		rt_text_diplomacyButton.anchorMin = new Vector2(0f,0f);
		rt_text_diplomacyButton.anchorMax = new Vector2(1f,1f);
		
		rt_text_diplomacyButton.offsetMin = new Vector2(0f,0f);
		rt_text_diplomacyButton.offsetMax = new Vector2(0f,0f);
		
		text_diplomacyButton.AddComponent<CanvasRenderer>();
		
		Text tx_text_diplomacyButton = text_diplomacyButton.AddComponent<Text>();
		
		tx_text_diplomacyButton.text = "Diplomacy";
		
		tx_text_diplomacyButton.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		tx_text_diplomacyButton.alignment = TextAnchor.MiddleCenter;
		tx_text_diplomacyButton.color = new Color(0.61f,0.50f,0.13f,1f);
		
		
		
		
		
		
		diplomacyMenu = new GameObject("DiplomacyMenu");
		AddChild(diplomacyMenu, mainCanvas);
		RectTransform rt_diplomacyMenu = diplomacyMenu.AddComponent<RectTransform>();
		
		
		diplomacyMenu.layer = LayerMask.NameToLayer("UI");
		

		rt_diplomacyMenu.anchorMin = new Vector2(0f,0f);
		rt_diplomacyMenu.anchorMax = new Vector2(1f,1f);
		
		rt_diplomacyMenu.offsetMin = new Vector2(0f,0f);
		rt_diplomacyMenu.offsetMax = new Vector2(0f,0f);
		
		diplomacyMenu.AddComponent<UIPingPong>();
		
		GameObject curNation = null;
		GameObject butText = null;
		
		int ii = 0;
		for(int i=0;i<numberNations;i++){
			if((i+1)!=playerNation){
				diplomacy_Nations_List.Add(new GameObject("Nation"+(i+1).ToString()));
				AddChild(diplomacy_Nations_List[ii], diplomacyMenu);
			
				curNation = diplomacy_Nations_List[ii];
			
				curNation.layer = LayerMask.NameToLayer("UI");
				RectTransform rt_curNation = curNation.AddComponent<RectTransform>();
			
				rt_curNation.anchorMin = new Vector2(0f,1f);
				rt_curNation.anchorMax = new Vector2(0f,1f);
			
				rt_curNation.anchoredPosition = new Vector2(164f+263f*ii,-92f);
				rt_curNation.sizeDelta = new Vector2(50f,50f);
			
				curNation.AddComponent<CanvasRenderer>();
			
				Image im = curNation.AddComponent<Image>();
				curNation.AddComponent<Button>();
				curNation.AddComponent<UIPingPong>();
			
				curNation.GetComponent<UIPingPong>().helpInteger1 = i+1;
			
				im.sprite = Resources.Load<Sprite>("textures/faces/"+(i+1).ToString());
			
			
			
			
			
				butText = new GameObject("Text");
				butText.layer = LayerMask.NameToLayer("UI");
				AddChild(butText, curNation);
				RectTransform rt_butText = butText.AddComponent<RectTransform>();
			
				rt_butText.anchorMin = new Vector2(0f,0f);
				rt_butText.anchorMax = new Vector2(1f,1f);
			
				rt_butText.offsetMin = new Vector2(0f,-20f);
				rt_butText.offsetMax = new Vector2(0f,-50f);
			
				butText.AddComponent<CanvasRenderer>();
			
				Text tx = butText.AddComponent<Text>();
			
				tx.text = (i+1).ToString();
			
				tx.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
				tx.alignment = TextAnchor.MiddleCenter;
				tx.color = new Color(0.61f,0.50f,0.13f,1f);
				
				ii++;
			
			}
			
			
			
			
			
			
			
			

			
			
		}
		
		
		GameObject nationMenu = new GameObject("NationMenu");
		AddChild(nationMenu, diplomacyMenu);
		RectTransform rt_nationMenu = nationMenu.AddComponent<RectTransform>();
	
	
		nationMenu.layer = LayerMask.NameToLayer("UI");
	

		rt_nationMenu.anchorMin = new Vector2(0f,0f);
		rt_nationMenu.anchorMax = new Vector2(1f,1f);
	
		rt_nationMenu.offsetMin = new Vector2(0f,0f);
		rt_nationMenu.offsetMax = new Vector2(0f,0f);
	
		nationMenu.AddComponent<UIPingPong>();
		
		
		
		
		for(int i=0;i<3;i++){
		
			string goName = null;
			string textString = null;
			
			if(i==0){
				goName = "GoUp";
				textString = "Back";
			}
			else if(i==1){
				goName = "War";
				textString = "Prepare to die";
			}
			else if(i==2){
				goName = "Peace";
				textString = "Let's live in peace";
			}
		
		
			GameObject goUp = new GameObject(goName);
			nation_Menu_Options_List.Add(goUp);
			AddChild(goUp, nationMenu);
			
			
			goUp.layer = LayerMask.NameToLayer("UI");
			RectTransform rt_goUp = goUp.AddComponent<RectTransform>();
			
			rt_goUp.anchorMin = new Vector2(0f,0.5f);
			rt_goUp.anchorMax = new Vector2(0f,0.5f);
			
			rt_goUp.anchoredPosition = new Vector2(102f,36f-30f*i);
			rt_goUp.sizeDelta = new Vector2(160f,30f);
		
			goUp.AddComponent<CanvasRenderer>();
		
			Image im2 = goUp.AddComponent<Image>();
			im2.enabled = false;
			Button but2 = goUp.AddComponent<Button>();
		//	UIPingPong ping = curNation.AddComponent<UIPingPong>();
		
		//	im2.sprite = Resources.Load<Sprite>("textures/faces/"+(i+1).ToString());
		
		    if(i==0){
		        jj=0;
		        for(int j=0;j<numberNations;j++){
					if((j+1)!=playerNation){
						GameObject tGo = diplomacy_Nations_List[jj];
						but2.onClick.AddListener(delegate {
							tGo.GetComponent<UIPingPong>().Activate();
						});
				        jj++;
					}	
    			}
    			but2.onClick.AddListener(delegate {
						nationMenu.GetComponent<UIPingPong>().DeActivate();
				});
		    }

		    if(i==1){
		        jj=0;
		        for(int j=0;j<numberNations;j++){
					if((j+1)!=playerNation){
						GameObject tGo = diplomacy_Nations_List[jj];
						but2.onClick.AddListener(delegate {
							tGo.GetComponent<UIPingPong>().Activate();
						});
				        jj++;
					}	
    			}
    			but2.onClick.AddListener(delegate {
						nationMenu.GetComponent<UIPingPong>().DeActivate();
				});
				
				but2.onClick.AddListener(delegate {
						diplomacyMenu.GetComponent<UIPingPong>().DeActivate();
						this.SetWar(1, diplomacyMenu.GetComponent<UIPingPong>().helpInteger1);
				});
				
				
		    }

		    if(i==2){
		        jj=0;
		        for(int j=0;j<numberNations;j++){
					if((j+1)!=playerNation){
						GameObject tGo = diplomacy_Nations_List[jj];
						but2.onClick.AddListener(delegate {
							tGo.GetComponent<UIPingPong>().Activate();
						});
						jj++;
					}	
    			}
    			but2.onClick.AddListener(delegate {
						nationMenu.GetComponent<UIPingPong>().DeActivate();
				});
				
				but2.onClick.AddListener(delegate {
						diplomacyMenu.GetComponent<UIPingPong>().DeActivate();
						this.SetPeace(1, diplomacyMenu.GetComponent<UIPingPong>().helpInteger1);
				});
				
				
		    }
			
			
			
			
			GameObject butText2 = new GameObject("Text");
			text_nation_Menu_Options_List.Add(butText2);
			butText2.layer = LayerMask.NameToLayer("UI");
			AddChild(butText2, goUp);
			RectTransform rt_butText2 = butText2.AddComponent<RectTransform>();
			
			rt_butText2.anchorMin = new Vector2(0f,0f);
		    rt_butText2.anchorMax = new Vector2(1f,1f);
		    
			rt_butText2.offsetMin = new Vector2(0f,0f);
			rt_butText2.offsetMax = new Vector2(300f,0f);
			
			butText2.AddComponent<CanvasRenderer>();
			
			Text tx2 = butText2.AddComponent<Text>();
			
			tx2.text = textString;
			
			tx2.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
			tx2.alignment = TextAnchor.MiddleCenter;
			tx2.color = new Color(0.61f,0.50f,0.13f,1f);

			
		
		}
	
	
		
////////////////////////////////////////////////////////////////////		
////////////////////////////////////////////////////////////////////	
//// Adding functionality //////////////////////////////////////////
////////////////////////////////////////////////////////////////////			
		
		
		
		but_diplomacyButton.onClick.AddListener(delegate {
			diplomacyMenu.GetComponent<UIPingPong>().PingPong();
		});
		
		jj=0;
		for(int j=0;j<numberNations;j++){
			if((j+1)!=playerNation){
				GameObject tGo = diplomacy_Nations_List[jj];
				but_diplomacyButton.onClick.AddListener(delegate {
					tGo.GetComponent<UIPingPong>().Activate();
				});
			    jj++;
			}
		}
		
		but_diplomacyButton.onClick.AddListener(delegate {
			nationMenu.GetComponent<UIPingPong>().DeActivate();
		});
		
		
		
		
		jj=0;
		for(int j=0;j<numberNations;j++){
			if((j+1)!=playerNation){
				GameObject ttGo = diplomacy_Nations_List[jj];
				Button tButt = diplomacy_Nations_List[jj].GetComponent<Button>();
				tButt.onClick.AddListener(delegate {
					nationMenu.GetComponent<UIPingPong>().Activate();
				});
			
				Text textW = text_nation_Menu_Options_List[1].GetComponent<Text>();
				tButt.onClick.AddListener(delegate {
					textW.text = (ttGo.GetComponent<UIPingPong>().helpInteger1).ToString()+war_Option_String;
					diplomacyMenu.GetComponent<UIPingPong>().helpInteger1 = ttGo.GetComponent<UIPingPong>().helpInteger1;
				//	this.SetWar(1, ttGo.GetComponent<UIPingPong>().helpInteger1);
				
				});
			
				Text textP = text_nation_Menu_Options_List[2].GetComponent<Text>();
				tButt.onClick.AddListener(delegate {
					textP.text = peace_Option_String+(ttGo.GetComponent<UIPingPong>().helpInteger1).ToString();
				//	this.SetPeace(1, ttGo.GetComponent<UIPingPong>().helpInteger1);
				});
			    int kk = 0;
				for(int k=0;k<numberNations;k++){
					if((k+1)!=playerNation){
						GameObject tGo = diplomacy_Nations_List[kk];
						tButt.onClick.AddListener(delegate {
							tGo.GetComponent<UIPingPong>().DeActivate();
						});
						kk++;
					}
					
				}
				jj++;
			}
		}
		
		
		
		diplomacyMenu.SetActive(false);
		

		
		
		
		
	}
	
	
	void BuildingMineLabel(){
		GameObject mineLabel = new GameObject("mineLabel");
		AddButton(
			ref mineLabel,
			ref mainCanvas,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,-0.5f),
			2
			
		);
		mineLabel.AddComponent<CanvasRenderer>();
		
		GameObject mineLabelIn = new GameObject("mineLabelIn");
		mineLabel.SetActive(false);
		camop.unitPropertiesButton.Add(mineLabel);
		AddButton(
			ref mineLabelIn,
			ref mineLabel,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
			new Vector2(-60.2f,170.26f),
			new Vector2(88.55f,40f),
			1
			
		);
		mineLabelIn.AddComponent<CanvasRenderer>();
		Image im_mineLabelIn = mineLabelIn.AddComponent<Image>();
		im_mineLabelIn.color = new Color(0.23f,0.11f,0.0f,0f);
		
		
		GameObject txmineLabelIn = new GameObject("Text");
		AddButton(
			ref txmineLabelIn,
			ref mineLabelIn,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,0f),
			2
			
		);
		txmineLabelIn.AddComponent<CanvasRenderer>();
		
		Text tx_txmineLabelIn = txmineLabelIn.AddComponent<Text>();
		rtsm.cameraOperator.mineLabel = tx_txmineLabelIn;
		tx_txmineLabelIn.text = "0";
		tx_txmineLabelIn.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		tx_txmineLabelIn.fontSize = 18;
		tx_txmineLabelIn.alignment = TextAnchor.MiddleLeft;
		tx_txmineLabelIn.color = new Color(0.61f,0.50f,0.13f,1f);
		
		
		GameObject ironmineLabelIcon = new GameObject("IronIcon");
		camop.mineIronIcon = ironmineLabelIcon;
		AddButton(
			ref ironmineLabelIcon,
			ref mineLabel,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
			new Vector2(-130.2f,170.26f),
			new Vector2(40f,40f),
			1
			
		);
		ironmineLabelIcon.AddComponent<CanvasRenderer>();
		Image im_ironmineLabelIcon = ironmineLabelIcon.AddComponent<Image>();
		im_ironmineLabelIcon.sprite = Resources.Load<Sprite>("textures/icons/ironBars");
		
		
		GameObject goldmineLabelIcon = new GameObject("GoldIcon");
		camop.mineGoldIcon = goldmineLabelIcon;
		AddButton(
			ref goldmineLabelIcon,
			ref mineLabel,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
			new Vector2(-130.2f,170.26f),
			new Vector2(40f,40f),
			1
			
		);
		goldmineLabelIcon.AddComponent<CanvasRenderer>();
		Image im_goldmineLabelIcon = goldmineLabelIcon.AddComponent<Image>();
		im_goldmineLabelIcon.sprite = Resources.Load<Sprite>("textures/icons/goldBars");
		
		
		
	}
	
	
	void BuildingPropertiesMenu(string[] icon, int menuMode, int countVisible){
	
		camop = GameObject.Find("Main Camera").GetComponent<CameraOperator>();
//		camopS = GameObject.Find("Main Camera").GetComponent<CameraOperator>();
		
		rtscam = GameObject.Find("Main Camera").GetComponent<RTSCamera>();	
		
		
	/*	GameObject activeScreen = new GameObject("ActiveScreen");
		AddButton(
			ref activeScreen,
			ref mainCanvas,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(11.5f,19f),
			new Vector2(-164.75f,-30.5f),
			2
			
		);
		activeScreen.AddComponent<CanvasRenderer>();
		
	//	eventTrigger = activeScreen.AddComponent<EventTrigger>();
		
		
		Image im_activeScreen = activeScreen.AddComponent<Image>();
		im_activeScreen.color = new Color(0f,0f,0f,0f);
		
	//	activeScreen.AddComponent<Button>();
		
		
	//	AddEventTrigger(OnPointerEnterT, EventTriggerType.PointerEnter);
	//	AddEventTrigger(OnPointerEnterF, EventTriggerType.PointerExit);
		
	//	et_activeScreen.OnPointerEnter(camop.ActiveScreenTrue());
	//		 delegate {
	//			camop.ActiveScreenTrue();
	//		}
	//	);
		
		*/
		
	
		GameObject propButton = new GameObject("PropertiesButton");
		AddButton(
			ref propButton,
			ref mainCanvas,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,-0.5f),
			2
			
		);
		propButton.AddComponent<CanvasRenderer>();
		
		GameObject propButtonIn = new GameObject("PropertiesButtonIn");
		propButtonIn.SetActive(false);
		camop.unitPropertiesButton.Add(propButtonIn);
		AddButton(
			ref propButtonIn,
			ref propButton,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
			new Vector2(-130.2f,-0.26f),
			new Vector2(60f,60f),
			1
			
		);
		
		propButtonIn.AddComponent<CanvasRenderer>();
		Image im_propButtonIn = propButtonIn.AddComponent<Image>();
	//	im_propButtonIn.sprite = Resources.Load<Sprite>("textures/icons/eye_ico");
		im_propButtonIn.color = new Color(0.23f,0.11f,0.0f,1f);
		Button bt_propButtonIn = propButtonIn.AddComponent<Button>();
		list_bt_propButtonIn.Add(bt_propButtonIn);
		
		
		GameObject txpropButtonIn = new GameObject("Text");
		AddButton(
			ref txpropButtonIn,
			ref propButtonIn,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,0f),
			2
			
		);
		txpropButtonIn.AddComponent<CanvasRenderer>();
		
		Text tx_txpropButtonIn = txpropButtonIn.AddComponent<Text>();
		tx_txpropButtonIn.text = "";
			
		tx_txpropButtonIn.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		tx_txpropButtonIn.alignment = TextAnchor.MiddleCenter;
		tx_txpropButtonIn.color = new Color(0.61f,0.50f,0.13f,1f);
		
		
		
		GameObject spritepropButtonIn = new GameObject("Sprite");
		AddButton(
			ref spritepropButtonIn,
			ref propButtonIn,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,0f),
			2
			
		);
		spritepropButtonIn.AddComponent<CanvasRenderer>();
		Image im_spritepropButtonIn = spritepropButtonIn.AddComponent<Image>();
		im_spritepropButtonIn.sprite = Resources.Load<Sprite>("textures/icons/eye_ico");
		
		
		
		
		GameObject propButtonOut = new GameObject("PropertiesButtonOut");
		propButtonOut.SetActive(false);
		AddButton(
			ref propButtonOut,
			ref propButton,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
			new Vector2(-130.2f,-0.26f),
			new Vector2(60f,60f),
			1
			
		);
		
		propButtonOut.AddComponent<CanvasRenderer>();
		Image im_propButtonOut = propButtonOut.AddComponent<Image>();
	//	im_propButtonOut.sprite = Resources.Load<Sprite>("textures/icons/eye_ico");
		im_propButtonOut.color = new Color(0.23f,0.11f,0.0f,1f);
		Button bt_propButtonOut = propButtonOut.AddComponent<Button>();
		list_bt_propButtonOut.Add(bt_propButtonOut);
		
		GameObject txpropButtonOut = new GameObject("Text");
		AddButton(
			ref txpropButtonOut,
			ref propButtonOut,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,0f),
			2
			
		);
		txpropButtonOut.AddComponent<CanvasRenderer>();
		Text tx_txpropButtonOut = txpropButtonOut.AddComponent<Text>();
		tx_txpropButtonOut.text = "";
			
		tx_txpropButtonOut.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		tx_txpropButtonOut.alignment = TextAnchor.MiddleCenter;
		tx_txpropButtonOut.color = new Color(0.61f,0.50f,0.13f,1f);
		
		GameObject spritepropButtonOut = new GameObject("Sprite");
		AddButton(
			ref spritepropButtonOut,
			ref propButtonOut,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,0f),
			2
			
		);
		spritepropButtonOut.AddComponent<CanvasRenderer>();
		Image im_spritepropButtonOut = spritepropButtonOut.AddComponent<Image>();
		im_spritepropButtonOut.sprite = Resources.Load<Sprite>("textures/icons/eye_ico");
		
		
	
	
	
		GameObject bCounter = new GameObject("BuildCounter");
		list_bCounter.Add(bCounter);
		
		bCounter.SetActive(false);
		AddButton(
			ref bCounter,
			ref mainCanvas,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
			new Vector2(-83f,36f),
			new Vector2(162f,26f),
			1
			
		);
		bCounter.AddComponent<CanvasRenderer>();
		
		
		Text tx_bCounter = bCounter.AddComponent<Text>();
		
		tx_bCounter.text = "";
			
		tx_bCounter.font = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		tx_bCounter.alignment = TextAnchor.MiddleCenter;
		tx_bCounter.color = new Color(0.61f,0.50f,0.13f,1f);
		
		
		ScrollCountController scc_bCounter = bCounter.AddComponent<ScrollCountController>();
		
	//	UIPingPong uipp_bCounter = bCounter.AddComponent<UIPingPong>();
		

//////////////////////////////////////////////////////////////////////////////////////////		
///////////////////////////////////   Unit Properties menus  /////////////////////////////		
//////////////////////////////////////////////////////////////////////////////////////////		
		
		
        GameObject uPropMenus = new GameObject("UnitPropertiesMenus");
        list_uPropMenus.Add(uPropMenus);
        
        AddButton(
			ref uPropMenus,
			ref mainCanvas,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,0f),
			new Vector2(0f,-0.6f),
			2
			
		);
		uPropMenus.AddComponent<CanvasRenderer>();
		
		pMenus_in.Add(new List<GameObject>());
		bt_pMenus_in.Add(new List<Button>());
		
		pMenus_out.Add(new List<GameObject>());
		bt_pMenus_out.Add(new List<Button>());
		
// 		List<GameObject> pMenus_in = new List<GameObject>();
// 		List<Button> bt_pMenus_in = new List<Button>();
// 		
// 		List<GameObject> pMenus_out = new List<GameObject>();
// 		List<Button> bt_pMenus_out = new List<Button>();
		
		for(int i=0;i<countVisible;i++){
			GameObject pMenu = new GameObject("pMenu_"+i);
			AddButton(
				ref pMenu,
				ref uPropMenus,
				new Vector2(0f,0f),
				new Vector2(1f,1f),
				new Vector2(0f,-0.2f),
				new Vector2(0f,0.2f),
				2
			
			);
			pMenu.AddComponent<CanvasRenderer>();
			
			GameObject pMenu_in = new GameObject("in");
			pMenus_in[menuMode-1].Add(pMenu_in);
			pMenu_in.SetActive(false);
			AddButton(
				ref pMenu_in,
				ref pMenu,
				new Vector2(1f,0.5f),
				new Vector2(1f,0.5f),
				new Vector2(-194f,23f*countVisible-45f*(1f*i+0.5f)),
				new Vector2(61f,45f),
				1
			
			);
			pMenu_in.AddComponent<CanvasRenderer>();
			
			Image im_pMenu_in = pMenu_in.AddComponent<Image>();
			im_pMenu_in.sprite = Resources.Load<Sprite>("textures/icons/"+icon[i]);
			
// 			if(i==0){
// 				im_pMenu_in.sprite = Resources.Load<Sprite>("textures/icons/"+icon[0]);
// 			}
// 			else if(i==1){
// 				im_pMenu_in.sprite = Resources.Load<Sprite>("textures/icons/"+icon[1]);
// 			}
			
			Button bt_pMenu_in = pMenu_in.AddComponent<Button>();
			bt_pMenus_in[menuMode-1].Add(bt_pMenu_in);
			
			
			
			
			
			GameObject pMenu_out = new GameObject("out");
			pMenus_out[menuMode-1].Add(pMenu_out);
			pMenu_out.SetActive(false);
			AddButton(
				ref pMenu_out,
				ref pMenu,
				new Vector2(1f,0.5f),
				new Vector2(1f,0.5f),
				new Vector2(-194f,23f*countVisible-45f*(1f*i+0.5f)),
				new Vector2(61f,45f),
				1
			
			);
			pMenu_out.AddComponent<CanvasRenderer>();
			
			Image im_pMenu_out = pMenu_out.AddComponent<Image>();
			im_pMenu_out.sprite = Resources.Load<Sprite>("textures/icons/"+icon[i]);
//			 if(i==0){
// 				im_pMenu_out.sprite = Resources.Load<Sprite>("textures/icons/"+icon[0]);
// 			}
// 			else if(i==1){
// 				im_pMenu_out.sprite = Resources.Load<Sprite>("textures/icons/"+icon[1]);
// 			}
			
			Button bt_pMenu_out = pMenu_out.AddComponent<Button>();
			bt_pMenus_out[menuMode-1].Add(bt_pMenu_out);
			
			
	        
	        		
			
			
			
			
		}
	// adding functionality
		
		bt_propButtonIn.onClick.AddListener(delegate {
		        
					propButtonOut.SetActive(true);
					propButtonIn.SetActive(false);
					activeScreenG.SetActive(false);
					
				});
		for(int i=0;i<countVisible;i++){
		    GameObject go1 = pMenus_in[menuMode-1][i];
			bt_propButtonIn.onClick.AddListener(delegate {
				go1.SetActive(true);
			});
		}
		
		
		
		bt_propButtonOut.onClick.AddListener(delegate {
		
			propButtonOut.SetActive(false);
			propButtonIn.SetActive(true);
			bCounter.SetActive(false);
			activeScreenG.SetActive(true);
			rtscam.enabled = true;
			
		});
		for(int i=0;i<countVisible;i++){
		    GameObject go1 = pMenus_in[menuMode-1][i];
		    GameObject go2 = pMenus_out[menuMode-1][i];
			bt_propButtonOut.onClick.AddListener(delegate {
				go1.SetActive(false);
				go2.SetActive(false);
			});
		}
		
			

		
		
		for(int i=0;i<countVisible;i++){
		    GameObject go1 = pMenus_in[menuMode-1][i];
		    GameObject go2 = pMenus_out[menuMode-1][i];
		    
		    
		    GameObject curModel = null;
		    
			if(menuMode == 1){
				curModel = models[i];
			}
			else if(menuMode == 2){
				curModel = building_models[i];
			}
			else if(menuMode == 3){
				curModel = factory_models[i];
			}
			
            UnitPars curModelPars = curModel.GetComponent<UnitPars>();
		    
	//	    if(menuMode == 1){
		    if(curModelPars.isBuilding == false){
				bt_pMenus_in[menuMode-1][i].onClick.AddListener(delegate {
						bCounter.SetActive(true);
						go2.SetActive(true);
						go1.SetActive(false);
						rtscam.enabled = false;
					
					});
			}
		//	else if((menuMode >= 2)&&(menuMode <= 5)){
			else if(curModelPars.isBuilding == true){
				bt_pMenus_in[menuMode-1][i].onClick.AddListener(delegate {
				//    int kkk = i;
					bCounter.SetActive(false);
					go2.SetActive(false);
					go1.SetActive(false);
					propButtonOut.SetActive(false);
					propButtonIn.SetActive(true);
					activeScreenG.SetActive(true);
					rtscam.enabled = true;
				    
				    bm.objectToSpawn = curModel;
				    bm.up_objectToSpawn = curModel.GetComponent<UnitPars>();
				    bm.enabled = true;
				    bm.ActivateProjector();
				    
				    
				    // bm.objectToSpawnId = kkk;
// 				    print(kkk);
				//	scc_bCounter.model = curModel;
				//	scc_bCounter.StartSpawnng();
				});
			}
				
				
			
		//	if(menuMode == 1){	
			if(curModelPars.isBuilding == false){
				bt_pMenus_out[menuMode-1][i].onClick.AddListener(delegate {
					bCounter.SetActive(false);
					go2.SetActive(false);
					go1.SetActive(false);
					propButtonOut.SetActive(false);
					propButtonIn.SetActive(true);
					activeScreenG.SetActive(true);
					rtscam.enabled = true;
				
					scc_bCounter.model = curModel;
					scc_bCounter.StartSpawnng();
				});	
			}
			
				
			for(int j=0;j<countVisible;j++){
			    GameObject go1a = pMenus_in[menuMode-1][j];
		    	GameObject go2a = pMenus_out[menuMode-1][j];
				if(i != j){
					bt_pMenus_in[menuMode-1][i].onClick.AddListener(delegate {
						go2a.SetActive(false);
						go1a.SetActive(false);
					});
				}
			}
		}
		
		
	}
	
	
	
	public void AddBuildingPropertiesMenuItem(GameObject spawnModel, string icon, int place, int menuMode){
		int N = pMenus_out[menuMode-1].Count;
		
		for(int i=0;i<N;i++){
		    GameObject c_pMenu_in = pMenus_in[menuMode-1][i];
		    GameObject c_pMenu_out = pMenus_out[menuMode-1][i];
		    float j = 1f*i-0.5f;
		    if(i>place-1){
		    	j=1f*i+0.5f;
		    }
		    
			MoveButton(
				ref c_pMenu_in,
				new Vector2(1f,0.5f),
				new Vector2(1f,0.5f),
				new Vector2(-194f,23f*N-45f*(1f*j+0.5f)),
				new Vector2(61f,45f),
				1
			
			);
			
			MoveButton(
				ref c_pMenu_out,
				new Vector2(1f,0.5f),
				new Vector2(1f,0.5f),
				new Vector2(-194f,23f*N-45f*(1f*j+0.5f)),
				new Vector2(61f,45f),
				1
			
			);
		}
		
		GameObject pMenu = new GameObject("pMenu_"+place);
		GameObject uPropMenus = list_uPropMenus[menuMode-1];
		AddButton(
			ref pMenu,
			ref uPropMenus,
			new Vector2(0f,0f),
			new Vector2(1f,1f),
			new Vector2(0f,-0.2f),
			new Vector2(0f,0.2f),
			2
		
		);
		pMenu.AddComponent<CanvasRenderer>();
		
		
		GameObject pMenu_in = new GameObject("in");
		pMenus_in[menuMode-1].Insert(place,pMenu_in);
		pMenu_in.SetActive(false);
		AddButton(
			ref pMenu_in,
			ref pMenu,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
			new Vector2(-194f,23f*(N+1)-45f*(1f*(place)+0.5f)),
			new Vector2(61f,45f),
			1
		
		);
		pMenu_in.AddComponent<CanvasRenderer>();
		
		Image im_pMenu_in = pMenu_in.AddComponent<Image>();
		im_pMenu_in.sprite = Resources.Load<Sprite>("textures/icons/"+icon);
        
		Button bt_pMenu_in = pMenu_in.AddComponent<Button>();
		bt_pMenus_in[menuMode-1].Insert(place, bt_pMenu_in);

		
		GameObject pMenu_out = new GameObject("out");
		pMenus_out[menuMode-1].Insert(place,pMenu_out);
		pMenu_out.SetActive(false);
		AddButton(
			ref pMenu_out,
			ref pMenu,
			new Vector2(1f,0.5f),
			new Vector2(1f,0.5f),
	//		new Vector2(-194f,23f*(N+1)-45f*(1f*(place+1)+0.5f)),
	        new Vector2(-194f,23f*(N+1)-45f*(1f*(place)+0.5f)),
			new Vector2(61f,45f),
			1
		
		);
		pMenu_out.AddComponent<CanvasRenderer>();
		
		Image im_pMenu_out = pMenu_out.AddComponent<Image>();
		im_pMenu_out.sprite = Resources.Load<Sprite>("textures/icons/"+icon);
		
		Button bt_pMenu_out = pMenu_out.AddComponent<Button>();
		bt_pMenus_out[menuMode-1].Insert(place, bt_pMenu_out);


        Button bt_propButtonIn = list_bt_propButtonIn[menuMode-1];
        Button bt_propButtonOut = list_bt_propButtonOut[menuMode-1];

// Adding functionality

		//GameObject go1 = pMenus_in[menuMode-1][i];
		bt_propButtonIn.onClick.AddListener(delegate {
			pMenu_in.SetActive(true);
		});
		
		//GameObject go2 = pMenus_out[menuMode-1][i];
		bt_propButtonOut.onClick.AddListener(delegate {
			pMenu_in.SetActive(false);
			pMenu_out.SetActive(false);
		});
		
		
		
		GameObject curModel = spawnModel;
		UnitPars curModelPars = spawnModel.GetComponent<UnitPars>();
		//null;
// 		if(menuMode == 1){
// 			curModel = models[place];
// 		}
// 		else if((menuMode >= 2)&&(menuMode <= 5)){
// 			curModel = building_models[place];
// 		}
        
        GameObject bCounter = list_bCounter[menuMode-1];
        GameObject propButtonIn = bt_propButtonIn.gameObject;
		GameObject propButtonOut = bt_propButtonOut.gameObject;

    //    if(menuMode == 1){
		if(curModelPars.isBuilding == false){
			bt_pMenu_in.onClick.AddListener(delegate {
					bCounter.SetActive(true);
					pMenu_out.SetActive(true);
					pMenu_in.SetActive(false);
					rtscam.enabled = false;
				
				});
		}
		
	//	else if((menuMode >= 2)&&(menuMode <= 5)){
		else if(curModelPars.isBuilding == true){
			bt_pMenu_in.onClick.AddListener(delegate {
				bCounter.SetActive(false);
				pMenu_out.SetActive(false);
				pMenu_in.SetActive(false);
				propButtonOut.SetActive(false);
				propButtonIn.SetActive(true);
				activeScreenG.SetActive(true);
				rtscam.enabled = true;
				
				bm.objectToSpawn = curModel;
				bm.up_objectToSpawn = curModel.GetComponent<UnitPars>();
				bm.enabled = true;
				bm.ActivateProjector();				
			});
		}
		
        ScrollCountController scc_bCounter = bCounter.GetComponent<ScrollCountController>();
        
    //    if(menuMode == 1){
		if(curModelPars.isBuilding == false){	
			bt_pMenu_out.onClick.AddListener(delegate {
				bCounter.SetActive(false);
				pMenu_out.SetActive(false);
				pMenu_in.SetActive(false);
				propButtonOut.SetActive(false);
				propButtonIn.SetActive(true);
				activeScreenG.SetActive(true);
				rtscam.enabled = true;
			    
				scc_bCounter.model = curModel;
				scc_bCounter.StartSpawnng();
			});	
		}
		
		for(int j=0;j<=N;j++){
			GameObject go1a = pMenus_in[menuMode-1][j];
			GameObject go2a = pMenus_out[menuMode-1][j];
			if(j != place){
				bt_pMenu_in.onClick.AddListener(delegate {
					go2a.SetActive(false);
					go1a.SetActive(false);
				});
	
				bt_pMenus_in[menuMode-1][j].onClick.AddListener(delegate {
					pMenu_out.SetActive(false);
					pMenu_in.SetActive(false);
				});
			
			}
		}
	
		
		
		
		
	}
	
	
	
	
	
	void AddButton(
					ref GameObject go, 
					ref GameObject mCanvas,
					
					Vector2 aMin,
					Vector2 aMax,
					Vector2 aPos,
					Vector2 sDelt,
					
					int mode
		){
		
		AddChild(go, mCanvas);
		
		RectTransform rt_go = go.AddComponent<RectTransform>();
		
		go.layer = LayerMask.NameToLayer("UI");
		
		rt_go.anchorMin = aMin;
		rt_go.anchorMax = aMax;
		
		if(mode == 1){
			rt_go.anchoredPosition = aPos;
			rt_go.sizeDelta = sDelt;
		}
		else if(mode == 2){
			rt_go.offsetMin = aPos;
			rt_go.offsetMax = sDelt;
		}
		
		
		
		
	}
	
	void MoveButton(
		ref GameObject go,
		
		Vector2 aMin,
		Vector2 aMax,
		Vector2 aPos,
		Vector2 sDelt,
		
		int mode
	)
// changes location of existing button	
	{
		
		RectTransform rt_go = go.GetComponent<RectTransform>();
		
		
		rt_go.anchorMin = aMin;
		rt_go.anchorMax = aMax;
		
		if(mode == 1){
			rt_go.anchoredPosition = aPos;
			rt_go.sizeDelta = sDelt;
		}
		else if(mode == 2){
			rt_go.offsetMin = aPos;
			rt_go.offsetMax = sDelt;
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	void AddChild(GameObject child, GameObject parent){
		child.transform.SetParent(parent.transform);
	}
	
	
	public void SetPeace(int a, int b){
	    dip.SetRelation(a,b,0);
	}
	
	public void SetWar(int a, int b){
	    dip.SetRelation(a,b,1);
	}
	
/*	#region TriggerEventsSetup
	private void AddEventTrigger(UnityAction action, EventTriggerType triggerType)
     {
         // Create a nee TriggerEvent and add a listener
         EventTrigger.TriggerEvent trigger = new EventTrigger.TriggerEvent();
         trigger.AddListener((eventData) => action()); // you can capture and pass the event data to the listener
 
         // Create and initialise EventTrigger.Entry using the created TriggerEvent
         EventTrigger.Entry entry = new EventTrigger.Entry() { callback = trigger, eventID = triggerType };
         
         if(action == null){
         	print("null");
         }
         else if(action != null){
         	print("full");
         }
 
         // Add the EventTrigger.Entry to delegates list on the EventTrigger
         eventTrigger.delegates.Add(
         	entry
         );
     }
	
	private void AddEventTrigger(UnityAction<BaseEventData> action, EventTriggerType triggerType)
     {
         // Create a nee TriggerEvent and add a listener
         EventTrigger.TriggerEvent trigger = new EventTrigger.TriggerEvent();
         trigger.AddListener((eventData) => action(eventData)); // you can capture and pass the event data to the listener
 
         // Create and initialise EventTrigger.Entry using the created TriggerEvent
         EventTrigger.Entry entry = new EventTrigger.Entry() { callback = trigger, eventID = triggerType };
         
         
         
         // Add the EventTrigger.Entry to delegates list on the EventTrigger
         eventTrigger.delegates.Add(entry);
     }
	#endregion
	
	#region Callbacks
	private void OnPointerEnterT()
     {
         if(camopS != null){
         	camopS.ActiveScreenTrue();
         }
     }
    private void OnPointerEnterF()
     {
     	if(camopS != null){
			camopS.ActiveScreenFalse();
        }
     }
     
 
	#endregion
	*/
	
}
