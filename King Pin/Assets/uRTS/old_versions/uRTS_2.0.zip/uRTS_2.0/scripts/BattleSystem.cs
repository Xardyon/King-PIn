﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BattleSystem : MonoBehaviour {

// BSystem is core component for simulating RTS battles
// It has 6 phases for attack and gets all different game objects parameters inside.
// Attack phases are: Search, Approach target, Attack, Self-Heal, Die, Rot (Sink to ground).
// All 6 phases are running all the time and checking if object is matching criteria, then performing actions
// Movements between different phases are also described

	
	public float attackDistance = 70.0f;

	
	
	private float[] timeloops = new float[7];
	private float[] timeall = new float[7];
	
	private float[] performance = new float[7];

	private string message = " ";
	
	private string message1 = " ";
	private string message2 = " ";
	private string message3 = " ";
	private string message4 = " ";
	private string message5 = " ";
	private string message6 = " ";
	[HideInInspector] public bool displayMessage = false;


	
	private float dist;
	

	
	
	public static int maxIndApproachers = 5;
	public static int maxIndAttackers = 5;
	

	




    public List<List<GameObject>> runits = new List<List<GameObject>>();
    public List<List<GameObject>> rfunits = new List<List<GameObject>>();
    
    public List<List<GameObject>> cprunits = new List<List<GameObject>>();
    public List<List<GameObject>> cprfunits = new List<List<GameObject>>();
    
    
    
/*    public List<List<UnitPars>> runitsUP = new List<List<UnitPars>>();
    public List<List<UnitPars>> rfunitsUP = new List<List<UnitPars>>();
    
    public List<List<UnitPars>> cprunitsUP = new List<List<UnitPars>>();
    public List<List<UnitPars>> cprfunitsUP = new List<List<UnitPars>>();




    public List<List<NavMeshAgent>> runitsNMA = new List<List<NavMeshAgent>>();
    public List<List<NavMeshAgent>> rfunitsNMA = new List<List<NavMeshAgent>>();
    
    public List<List<NavMeshAgent>> cprunitsNMA = new List<List<NavMeshAgent>>();
    public List<List<NavMeshAgent>> cprfunitsNMA = new List<List<NavMeshAgent>>();

	*/

	public List<GameObject> unitss = new List<GameObject>();
	public List<UnitPars> unitssUP = new List<UnitPars>();
	public List<NavMeshAgent> unitssNMA = new List<NavMeshAgent>();
	public List<SpriteLoader> unitssSL = new List<SpriteLoader>();

	

	public List<GameObject> unitsBuffer = new List<GameObject>();



    public List<GameObject> selfHealers = new List<GameObject>();
    public List<GameObject> deads = new List<GameObject>();
    
 

    public List<GameObject> selfHealersBuffer = new List<GameObject>();
    public List<GameObject> deadsBuffer = new List<GameObject>();

	public List<GameObject> sinks = new List<GameObject>();
	
	
	private Scores sc;
	
	private RTSMaster rtsm = null;
	
//	private int appCount = 0;
//	private int maxAppCount = 200;
	
	
	
	static private SelectionMark selM;    

	
	
	void Awake(){
		sc = GameObject.Find("Terrain").GetComponent<Scores>();
		selM = GameObject.Find("Terrain").GetComponent<SelectionMark>();
		rtsm = GameObject.Find("RTS Master").GetComponent<RTSMaster>();
		rtsm.battleSystem = this;
	}
	
	
	
	
	// Use this for initialization
	void Start () {
	

        
        

        
        
 

		
// starting to add units to main unitss array		
		StartCoroutine(AddBuffer());

		
// Starts all 6 coroutines to start searching for possible units in unitss array.
		StartCoroutine(SearchPhase());
		StartCoroutine(ApproachTargetPhase());
		StartCoroutine(AttackPhase());
		StartCoroutine(SelfHealingPhase());
		StartCoroutine(DeathPhase());
		StartCoroutine(SinkPhase());
		
		StartCoroutine(ManualRestorer());
	
		

	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI (){
	
	// Display performance
		if ( displayMessage )
    	{
    		GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.05f, 500f, 20f), message);
    		
        	GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.2f, 500f, 20f), message1);
        	GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.3f, 500f, 20f), message2);
        	GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.4f, 500f, 20f), message3);
        	GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.5f, 500f, 20f), message4);
        	GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.6f, 500f, 20f), message5);
        	GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.7f, 500f, 20f), message6);
    	}
	}
	

	
	public IEnumerator SearchPhase()
	{
	
// The main coroutine, which starts to search for nearest enemies neighbours and set them for attack
// NN search works with kdtree.cs NN search class, implemented by A. Stark at 2009.
// Target candidates are put on kdtree, while attackers used to search for them.
// NN searches are based on position coordinates in 3D.

	float t1 = 0.0f;
//	float t2 = 0.0f;
	float twaiter = 0.0f;
//	float t3 = Time.realtimeSinceStartup;

	List<int> countr = new List<int>();
	List<int> countrf = new List<int>();

	List<int[]> iorig = new List<int[]>();
	List<int[]> iorigf = new List<int[]>();

    List<KDTree> RTree = new List<KDTree>();
    List<Vector3[]> rtreePoints = new List<Vector3[]>();
    List<Vector3[]> rftreePoints = new List<Vector3[]>();
    
    int maxsWaiter = 1000;
	
	

	int indmindisti = 0;
	
	int sWaiter = 0;
	
	Diplomacy dip = this.gameObject.GetComponent<Diplomacy>();
	int numNations = dip.numberNations;
	
	runits.Clear();
    rfunits.Clear();
    
    
    for(int iNations =0; iNations<numNations; iNations++){
			runits.Add(new List<GameObject>());
			rfunits.Add(new List<GameObject>());
	}
	

	
  	yield return new WaitForSeconds(1.0f);
  		
  		while(true){
  		
  		t1 = Time.realtimeSinceStartup;
  		twaiter = 0;
  		

    //    Diplomacy dip = this.gameObject.GetComponent<Diplomacy>();
        
        
        
        
        
        cprunits.Clear();
        cprfunits.Clear();
        
		for(int iNations =0; iNations<numNations; iNations++){
		
			cprunits.Add(new List<GameObject>());
			cprfunits.Add(new List<GameObject>());
		}
		


		
// adding back units which becomes attackable (if they get less attackers than defined by critical number)

		for(int i = 0; i<unitss.Count; i++){
		
			GameObject go = unitss[i];
		//	UnitPars goPars = go.GetComponent<UnitPars>();
			UnitPars goPars = unitssUP[i];
			
			int nation = goPars.nation-1;
			if(goPars.isReadyBeg){

			
        			rfunits[nation].Add(go); // fighters array
        	
        	        goPars.isReadyBeg = false;
        	        goPars.isReadyEnd = true;
			}
			if(goPars.isAttackable == true){
			    if(goPars.onTargetSearch == false){
			        if(goPars.noAttackers <= goPars.maxAttackers){
						runits[nation].Add(go);	// attackable targets
						goPars.onTargetSearch = true;
					}
				}
			}
			
			
		}
		
		

		
		
		
		
		
		
		

		
		
		
// resetting copies arrays.	
    
		
		for(int iNations =0; iNations<numNations; iNations++){
		
			cprunits[iNations].Clear();
		
		
			cprfunits[iNations].Clear();
			
		
			for(int jNations =0; jNations<numNations; jNations++){
				if(iNations!=jNations){
				    
					if(dip.relations[iNations+1][jNations+1] == 1){
					    
					
						for(int i =0; i<runits[jNations].Count; i++){
		
							cprunits[iNations].Add(runits[jNations][i]);
		
						}
					}
				}
			}
		
			for(int i =0; i<rfunits[iNations].Count; i++){
		
				cprfunits[iNations].Add(rfunits[iNations][i]);
		
			}
		
		}
		
	

		
		
// finding counters for copies arrays			
		
		countr.Clear();
		countrf.Clear();
		

		

		
		for(int iNations =0; iNations<numNations; iNations++){
			
			countr.Add(cprunits[iNations].Count);
			countrf.Add(cprfunits[iNations].Count);
			
		
		}
		
		iorig.Clear();
		iorigf.Clear();
		
		
		for(int iNations =0; iNations<numNations; iNations++){
			iorig.Add(new int[countr[iNations]]);
			iorigf.Add(new int[countrf[iNations]]);
		}
		
		
		// initialising vector arrays	
		
		rtreePoints.Clear();
		rftreePoints.Clear();
		
		for(int iNations =0; iNations<numNations; iNations++){
			rtreePoints.Add(new Vector3[countr[iNations]]);
			rftreePoints.Add(new Vector3[countrf[iNations]]);
		}
		

		
// putting target candidates coordinates onto arrays and setting non attackable targets not to be used on search
		
        
		
		for(int iNations =0; iNations<numNations; iNations++){
		  for(int i =0; i<cprunits[iNations].Count; i++){
		    
		/*    sWaiter = sWaiter+1;
                
            if(sWaiter>maxsWaiter){
                    twaiter = twaiter + 0.2f;
                    sWaiter = 0;
                    yield return new WaitForSeconds(0.2f);
            }*/
		    
			GameObject go = cprunits[iNations][i];
        	UnitPars goPars = go.GetComponent<UnitPars>();
			
			rtreePoints[iNations][i]=go.transform.position;
			
			iorig[iNations][i]=i;
			if(goPars.isAttackable == false){
				if(goPars.onTargetSearch == true){
					goPars.onTargetSearch = false;
					for(int jNations =0; jNations<numNations; jNations++){
						if(iNations!=jNations){
							
							runits[jNations].Remove(go);
						}
					}
				}
			}
		
		
		
		  }
		
		}
		
		
	
		
// putting attackers candidates coordinates onto arrays and removing them from original arrays,
// as they all will get targets
		for(int iNations =0; iNations<numNations; iNations++){
			for(int i =0; i<countrf[iNations]; i++){
		
				rftreePoints[iNations][i]=cprfunits[iNations][i].transform.position;
				iorigf[iNations][i]=i;
				
		
			}
		
		}
		
// sorting vector arrays for faster searches in kdtree

		for(int iNations =0; iNations<numNations; iNations++){
			HeapSort(rtreePoints[iNations], iorig[iNations]);
		//	HeapSort(rftreePoints[iNations], iorigf[iNations]);
			
		}

		
// putting target candidates onto kdtree
        RTree.Clear();
        
        for(int iNations =0; iNations<numNations; iNations++){
      
				RTree.Add(KDTree.MakeFromPoints(rtreePoints[iNations]));
		
		}

		

		
		GameObject go1;
		GameObject go2 = null;
		
		UnitPars goPars1 = null;
		UnitPars goPars2 = null;
		
// attackers searching and setting their targets
        bool exit1 = false;
     //   bool exit2 = false;
     //   bool exit3 = false;
        
        

		for(int iNations =0; iNations<numNations; iNations++){


			for(int i=0;i<countrf[iNations];i++){
			    int io = iorigf[iNations][i];
			    go1 = cprfunits[iNations][io];
			    
				if((countr[iNations]>0)&&(countrf[iNations]>0)){
				
				    bool pass = false;
				    int iomind;
				    
				    int nn = 1;
				    
				//    float sqrRmin = 0.0f;
				    
				    while(pass == false){
					    indmindisti = RTree[iNations].FindNearest(rftreePoints[iNations][io],nn);
					 
					//    RTree[iNations].FindNearestR(indmindisti,rftreePoints[iNations][io],ref sqrRmin);
					    
					//    pass = true;
				        sWaiter = sWaiter+1;
                
                 /*       if(sWaiter>maxsWaiter){
                            twaiter = twaiter + 0.2f;
                            sWaiter = 0;
                            yield return new WaitForSeconds(0.2f);
                        }*/
                        
					    nn = nn+1;
					    if(nn>9990){
					//        print(sqrRmin);
					    }
					    if(nn>10000){
					        print(nn);
					        exit1 = true;
					        break;
					    }
					    
					    if(indmindisti >= iorig[iNations].Length){
					 //    print(indmindisti);
					    }
					    if(indmindisti < 0){
					 //    print(indmindisti);
					     exit1 = true;
					     break;
					    }
					    iomind = iorig[iNations][indmindisti];
				
					
					    go2 = cprunits[iNations][iomind];
					
					    goPars1 = go1.GetComponent<UnitPars>();
					    goPars2 = go2.GetComponent<UnitPars>();
					    
					    if(goPars2.noAttackers <= goPars2.maxStrictAttackers){
					        
					        pass = true;
					    }
					    
					
					}
					if(exit1 == true){
					    break;
					}
					
					
					
			//		goPars1 = go1.GetComponent<UnitPars>();
			//	    goPars2 = go2.GetComponent<UnitPars>();
					
					if(goPars1.isReadyEnd==true){
					//	if(goPars2.noAttackers <= goPars2.maxStrictAttackers){
							goPars1.target = go2;
							goPars1.targetUP = goPars2;
							goPars1.targetNMA = go2.GetComponent<NavMeshAgent>();
				
			// adding attacker to target attackers list	
							goPars2.attackers.Add(go1);
							goPars2.noAttackers = goPars2.noAttackers + 1;
							
							if(goPars2.isAttackable == true){
				   				if(goPars2.noAttackers > goPars2.maxAttackers){
									goPars2.isAttackable = false;
								}
							}
				    	
				    		goPars1.isReadyEnd=false;
							goPars1.isApproaching = true;
							
							
				//		}
				//		else{
				//			goPars1.isReadyEnd=false;
				//			goPars1.isReadyBeg=true;
				//		}
					}
					
					
			    }
			    else{
			    	cprfunits[iNations][io].GetComponent<UnitPars>().isReadyEnd=false;
			    	cprfunits[iNations][io].GetComponent<UnitPars>().isReadyBeg=true;
			    }
			    
				rfunits[iNations].Remove(go1);
			
				
                sWaiter = sWaiter+1;
                
                if(sWaiter>maxsWaiter){
                    twaiter = twaiter + 0.2f;
                    sWaiter = 0;
                    yield return new WaitForSeconds(0.2f);
                }
    		
			

				
		/*		if(Time.realtimeSinceStartup-t3>0.005f){
					twaiter = twaiter + 0.1f*(Time.realtimeSinceStartup-t3)+0.05f;
					yield return new WaitForSeconds(0.1f*(Time.realtimeSinceStartup-t3)+0.05f);
					t3=Time.realtimeSinceStartup;
				}*/
		
			}

		}
		

		
		
	//	t2= Time.realtimeSinceStartup;
		
	//	displayMessage = true;
		
		

  		
		
		
// main coroutine wait statement and performance information collection from search coroutine		

//	twaiter = twaiter + 0.5f+1.0f*(t2-t1);
//	yield return new WaitForSeconds(0.5f+1.0f*(t2-t1));	
	
	twaiter = twaiter + 0.2f;
	yield return new WaitForSeconds(0.2f);
	
	float curTime = Time.realtimeSinceStartup;
	
	timeloops[1] = curTime - t1 - twaiter;
	timeall[1] = curTime - t1;
	performance[1] = (curTime - t1 - twaiter)*100.0f/(curTime - t1);
	
	message1 = ("Search: " + (countr[0]+countr[1]).ToString() + "; " + countrf[0] + "; " + countrf[1] + "; " + (curTime - t1 - twaiter).ToString() + "; " + (performance[1]).ToString() + "% ");

	}
	
	}
	
	
	
	
	
	
	public IEnumerator ApproachTargetPhase()
	{

// this phase starting attackers to move towards their targets
	    
	    float timeBeg;
	    float twaiter;
	    

	    
	    float Rtarget;
	    
	    float stoppDistance;
	    
	    int pCount = 700;
	    

	    int ii = 0;
	    
	    Diplomacy dip = this.gameObject.GetComponent<Diplomacy>();
	    
	    
		while(true){
		    timeBeg = Time.realtimeSinceStartup;
		    
		    
		    int noApproachers = 0;
		    

		    twaiter = 0.0f;
		    
            ii++;
		
		
// checking through main unitss array which units are set to approach (isApproaching)			
		    for(int i = 0; i<unitss.Count; i++){
		        
		        
		        
		        
		        ii++;
		        
		 		GameObject appr = unitss[i];
		 	    UnitPars apprPars = unitssUP[i];
		 		
		 		

		 		
		    	if(apprPars.isApproaching){
		    	
		    	 GameObject targ = apprPars.target;
				 UnitPars targPars = apprPars.targetUP;						
				 NavMeshAgent apprNav = unitssNMA[i];				 
				 NavMeshAgent targNav = apprPars.targetNMA;
				 
				 
		    	 
		    	 bool relationCont = true;
		    	 
		    	 
		    	 
		    	 if(dip.relations[apprPars.nation][targPars.nation]!=1){
		    	 	if(apprPars.nation != targPars.nation){
		    	 		if(apprPars.strictApproachMode == false){
		    	 			relationCont = false;
		    	 			ResetSearching(appr);
		    	 			
		    	 			if(ii > pCount){
		 						yield return new WaitForSeconds(0.05f);
		 						twaiter = twaiter + 0.05f;
		 						ii = 0;
		 					}
		    	 			continue;
		    	 		}
		    	 	}
		    	 }
		    	 if(relationCont == true){
		    	
					
					
					if(targPars.isApproachable == true){
		    	        
		    	 
		    	        
					
						
					    // stopping condition for NavMesh
					    
						apprNav.stoppingDistance = apprNav.radius/(appr.transform.localScale.x) + targNav.radius/(targ.transform.localScale.x);
				
				      // distance between approacher and target
				    
						Rtarget = (targ.transform.position - appr.transform.position).magnitude;
						
						ii = ii + 2;
					 
					 
						stoppDistance = (apprPars.stopDistOut + appr.transform.localScale.x*targ.transform.localScale.x*apprNav.stoppingDistance);
					
					// counting increased distances (failure to approach) between attacker and target;
					// if counter failedR becomes bigger than critFailedR, preparing for new target search.
					
						if(apprPars.strictApproachMode == true){
							
							
					    // for manual approachers
					        
					    	
							float sD = 0.0f;
					
							if(apprPars.isArcher == false){
								sD = stoppDistance;
							}
							else if(apprPars.isArcher == true){
								float critRShoot = apprPars.velArrow*apprPars.velArrow/9.81f - (apprPars.stopDistOut-apprPars.stopDistIn);
								sD = critRShoot;
							
							}
					    
					    
							if(Rtarget < sD){
								apprNav.SetDestination(appr.transform.position);
							
						// pre-setting for attacking
							
								apprPars.isApproaching = false;
								apprPars.isAttacking = true;
					
							
							}
							else{
						
				
								if(apprPars.changeMaterial){
							//		appr.renderer.material.color = Color.green;				
								}
								if(apprPars.animationToUse == 2){
								    if(apprPars.animationMode == 100){
								        appr.GetComponent<Animation>().animation.Play("Knight_Walk");
								        apprPars.animationMode = 101;
								        
								    }
								
								
								}
								if(apprPars.animationToUse == 1){
									SpriteLoader spL = unitssSL[i];
									if(spL.animName != "Walk"){
										spL.animName = "Walk";
									}
								}
				
			
			            // starting to move
			            
								if(apprPars.isMovable){
					        		noApproachers = noApproachers+1;
					        		
									apprNav.SetDestination(targ.transform.position);
									apprNav.speed = 1.5f;
								}
							
						
							}
						    if(ii > pCount){
		 						yield return new WaitForSeconds(0.05f);
		 						twaiter = twaiter + 0.05f;
		 						ii = 0;
		 					}
							continue;
							
							
						}
					
					    if(apprPars.prevR < Rtarget){
					      
					    	apprPars.failedR = apprPars.failedR + 1;
					    	if(apprPars.failedR > apprPars.critFailedR){
					    						    		
					    		targPars.noAttackers = targPars.noAttackers - 1;
					    		if(targPars.isAttackable == false){
				   					if(targPars.noAttackers < targPars.maxAttackers){
				    					targPars.isAttackable = true;
				    				}
								}
					    		
								targPars.attackers.Remove(appr);
								
					    		apprPars.target = null;
					    		apprPars.targetUP = null;
					    		apprPars.targetNMA = null;
					    		
					    		apprPars.isApproaching = false;
					    	
					    		if(apprPars.onManualControl == false){
									apprPars.isReadyBeg = true;
								}
								apprPars.failedR = 0;
								
								if(apprPars.changeMaterial){
						//			appr.renderer.material.color = Color.yellow;				
								}
								if(apprPars.animationToUse == 2){
								    if(apprPars.animationMode == 101){
								        appr.GetComponent<Animation>().animation.Play("Knight_Walk", PlayMode.StopAll);
								        apprPars.animationMode = 100;
								        
								    }
								}
								if(apprPars.animationToUse == 1){
									SpriteLoader spL = unitssSL[i];
								    if(spL.animName != "Walk"){
										spL.animName = "Walk";
									}
								}
								if(ii > pCount){
									yield return new WaitForSeconds(0.05f);
									twaiter = twaiter + 0.05f;
									ii = 0;
		 						}
								continue;
					    	}
					      
				
					    }
				
					    
					    else{
					    // if approachers already close to their targets
					    	
							float sD = 0.0f;
					
							if(apprPars.isArcher == false){
								sD = stoppDistance;
							}
							else if(apprPars.isArcher == true){
								float critRShoot = apprPars.velArrow*apprPars.velArrow/9.81f - (apprPars.stopDistOut-apprPars.stopDistIn);
								sD = critRShoot;
							}
					    
					    
							if(Rtarget < sD){
								apprNav.SetDestination(appr.transform.position);
							
						// pre-setting for attacking
							
								apprPars.isApproaching = false;
						
								apprPars.isAttacking = true;
					
							
							}
							else{
						
				
								if(apprPars.changeMaterial){
						//			appr.renderer.material.color = Color.green;				
								}
								if(apprPars.animationToUse == 2){
								    if(apprPars.animationMode == 100){
								        appr.GetComponent<Animation>().animation.Play("Knight_Walk");
								        apprPars.animationMode = 101;
								        
								    }
								}
								if(apprPars.animationToUse == 1){
								    SpriteLoader spL = unitssSL[i];
								    if(spL.animName != "Walk"){
										spL.animName = "Walk";
									}
								}
				
			
			            // starting to move
			            
								if(apprPars.isMovable){
					        		noApproachers = noApproachers+1;
					        		
									apprNav.SetDestination(targ.transform.position);
									apprNav.speed = 1.5f;
								}
							
						
							}
						}
					// saving previous R
						apprPars.prevR = Rtarget;
						if(ii > pCount){
							yield return new WaitForSeconds(0.05f);
							twaiter = twaiter + 0.05f;
							ii = 0;
		 				}
						continue;
					}
					
				// condition for non approachable targets	
					else{
					    
						targPars.noAttackers = targPars.noAttackers - 1;
						if(targPars.isAttackable == false){
				   			if(targPars.noAttackers < targPars.maxAttackers){
				    			targPars.isAttackable = true;
				    		}
						}
						
						targPars.attackers.Remove(appr);
						
					    apprPars.target = null;
					    apprPars.targetUP = null;
					    apprPars.targetNMA = null;
					    
						apprNav.SetDestination(appr.transform.position);
						
					
						
						apprPars.isApproaching = false;
					
						if(apprPars.onManualControl == false){
							apprPars.isReadyBeg = true;
							
						}
						
						if(apprPars.changeMaterial){
					//			appr.renderer.material.color = Color.yellow;				
						}
						if(apprPars.animationToUse == 2){
								    if(apprPars.animationMode == 101){
								        appr.GetComponent<Animation>().animation.Play("Knight_Walk", PlayMode.StopAll);
								        apprPars.animationMode = 100;
								        
								    }
						}
						
						if(apprPars.animationToUse == 1){
						    SpriteLoader spL = unitssSL[i];
							if(spL.animName != "Idle"){
									spL.animName = "Idle";
								}
						}
						
					}
				   }
		    	}
		    	
		    	ii = ii + 1;
		    	
		    	
		    	
		    	if(ii > pCount){
		 			yield return new WaitForSeconds(0.05f);
		 			twaiter = twaiter + 0.05f;
		 			ii = 0;
		 		}
		        
		    	
		    }
		    if(ii > pCount){
		 			yield return new WaitForSeconds(0.05f);
		 			twaiter = twaiter + 0.05f;
		 			ii = 0;
		 	}
		    	    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
	
// main coroutine wait statement and performance information collection from approach coroutine			
		
		
			
			
			
			twaiter = twaiter + 0.1f;
		
			yield return new WaitForSeconds(0.1f);
		
			
			float curTime = Time.realtimeSinceStartup;
	
			timeloops[2] = curTime - timeBeg - twaiter;
			timeall[2] = curTime - timeBeg;
			
			performance[2] = (curTime-timeBeg-twaiter)*100.0f/(curTime-timeBeg);
			
			message2 = ("Approacher: " + (noApproachers).ToString() + "; "+(noApproachers).ToString() + "; " + (curTime-timeBeg-twaiter).ToString() + "; " + (performance[2]).ToString() + "% ");
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public IEnumerator AttackPhase() {
    
    // Attacking phase set attackers to attack their targets and cause damage when they already approached their targets
    
    float timeBeg;
	float timeEnd;
	

	float twaiter;

	
	float ax;
	float ay;
	float az;
	    
	float tx;
	float ty;
	float tz;
	    
	float Rtarget;
	    
	float stoppDistance;
	
    

    
    float tempRand = 0.0f;
    
    float tempStrength = 1.0f;
    float tempDefence = 1.0f;
    
    int attackersPhaseWaiterCount = 1500;
    int ii=0;
    
    Diplomacy dip = this.gameObject.GetComponent<Diplomacy>();
    
    
	while(true){
		timeBeg = Time.realtimeSinceStartup;
	    
        twaiter = 0.0f;
        
        

        
        int noAttackers = 0;
		    

		    
	// checking through main unitss array which units are set to approach (isAttacking)
        
        for(int i = 0; i<unitss.Count; i++){
        	GameObject att = unitss[i];
        	UnitPars attPars = unitssUP[i];
        	

        	
        	if(attPars.isAttacking){
        	
        			GameObject targ = attPars.target;
        			UnitPars targPars = attPars.targetUP;
        			
        			bool relationCont = true;
		    	 
		    	 	if(dip.relations[attPars.nation][targPars.nation]!=1){
		    	 		if(attPars.nation != targPars.nation){
		    	 			if(attPars.strictApproachMode == false){
		    	 				relationCont = false;
		    	 				ResetSearching(att);
		    	 			}
		    	 		}
		    	 	}
		    	 	if(relationCont == true){
		    	
					
					NavMeshAgent attNav = unitssNMA[i];
					NavMeshAgent targNav = attPars.targetNMA;
					
					attNav.stoppingDistance = attNav.radius/(att.transform.localScale.x) + targNav.radius/(targ.transform.localScale.x);
				
				// distance between attacker and target
				
					Rtarget = (targ.transform.position - att.transform.position).magnitude;
					stoppDistance = (attPars.stopDistOut + att.transform.localScale.x*targ.transform.localScale.x*attNav.stoppingDistance);
					
					
				// auto-correction for archers, who can't reach their targets in large enough distance
					
					
					float sD = 0.0f;
					
					if(attPars.isArcher == false){
						sD = stoppDistance;
					}
					else if(attPars.isArcher == true){
						float critRShoot = attPars.velArrow*attPars.velArrow/9.81f;
						sD = critRShoot;
					}
					
				// if target moves away, resetting back to approach target phase
					if(Rtarget > sD){
						
					
						attPars.isApproaching = true;
						
						attPars.isAttacking = false;
						
					
						
					}
					
					
					
				// if targets becomes immune, attacker is reset to start searching for new target 	
					else if(targPars.isImmune == true){
					
							attPars.isAttacking = false;
							if(attPars.onManualControl == false){
								attPars.isReadyBeg = true;
							}
						
							
							
							targPars.attackers.Remove(att);
							
							targPars.noAttackers = targPars.noAttackers - 1;
							if(targPars.isAttackable == false){
				   				if(targPars.noAttackers < targPars.maxAttackers){
				    				targPars.isAttackable = true;
				    			}
							}
							
							if(attPars.changeMaterial){
						//		att.renderer.material.color = Color.yellow;				
							}
							if(attPars.animationToUse == 1){
								SpriteLoader spL = unitssSL[i];
								if(spL.animName != "Idle"){
									spL.animName = "Idle";
								}
							}
					}
				
				// attacker starts attacking their target	
					else{
						noAttackers = noAttackers + 1;
				
						if(attPars.changeMaterial){
					//		att.renderer.material.color = Color.red;				
						}
						if(attPars.animationToUse == 1){
							SpriteLoader spL = unitssSL[i];
							if(spL.animName != "Attack"){
									spL.animName = "Attack";
							}
						}
						tempRand = Random.value;
						
						tempStrength = attPars.strength;
						tempDefence = attPars.defence;
						
					// if attack passes target through target defence, cause damage to target
						
						
						if(Time.realtimeSinceStartup-attPars.timeMark > attPars.attackWaiter){
						    attPars.timeMark = Time.realtimeSinceStartup;
						    if(attPars.isArcher==true){
						        Quaternion rot = new Quaternion(0.0f,0.0f,0.0f,0.0f);
						    	GameObject arroww = (GameObject)Instantiate(attPars.arrow, att.transform.position,rot);
						    	
						    	ax = att.transform.position.x;
								ay = att.transform.position.y;
								az = att.transform.position.z;
				
								tx = targ.transform.position.x;
								ty = targ.transform.position.y;
								tz = targ.transform.position.z;
						    	
						    	
						    	
						    	float vini = attPars.velArrow;
						    	
						    	float tanthe = vini*vini/(9.81f*Rtarget)-Mathf.Sqrt(vini*vini*vini*vini/(96.2361f*Rtarget*Rtarget)-1.0f);
						    	
						    	float ystatic = (tanthe * Mathf.Sqrt((tx - ax)*(tx - ax)+(tz - az)*(tz - az)));
						    									
						    									
						    	float tana = Mathf.Sqrt(((tx - ax)*(tx - ax)+(ty - ay)*(ty - ay)+(tz - az)*(tz - az))/((tx - ax)*(tx - ax)+(tz - az)*(tz - az))-1);
						    	float cosa = Mathf.Sqrt(((tx - ax)*(tx - ax)+(tz - az)*(tz - az))/((tx - ax)*(tx - ax)+(ty - ay)*(ty - ay)+(tz - az)*(tz - az)));
						    			
						    	float hillModif = 1.0f;
						    	
						    	if(ty > ay){
						    		hillModif = (1.0f+tana/tanthe)/cosa;
						    	}
						    	else{
						    		hillModif = (1.0f-tana/tanthe)/cosa;
						    		//cosa/(1.0f-tana/tanthe);
						    	}
						    	
						    	Vector3 arrForce = (new Vector3(
						    									(tx - ax),
						    									
						    									(ystatic * hillModif),
						    							
						    									(tz - az)
						    						)).normalized;
						    	
						    	
						    	// shoting time
						    	
						    	float shTime = Mathf.Sqrt( ((tx - ax)*(tx - ax)+(tz - az)*(tz - az))/
						    							((vini*arrForce.x)*(vini*arrForce.x)+(vini*arrForce.z)*(vini*arrForce.z))
						    	);
						    	
						    //	Vector3 futureTargPos = targ.transform.position + shTime*targNav.desiredVelocity;
						    	
						    //	Vector3 arrForce2 = vini*arrForce;
						    	
						    	Vector3 arrForce2 = vini*arrForce + shTime*targNav.desiredVelocity;
						    	
						    	//shTime*((targ.transform.position-targPars.prevPos)/(Time.realtimeSinceStartup-targPars.prevTime));
						    	//shTime*targNav.desiredVelocity;
						    	
						    	//(targ.transform.position - att.transform.position).normalized;
						    	
						    //	Vector3 arrForce2 = new Vector3(arrForce.x,arrForce.y,arrForce.z);
						    	
						    	
						    	if(arrForce2.sqrMagnitude > 0.0f){
						    		arroww.rigidbody.AddRelativeForce(arrForce2,ForceMode.VelocityChange);
						    	
						    		ArrowPars arrPars = arroww.GetComponent<ArrowPars>();
						    		
						    		arrPars.attacker = att;
						    		arrPars.target = targ;
						    		
						    		arrPars.attPars = attPars;
						    		arrPars.targPars = targPars;
						    		
						    		arrPars.sc = sc;
						    	
						    		if(tempRand > (tempStrength/(tempStrength+tempDefence))){
			            				arrPars.carriedDamage = 2.0f*tempStrength*Random.value;
			            	
									}
								}
								else{
									Destroy(arroww.gameObject);
								}
						    
						    	
						    }
						    else{
								
								if(tempRand > (tempStrength/(tempStrength+tempDefence))){
								    float damage = 2.0f*tempStrength*Random.value;
			            			targPars.health = targPars.health - damage;
			            			
			            			sc.damageMade[attPars.nation-1] = sc.damageMade[attPars.nation-1] + damage;
			            			sc.damageObtained[targPars.nation-1] = sc.damageObtained[targPars.nation-1] + damage;
			            	
								}
							}
						}
						
					}
        
        	}
        	
       // 	targPars.prevPos = targ.transform.position;
       // 	targPars.prevTime = Time.realtimeSinceStartup;
        	
        	
        	}
            
            
            ii = ii + 1;
        	if(ii > attackersPhaseWaiterCount){
        		ii = 0;
        		yield return new WaitForSeconds(0.2f);
        		twaiter = twaiter + 0.2f;
        		
        	}
            
            
        }
        
        
        






	    
	// main coroutine wait statement and performance information collection from attack coroutine	
		
		twaiter = twaiter + 0.2f;
		
		yield return new WaitForSeconds(0.2f);
		
		timeEnd = Time.realtimeSinceStartup;
		
	
		timeloops[3] = timeEnd - timeBeg - twaiter;
		timeall[3] = timeEnd - timeBeg;
		
		performance[3] = (timeEnd-timeBeg - twaiter)*100.0f/(timeEnd-timeBeg);
		
		message3 = ("Attacker: " + (noAttackers).ToString() + "; "+ (noAttackers).ToString() + "; " + (timeEnd-timeBeg - twaiter).ToString() + "; " + (performance[3]).ToString() + "% ");
	}
    
    
    }


	
	
	public IEnumerator SelfHealingPhase() {
	
	// Self-Healing phase heals damaged units over time
	
	float timeBeg;
	float timeEnd;
	
	float twaiter;
	
	float t3;
	
	int selfHealingPhaseWaiterCount=1500;
	
	
	while(true){
		timeBeg = Time.realtimeSinceStartup;
		
		int noSelfHealers = 0;
		twaiter = 0.0f;
		
		t3=Time.realtimeSinceStartup;
		
		int ii=0;
		
		selfHealers.Clear();
			
		for(int i = 0; i<selfHealersBuffer.Count; i++){
				GameObject go = selfHealersBuffer[i];
				selfHealers.Add(go);
				ii = ii + 1;
				if(ii > selfHealingPhaseWaiterCount){
					if(Time.realtimeSinceStartup-t3>0.005f){
						twaiter = twaiter + 0.1f*(Time.realtimeSinceStartup-t3)+0.05f;
						yield return new WaitForSeconds(0.1f*(Time.realtimeSinceStartup-t3)+0.05f);
						t3=Time.realtimeSinceStartup;
						ii = 0;
					}
				}
				
		}
		
		
	// checking which units are damaged	
	    
		
		for(int i = 0; i<selfHealers.Count; i++){
		
			GameObject sheal = selfHealers[i];
			UnitPars shealPars = sheal.GetComponent<UnitPars>();
			
			if(shealPars.health < shealPars.maxHealth){
			
			// if unit has less health than 0, preparing it to die
			
			    if(shealPars.health < 0.0f){
					shealPars.isHealing = false;
					shealPars.isImmune = true;
					shealPars.isDying = true;
					selfHealersBuffer.Remove(sheal);
					if(!(deadsBuffer.Contains(sheal))){
						deadsBuffer.Add(sheal);
					}
				
				}
				
			// healing unit	
				else{
					shealPars.isHealing = true;
					shealPars.health = shealPars.health + shealPars.selfHealFactor;
				    noSelfHealers = noSelfHealers + 1;
				    
				 // if unit health reaches maximum, unset self-healing
				    
					if(shealPars.health >= shealPars.maxHealth){
						shealPars.health = shealPars.maxHealth;
						shealPars.isHealing = false;
						noSelfHealers = noSelfHealers - 1;
					}
				}
				
			}
			ii = ii + 1;
				if(ii > selfHealingPhaseWaiterCount){
					if(Time.realtimeSinceStartup-t3>0.005f){
						twaiter = twaiter + 0.1f*(Time.realtimeSinceStartup-t3)+0.05f;
						yield return new WaitForSeconds(0.1f*(Time.realtimeSinceStartup-t3)+0.05f);
						t3=Time.realtimeSinceStartup;
						ii = 0;
					}
				}
			
		}
		
// main coroutine wait statement and performance information collection from self-healing coroutine
		
		twaiter = twaiter + 3.0f;

		yield return new WaitForSeconds(3.0f);
		
		timeEnd = Time.realtimeSinceStartup;
		
		timeloops[4] = timeEnd - timeBeg - twaiter;
		timeall[4] = timeEnd - timeBeg;
		
		performance[4] = (timeEnd-timeBeg-twaiter)*100.0f/(timeEnd-timeBeg);
		
		message4 = ("SelfHealing: " + (noSelfHealers).ToString() + "; "+ (selfHealers.Count).ToString() + "; " + (timeEnd-timeBeg-twaiter).ToString() + "; "+ (performance[4]).ToString() + "% ");
		
		
	}
	
	
	}
	
	public IEnumerator DeathPhase(){
	
// Death phase unset all unit activity and prepare to die
	
	float timeBeg;
	float timeEnd;
	
	float twaiter;
	
	float t3;
	
	
	int deathPhaseWaiterCount=1500;
	
	
		while(true){
		    timeBeg = Time.realtimeSinceStartup;
		    
			int noDeads = 0;
			twaiter = 0.0f;
			
			t3=Time.realtimeSinceStartup;
			int ii=0;
			
			deads.Clear();
			
			for(int i = 0; i<deadsBuffer.Count; i++){
				GameObject go = deadsBuffer[i];
				deads.Add(go);
				ii = ii + 1;
				if(ii > deathPhaseWaiterCount){
					if(Time.realtimeSinceStartup-t3>0.005f){
						twaiter = twaiter + 0.1f*(Time.realtimeSinceStartup-t3)+0.05f;
						yield return new WaitForSeconds(0.1f*(Time.realtimeSinceStartup-t3)+0.05f);
						t3=Time.realtimeSinceStartup;
						ii = 0;
					}
				}
				
			}
			
			
	// Getting dying units		
		
			for(int i = 0; i<deads.Count; i++){
			
				GameObject dead = deads[i];
				UnitPars deadPars = dead.GetComponent<UnitPars>();
				
				if(deadPars.isDying == true){
					    
					// If unit is dead long enough, prepare for rotting (sinking) phase and removing from the unitss list
					    
					    if(deadPars.deathCalls > deadPars.maxDeathCalls){
					
							deadPars.isDying = false;
							deadPars.isSinking = true;
							
							deadsBuffer.Remove(dead);
							deads.Remove(dead);
						    
						    
							dead.GetComponent<NavMeshAgent>().enabled = false;
							sinks.Add(dead);
							
							int removeIndex = unitss.IndexOf(dead);
							
							unitss.RemoveAt(removeIndex);
							unitssUP.RemoveAt(removeIndex);
							unitssNMA.RemoveAt(removeIndex);
							unitssSL.RemoveAt(removeIndex);
							
						/*	if(deadPars.animationToUse==1){
								unitssSL.Remove(dead.GetComponent<SpriteLoader>());
							}
							else{
								
							}*/
						
							int nation = deadPars.nation-1;
							runits[nation].Remove(dead);
							rfunits[nation].Remove(dead);
							
							
							
							
						}
						
					// unsetting unit activity and keep it dying	
						else{
							deadPars.isMovable = false;
							deadPars.isReadyBeg = false;
							deadPars.isReadyEnd = false;
							deadPars.isApproaching = false;
							deadPars.isAttacking = false;
							deadPars.isApproachable = false;
							deadPars.isAttackable = false;
							deadPars.isHealing = false;
							
							if(deadPars.animationToUse == 1){
								dead.GetComponent<SpriteLoader>().animName = "Death";
							}
							
							if(deadPars.deathCalls == 0){
								if(deadPars.target!=null){
									UnitPars targPars = deadPars.target.GetComponent<UnitPars>();
									targPars.noAttackers = targPars.noAttackers - 1;
									
									if(targPars.isAttackable == false){
				   						if(targPars.noAttackers < targPars.maxAttackers){
				    						targPars.isAttackable = true;
				    					}
									}
									targPars.attackers.Remove(dead);
								}
								
								if(deadPars.rtsUnitId == 15){
									int iii = rtsm.resourcesCollection.workers.IndexOf(dead);
								
									rtsm.resourcesCollection.workers.RemoveAt(iii);
									rtsm.resourcesCollection.up_workers.RemoveAt(iii);
									rtsm.resourcesCollection.nav_workers.RemoveAt(iii);
									rtsm.resourcesCollection.sl_workers.RemoveAt(iii);
									rtsm.resourcesCollection.workers_resType.RemoveAt(iii);
									rtsm.resourcesCollection.workers_resAmount.RemoveAt(iii);
								}
								else if(deadPars.rtsUnitId == 2){
									int iii = rtsm.resourcesCollection.sawmills.IndexOf(dead);
							//		print(iii);
							//		if((iii>=0) && (iii<rtsm.resourcesCollection.sawmillsPos.Count)){
										rtsm.resourcesCollection.sawmills.RemoveAt(iii);
										rtsm.resourcesCollection.up_sawmills.RemoveAt(iii);
										rtsm.resourcesCollection.sawmillsPos.RemoveAt(iii);
							//		}
								}
								else if(deadPars.rtsUnitId == 5){
									if(rtsm.resourcesCollection.mines.Contains(dead)){
										int iii = rtsm.resourcesCollection.mines.IndexOf(dead);
										rtsm.resourcesCollection.mines.RemoveAt(iii);
										rtsm.resourcesCollection.up_mines.RemoveAt(iii);
										rtsm.resourcesCollection.minesPos.RemoveAt(iii);
										rtsm.resourcesCollection.minesResource.RemoveAt(iii);
										rtsm.resourcesCollection.minesResourceType.RemoveAt(iii);
										rtsm.resourcesCollection.minesResPoints.RemoveAt(iii);
									}
								}
								else if(deadPars.rtsUnitId == 0){
									int iii = rtsm.resourcesCollection.castle.IndexOf(dead);
									rtsm.resourcesCollection.castle.RemoveAt(iii);
									rtsm.resourcesCollection.up_castle.RemoveAt(iii);
									rtsm.resourcesCollection.castlePos.RemoveAt(iii);
								}
								
								
								
								
							}
							
							deadPars.target = null;
							deadPars.targetUP = null;
							deadPars.targetNMA = null;
							
						
						
						// unselecting deads	
							dead.SendMessage("OnUnselected", SendMessageOptions.DontRequireReceiver);
							dead.transform.gameObject.tag = "Untagged";
							
						// unsetting attackers	
						
							dead.GetComponent<NavMeshAgent>().SetDestination(dead.transform.position);
							dead.GetComponent<NavMeshAgent>().speed = 0.0f;
							deadPars.deathCalls = deadPars.deathCalls + 1;
						
							if(deadPars.changeMaterial){
					//			dead.renderer.material.color = Color.blue;				
							}
							
							selM.selectedGoT.Remove(dead.transform);
						    selM.selectedGoPars.Remove(deadPars);
						    
						    
							
					    	noDeads = noDeads + 1;
					    }
				}
			}
			
// main coroutine wait statement and performance information collection from death coroutine			

			twaiter = twaiter + 1.0f;
			yield return new WaitForSeconds(1.0f);
			
			timeEnd = Time.realtimeSinceStartup;
			
			timeloops[5] = timeEnd - timeBeg - twaiter;
			timeall[5] = timeEnd - timeBeg;
			
			performance[5] = (timeEnd-timeBeg-twaiter)*100.0f/(timeEnd-timeBeg);
			
			message5 = ("Dead: " + (noDeads).ToString() + "; "+ (deads.Count).ToString() + "; " + (timeEnd-timeBeg-twaiter).ToString() + "; " + (performance[5]).ToString() + "; ");
			
			
		}
	}
	
	
	
	public IEnumerator SinkPhase(){
	
// rotting or sink phase includes time before unit is destroyed: for example to perform rotting animation or sink object into the ground
	
		float timeBeg;
		float timeEnd;
		
		float twaiter;
		
		while(true){
		    
			timeBeg = Time.realtimeSinceStartup;
			twaiter = 0.0f;
			
	// checking in sinks array, which is already different from main units array
			
			for(int i = 0; i<sinks.Count; i++){
			
				GameObject sink = sinks[i];
				UnitPars sinkPars = sink.GetComponent<UnitPars>();
			
				if(sinkPars.isSinking == true){
				
				
					if(sinkPars.changeMaterial){
			//			sink.renderer.material.color = new Color((148.0f/255.0f),(0.0f/255.0f),(211.0f/255.0f),1.0f);				
					}
					
				// moving sinking object down into the ground	
					if(sink.transform.position.y>-1.0f){
			
						sink.transform.Translate(0,-0.1f,0,Space.World);
		
					}
					
				// destroy object if it has sinked enough	
					else if(sink.transform.position.y<-1.0f){
						sinks.Remove(sink);
						
						if(sink.GetComponent<SpriteLoader>() != null){
							sink.GetComponent<SpriteLoader>().unsetSprite();
						}
						
						if(sinkPars.isBuilding == false){
								sc.nUnits[sinkPars.nation-1] = sc.nUnits[sinkPars.nation-1]-1;
								sc.unitsLost[sinkPars.nation-1] = sc.unitsLost[sinkPars.nation-1]+1;
						}
						else if(sinkPars.isBuilding == true){
								sc.nBuildings[sinkPars.nation-1] = sc.nBuildings[sinkPars.nation-1]-1;
								sc.buildingsLost[sinkPars.nation-1] = sc.buildingsLost[sinkPars.nation-1]+1;
						}
                        rtsm.numberOfUnitTypes[sinkPars.nation-1][sinkPars.rtsUnitId] = rtsm.numberOfUnitTypes[sinkPars.nation-1][sinkPars.rtsUnitId] - 1;
                        
                        
                        
						Destroy(sink.gameObject);
					}
				
				
				}
			}
			
// main coroutine wait statement and performance information collection from sink coroutine			
			twaiter = twaiter + 1.0f;
			yield return new WaitForSeconds(1.0f);
			
			timeEnd = Time.realtimeSinceStartup;
			
			timeloops[6] = timeEnd - timeBeg - twaiter;
			timeall[6] = timeEnd - timeBeg;
			
			performance[6] = (timeEnd-timeBeg-twaiter)*100.0f/(timeEnd-timeBeg);
		
			message6 = ("Sink: " + (sinks.Count).ToString() + "; " + (timeEnd-timeBeg-twaiter).ToString() + "; " + (performance[6]).ToString() + "% ");
		
			
		}
	}
	
	
	
	
	

	
	public IEnumerator AddBuffer()
	
// adding new units from buffer to BSystem : 
// units, which are wanted to be used on BSystem should be placed to unitsBuffer array first	
	
	{
		int setterCount = 0;
		while(true){
			
			int maxbuffer = unitsBuffer.Count;
			
			if(unitsBuffer.Count>0){
			
				for(int i =0; i<maxbuffer; i++){
					GameObject go = unitsBuffer[i];
					UnitPars goPars = go.GetComponent<UnitPars>();
				
				
					setterCount = setterCount+1;
					if(setterCount>1000){
						yield return new WaitForSeconds(0.2f);
						setterCount=0;
					}
				
		
					if(goPars.onManualControl == false){
						goPars.isReadyBeg = true;
					}
					goPars.isApproachable = true;
					goPars.isAttackable = true;
					goPars.statusBS = 1;
						
					goPars.isOnBS = true;
						
					unitss.Add(go);
					unitssUP.Add(goPars);
					unitssNMA.Add(go.GetComponent<NavMeshAgent>());
					if(goPars.animationToUse==1){
						unitssSL.Add(go.GetComponent<SpriteLoader>());
					}
					else{
						unitssSL.Add(null);
					}
				
			
				
			
			
			
				
				}
			
			// cleaning up buffer
				if(unitsBuffer.Count>0){
					for(int i =0; i<unitss.Count; i++){
						unitsBuffer.Remove(unitss[i]);
				
						setterCount = setterCount+1;
						if(setterCount>1000){
							yield return new WaitForSeconds(0.2f);
							setterCount=0;
						}
				
			
					}
				}
			}
					// overall performance calculation from Battle System
		
			timeloops[0] = timeloops[1] + timeloops[2] + timeloops[3] + timeloops[4] + timeloops[5] + timeloops[6];
			timeall[0] = timeall[1] + timeall[2] + timeall[3] + timeall[4] + timeall[5] + timeall[6];
			
		
			                 
			performance[0] = (performance[1] +
			                  performance[2] +
			                  performance[3] +
			                  performance[4] +
			                  performance[5] +
			                  performance[6])/6.0f;
			                  
			
		
		
			message = ("BSystem: " + (unitss.Count).ToString() + "; "
			                     + (timeloops[0]).ToString() + "; "
			                     + (timeall[0]).ToString() + "; "
			                     + (performance[0]).ToString() + "% ");
			
			
			
			yield return new WaitForSeconds(0.3f);
		}
	}
	
	
// ManualMover controls unit if it is selected and target is defined by player
	
	public IEnumerator ManualRestorer()
	{
	float r;
	
	float ax;
	float ay;
	float az;
	
	float tx;
	float ty;
	float tz;
	
		while(true){
			
			for(int i =0; i<unitss.Count; i++){
			
				GameObject go = unitss[i];
				UnitPars goPars = unitssUP[i];
				
				if(goPars.strictApproachMode == false){
				  if(goPars.isMovingMC){
				    
				    ax = go.transform.position.x;
					ay = go.transform.position.y;
					az = go.transform.position.z;
				
					tx = goPars.manualDestination.x;
					ty = goPars.manualDestination.y;
					tz = goPars.manualDestination.z;
				    
				    
				    r = Mathf.Sqrt((tx-ax)*(tx-ax)+(ty-ay)*(ty-ay)+(tz-az)*(tz-az));
				    
					if(r >= goPars.prevDist){
					
					    
					    goPars.failedDist = goPars.failedDist+1;
					    if(goPars.failedDist > goPars.critFailedDist){
					    	goPars.failedDist = 0;
					    	goPars.onManualControl = false;
					    	goPars.isMovingMC = false;
					    	ResetSearching(go);
					    }
						
					}
					goPars.prevDist = r;
				  }
				
			
				}
				
			}
			
			yield return new WaitForSeconds(0.5f);
		}
	}
	

	
	
	
// single action functions	
	
	public void AddUnit(GameObject go)
	{

			
			unitsBuffer.Add(go);

	}
	
	public void AddSelfHealer(GameObject go)
	{

			
			selfHealersBuffer.Add(go);

	}
	
	public void RemoveUnit(GameObject go)
	{
		
		UnitPars goPars = go.GetComponent<UnitPars>();
		goPars.statusBS = 2;
			
	}
	

	
	
	public void ResetSearching(GameObject go)
	{
	
	    
				UnitPars goPars = go.GetComponent<UnitPars>();
	
	
	    	
				goPars.isApproaching = false;
				goPars.isAttacking = false;
				
				if(goPars.target != null){
					goPars.target.GetComponent<UnitPars>().noAttackers = goPars.target.GetComponent<UnitPars>().noAttackers-1;
					goPars.target.GetComponent<UnitPars>().attackers.Remove(go);
					
					goPars.target = null;
					goPars.targetUP = null;
					goPars.targetNMA = null;
				}
			
			
		
				go.GetComponent<NavMeshAgent>().SetDestination(go.transform.position);
		
				if(goPars.changeMaterial){
		//			go.renderer.material.color = Color.yellow;				
				}
				if(go.GetComponent<SpriteLoader>() != null){
					go.GetComponent<SpriteLoader>().animName = "Idle";
				}
			
				goPars.isReadyBeg = true;
		
	
	}
	
		

	
	
	public void UnSetSearching(GameObject go)
	{
				UnitPars goPars = go.GetComponent<UnitPars>();
	
	 

	 
	    	
	    		goPars.isReadyBeg = false;
	    		goPars.isReadyEnd = false;
				goPars.isApproaching = false;
				goPars.isAttacking = false;
				
				if(goPars.target != null){
					goPars.target.GetComponent<UnitPars>().noAttackers = goPars.target.GetComponent<UnitPars>().noAttackers-1;
					goPars.target.GetComponent<UnitPars>().attackers.Remove(go);
					
					goPars.target = null;
					goPars.targetUP = null;
					goPars.targetNMA = null;
				}
				
				
		
	
		
				go.GetComponent<NavMeshAgent>().SetDestination(go.transform.position);
		
				if(goPars.changeMaterial){
			//		go.renderer.material.color = Color.grey;				
				}
				if(go.GetComponent<SpriteLoader>() != null){
					go.GetComponent<SpriteLoader>().animName = "Idle";
				}
			
		
	}
	

	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
// Heap sort used for sorting before passing to KDTree

    public static void HeapSort(Vector3[] input, int[] iorig)
   {
    	//Build-Max-Heap
    	int heapSize = input.Length;
    	for (int p = (heapSize - 1) / 2; p >= 0; p--)
        	MaxHeapify(input, iorig, heapSize, p);
 
    	for (int i = input.Length - 1; i > 0; i--)
    	{
        	//Swap
        	Vector3 temp = input[i];
        	input[i] = input[0];
        	input[0] = temp;
        	
        	int itemp = iorig[i];
        	iorig[i] = iorig[0];
        	iorig[0] = itemp;
 
        	heapSize--;
        	MaxHeapify(input, iorig, heapSize, 0);
    	}
    }


    private static void MaxHeapify(Vector3[] input, int[] iorig, int heapSize, int index)
    {
    	int left = (index + 1) * 2 - 1;
    	int right = (index + 1) * 2;
    	int largest = 0;
 
    	if (left < heapSize && input[left].x > input[index].x)
        	largest = left;
    	else
        	largest = index;
 
    	if (right < heapSize && input[right].x > input[largest].x)
        	largest = right;
 
    	if (largest != index)
    	{
        	Vector3 temp = input[index];
        	input[index] = input[largest];
        	input[largest] = temp;
        	
        	int itemp = iorig[index];
        	iorig[index] = iorig[largest];
        	iorig[largest] = itemp;
 
        	MaxHeapify(input, iorig, heapSize, largest);
    	}
    }	
	
	
	
	
	

	
	
}
