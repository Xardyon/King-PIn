﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ResourcesCollection : MonoBehaviour {
    
	private RTSMaster rtsm = null;
	[HideInInspector] public List<GameObject> workers = new List<GameObject>();
	[HideInInspector] public List<UnitPars> up_workers = new List<UnitPars>();
	[HideInInspector] public List<NavMeshAgent> nav_workers = new List<NavMeshAgent>();
	[HideInInspector] public List<SpriteLoader> sl_workers = new List<SpriteLoader>();
	[HideInInspector] public List<int> workers_resType = new List<int>();
	[HideInInspector] public List<int> workers_resAmount = new List<int>();
	
	
	[HideInInspector] public List<Vector3> treePositions = new List<Vector3>();
	[HideInInspector] public List<int> treeHealth = new List<int>();
	
	[HideInInspector] public List<GameObject> sawmills = new List<GameObject>();
	[HideInInspector] public List<UnitPars> up_sawmills = new List<UnitPars>();	
	[HideInInspector] public List<Vector3> sawmillsPos = new List<Vector3>();

	[HideInInspector] public List<GameObject> mines = new List<GameObject>();
	[HideInInspector] public List<UnitPars> up_mines = new List<UnitPars>();	
	[HideInInspector] public List<Vector3> minesPos = new List<Vector3>();
	[HideInInspector] public List<int> minesResource = new List<int>();
	[HideInInspector] public List<int> minesResourceType = new List<int>();	
	[HideInInspector] public List<int> minesResPoints = new List<int>();
	
	
	[HideInInspector] public List<GameObject> castle = new List<GameObject>();
	[HideInInspector] public List<UnitPars> up_castle = new List<UnitPars>();
	[HideInInspector] public List<Vector3> castlePos = new List<Vector3>();

	
	private Terrain ter = null;
	
	[HideInInspector] public KDTree kd_treePositions = null;
	private KDTree kd_sawmills = null;
	private KDTree kd_minesPos = null;
	private KDTree kd_castle = null;

    void Awake(){
    	rtsm = GameObject.Find("RTS Master").GetComponent<RTSMaster>();
    	rtsm.resourcesCollection = this;
 //   	StartCoroutine(AssignScripts());
    }    

	// Use this for initialization
	void Start () {
		
		ter = Terrain.activeTerrain;
		StartCoroutine(WorkerChopPhases());
		StartCoroutine(WorkerMinePhases());
		

	}
	
	// Update is called once per frame
	void Update () {
		
		if(Input.GetMouseButtonUp(1)){
		//     Vector3 hitLocation = Vector3.zero;
		     bool hitted = false;
		     
		     RaycastHit hit;
			 Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
             if (ter.collider.Raycast (ray, out hit, 10000f)) {
                 hitted = true;
             }
             if(hitted == true){
                if(treePositions.Count>0){
					kd_treePositions = KDTree.MakeFromPoints(treePositions.ToArray());
					int treeId = kd_treePositions.FindNearest(hit.point,1);
					if(
						(treePositions[treeId]-hit.point).sqrMagnitude
						<
						25f
					){
					    ChopTree(treeId);
					
					
					}
					else if(minesPos.Count>0){
						kd_minesPos = KDTree.MakeFromPoints(minesPos.ToArray());
						int mineId = kd_minesPos.FindNearest(hit.point,1);
						if(
							(minesPos[mineId]-hit.point).sqrMagnitude
							<
							45f
						){
							MineResource(mineId);
					
					
						}
						else{
							WalkTo(hit.point);
					
						}
				
					}
					
					
					
					else{
             	        WalkTo(hit.point);
					
					}
					
             	}
             	else if(minesPos.Count>0){
             		kd_minesPos = KDTree.MakeFromPoints(minesPos.ToArray());
             		int mineId = kd_minesPos.FindNearest(hit.point,1);
             		if(
						(minesPos[mineId]-hit.point).sqrMagnitude
						<
						1.3f*up_mines[mineId].rEnclosed*up_mines[mineId].rEnclosed
					//	45f
					){
					    MineResource(mineId);
					
					
					}
					else{
             	        WalkTo(hit.point);
					
					}
             	
             	}
             	
             	else{
             	    
             	    WalkTo(hit.point);
             	    
             	}
             	
             	
             }

		}
		
		
	}
    
    void WalkTo(Vector3 dest){
	   for(int i=0;i<workers.Count;i++){
			if(up_workers[i].isSelected==true){
				nav_workers[i].SetDestination(
					dest
				);
				up_workers[i].chopTreeId = -1;
				up_workers[i].chopTreePhase = -1;
				sl_workers[i].animName = "Walk";
				
				workers_resType[i] = -1;
			}
		
		}

    }
    
    void ChopTree(int treeId){
    	for(int i=0;i<workers.Count;i++){
			if(up_workers[i].isSelected==true){
				nav_workers[i].SetDestination(
					treePositions[treeId]
				);
				up_workers[i].chopTreeId = treeId;
				up_workers[i].chopTreePhase = 1;
				sl_workers[i].animName = "Walk";
				
				workers_resType[i] = 2;
			}
		}
    }
    
    void MineResource(int mineId){
    	for(int i=0;i<workers.Count;i++){
			if(up_workers[i].isSelected==true){
				nav_workers[i].SetDestination(
					minesPos[mineId]
				);
				up_workers[i].chopTreeId = mineId;
				up_workers[i].chopTreePhase = 11;
				sl_workers[i].animName = "Walk";
				
				workers_resType[i] = minesResourceType[mineId];
			}
		}
    }

    
    

    IEnumerator WorkerChopPhases(){
    	while(true){
    	    bool kd_sawmill_ready = false;
    	    bool kd_treePositions_ready = false;
    		
    		for(int i=0; i<workers.Count; i++){
    			if(up_workers[i].chopTreePhase == 1){
    				if(
    					(treePositions[up_workers[i].chopTreeId] - workers[i].transform.position).sqrMagnitude
    					<
    					16f
    				){
    					nav_workers[i].Stop();
    					sl_workers[i].animName = "Attack";
    					up_workers[i].chopTreePhase = 2;
    					up_workers[i].maxChopHits = 50;
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 2){
    				up_workers[i].chopHits = up_workers[i].chopHits + 1;
    				if(up_workers[i].chopHits > up_workers[i].maxChopHits){
    				
    					int chTreeId = up_workers[i].chopTreeId;
    					workers_resAmount[i] = 50;
    					if(treeHealth[chTreeId]-50 < 0){
    						workers_resAmount[i] = treeHealth[chTreeId];
    					}
    					treeHealth[chTreeId] = treeHealth[chTreeId]-50;
    					
    					
						if(treeHealth[chTreeId]<0){	
							rtsm.createForest.treeList.RemoveAt(3*chTreeId);
							rtsm.createForest.treeList.RemoveAt(3*chTreeId);
							rtsm.createForest.treeList.RemoveAt(3*chTreeId);
					        
					        rtsm.createForest.treePos2D.RemoveAt(chTreeId);
					    //    Vector3 fallenTree = treePositions[chTreeId];
					        
					 		rtsm.createForest.RefreshTrees();
					 		
					 		treePositions.RemoveAt(chTreeId);
					 		treeHealth.RemoveAt(chTreeId);
					 		
					 		if(treePositions.Count>0){
								kd_treePositions = KDTree.MakeFromPoints(treePositions.ToArray());
							
								for(int j=0; j<workers.Count; j++){
									if(up_workers[j].chopTreeId == chTreeId){
									
										int neighTreeId = kd_treePositions.FindNearest(workers[j].transform.position,1);
										up_workers[j].chopTreeId = neighTreeId;
										if(j != i){
											if(up_workers[j].chopTreePhase == 1){
												nav_workers[j].SetDestination(
													treePositions[neighTreeId]
												);
											}
											else if(up_workers[j].chopTreePhase == 2){
												nav_workers[j].SetDestination(
													treePositions[neighTreeId]
												);
												up_workers[j].chopTreePhase = 1;
												sl_workers[j].animName = "Walk";
											}
										}
									
									}
									else if(up_workers[j].chopTreeId > chTreeId){
										up_workers[j].chopTreeId = up_workers[j].chopTreeId-1;
									}
								}
					 		}
					 		else{
					 			for(int j=0; j<workers.Count; j++){
					 			    if(j != i){
										if(up_workers[j].chopTreePhase == 1){
											nav_workers[j].Stop();
											sl_workers[j].animName = "Idle";
											up_workers[j].chopTreePhase = 5;
										}
										else if(up_workers[j].chopTreePhase == 2){
											sl_workers[j].animName = "Idle";
											up_workers[j].chopTreePhase = 5;
										}
										
					 				}
					 				
					 			}
					 		}
					 		
						}
    					
    					if(sawmills.Count > 0){
    					    if(kd_sawmill_ready == false){
    					    	kd_sawmills = KDTree.MakeFromPoints(sawmillsPos.ToArray());
    					    	kd_sawmill_ready = true;
    					    }
    					    
    					    int neighId = kd_sawmills.FindNearest(workers[i].transform.position,1);
    					    
    					    nav_workers[i].SetDestination(
             	        	    sawmillsPos[
             	        	    	neighId
             	        	    ]
             	        	);
    					    up_workers[i].targetSawmillId = neighId;
    						sl_workers[i].animName = "WalkLog";
    						up_workers[i].chopTreePhase = 3;
    						up_workers[i].chopHits = 0;
    						
    						
    						
    					}
    					else{
    						sl_workers[i].animName = "IdleLog";
    						up_workers[i].chopTreePhase = 4;
    						up_workers[i].chopHits = 0;
    					}
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 3){
    			    if(sawmills.Count>0){
						float rEncl = up_sawmills[up_workers[i].targetSawmillId].rEnclosed;
						if(
							(sawmillsPos[up_workers[i].targetSawmillId] - workers[i].transform.position).sqrMagnitude
							<
							(0.3f*rEncl*rEncl)
						){
							int nationId = up_sawmills[up_workers[i].targetSawmillId].nation-1;
							rtsm.economy.lumber[nationId] = rtsm.economy.lumber[nationId] + workers_resAmount[i];
							workers_resAmount[i] = 0;
							if(nationId == 0){
								rtsm.economy.textLumber.text = rtsm.economy.lumber[0].ToString();
							}
						
							if(treePositions.Count>0){
								nav_workers[i].SetDestination(
										treePositions[up_workers[i].chopTreeId]
									);
								up_workers[i].chopTreePhase = 1;
								sl_workers[i].animName = "Walk";
							}
							else{
								nav_workers[i].Stop();
								up_workers[i].chopTreePhase = 5;
								sl_workers[i].animName = "Idle";
							}
						
						}
    				}
    				else{
    					sl_workers[i].animName = "IdleLog";
    					up_workers[i].chopTreePhase = 4;
    					up_workers[i].chopHits = 0;
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 4){
    				if(sawmills.Count > 0){
    					if(kd_sawmill_ready == false){
							kd_sawmills = KDTree.MakeFromPoints(sawmillsPos.ToArray());
							kd_sawmill_ready = true;
						}
						
						int neighId = kd_sawmills.FindNearest(workers[i].transform.position,1);
						
						nav_workers[i].SetDestination(
							sawmillsPos[
								neighId
							]
						);
						up_workers[i].targetSawmillId = neighId;
						sl_workers[i].animName = "WalkLog";
						up_workers[i].chopTreePhase = 3;
						up_workers[i].chopHits = 0;
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 5){
    				if(treePositions.Count>0){
    				    if(kd_treePositions_ready == false){
    						kd_treePositions = KDTree.MakeFromPoints(treePositions.ToArray());
    						kd_treePositions_ready = true;
    					}
    					int neighId = kd_treePositions.FindNearest(workers[i].transform.position,1);
    					nav_workers[i].SetDestination(
             	        	    treePositions[
             	        	    	neighId
             	        	    ]
             	        	);
             	        up_workers[i].chopTreeId = neighId;
             	        up_workers[i].chopTreePhase = 1;
             	        sl_workers[i].animName = "Walk";
    					
    				}
    			}

    			
    		}
    		yield return new WaitForSeconds(0.1f);
    	}
    
    
    }
    
    
    
    
    
    
    IEnumerator WorkerMinePhases(){
    	while(true){
    	    bool kd_castle_ready = false;
    		bool kd_mines_ready = false;
    		
    		for(int i=0; i<workers.Count; i++){
    			if(up_workers[i].chopTreePhase == 11){
    				if(
    					(minesPos[up_workers[i].chopTreeId] - workers[i].transform.position).sqrMagnitude
    					<
    					0.8f*up_mines[up_workers[i].chopTreeId].rEnclosed*up_mines[up_workers[i].chopTreeId].rEnclosed
    				){
    					nav_workers[i].Stop();
    					sl_workers[i].animName = "IdlePouch";
    					up_workers[i].chopTreePhase = 12;
    					up_workers[i].maxChopHits = 2;
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 12){
    				up_workers[i].chopHits = up_workers[i].chopHits + 1;
    				if(up_workers[i].chopHits > up_workers[i].maxChopHits){
    				
    					int chTreeId = up_workers[i].chopTreeId;
    					
    					workers_resAmount[i] = 100;
    					if(minesResource[chTreeId]-100 < 0){
    						workers_resAmount[i] = minesResource[chTreeId];
    					}
    					minesResource[chTreeId] = minesResource[chTreeId]-100;
    					up_mines[chTreeId].remainingResources = minesResource[chTreeId];
    					if(up_mines[chTreeId].remainingResources < 0){
    						up_mines[chTreeId].remainingResources = 0;
    					}
    					if(up_mines[chTreeId].isSelected == true){
    						rtsm.cameraOperator.mineLabel.text = up_mines[chTreeId].remainingResources.ToString();
    					}
    					
    					int resPointId = minesResPoints[chTreeId];
    					rtsm.resourcePoint.resAmount[resPointId] = rtsm.resourcePoint.resAmount[resPointId] - 100;
						if(minesResource[chTreeId]<0){	
					 		
					 		up_mines[chTreeId].selfHealFactor = -(int)(0.1f*up_mines[chTreeId].maxHealth)-1;
					 		up_mines[chTreeId].health = up_mines[chTreeId].health +2*up_mines[chTreeId].selfHealFactor;
					 		
					 		mines.RemoveAt(chTreeId);
					 		up_mines.RemoveAt(chTreeId);
					 		minesPos.RemoveAt(chTreeId);
					 		minesResource.RemoveAt(chTreeId);
					 		minesResourceType.RemoveAt(chTreeId);
					 		minesResPoints.RemoveAt(chTreeId);
					 		
					 	// removal of resource point from map	
					 		if(rtsm.resourcePoint.resAmount[resPointId]<0){
					 			for(int jj=0;jj<minesResPoints.Count;jj++){
					 				if(minesResPoints[chTreeId]>resPointId){
					 					minesResPoints[chTreeId] = minesResPoints[chTreeId]-1;
					 				}
					 			}
					 			
					 			rtsm.resourcePoint.UnsetResourcePoint(resPointId);
					 			
					 			
					 			
					 			
					 			
					 			
					 		}
					 		
					 		
					 		if(minesPos.Count>0){
								kd_minesPos = KDTree.MakeFromPoints(minesPos.ToArray());
							
								for(int j=0; j<workers.Count; j++){
									if(up_workers[j].chopTreeId == chTreeId){
									
										int neighTreeId = kd_minesPos.FindNearest(workers[j].transform.position,1);
										up_workers[j].chopTreeId = neighTreeId;
										if(j != i){
											if(up_workers[j].chopTreePhase == 11){
												nav_workers[j].SetDestination(
													minesPos[neighTreeId]
												);
											}
											else if(up_workers[j].chopTreePhase == 12){
												nav_workers[j].SetDestination(
													minesPos[neighTreeId]
												);
												up_workers[j].chopTreePhase = 11;
												sl_workers[j].animName = "Walk";
											}
										}
									
									}
									else if(up_workers[j].chopTreeId > chTreeId){
										up_workers[j].chopTreeId = up_workers[j].chopTreeId-1;
									}
								}
					 		}
					 		else{
					 			for(int j=0; j<workers.Count; j++){
					 			    if(j != i){
										if(up_workers[j].chopTreePhase == 11){
											nav_workers[j].Stop();
											sl_workers[j].animName = "Idle";
											up_workers[j].chopTreePhase = 15;
										}
										else if(up_workers[j].chopTreePhase == 12){
											sl_workers[j].animName = "Idle";
											up_workers[j].chopTreePhase = 15;
										}
										
					 				}
					 				
					 			}
					 		}
					 		
						}
    					
    					if(castle.Count > 0){
    					    if(kd_castle_ready == false){
    					    	kd_castle = KDTree.MakeFromPoints(castlePos.ToArray());
    					    	kd_castle_ready = true;
    					    }
    					    
    					    int neighId = kd_castle.FindNearest(workers[i].transform.position,1);
    					    
    					    nav_workers[i].SetDestination(
             	        	    castlePos[
             	        	    	neighId
             	        	    ]
             	        	);
    					    up_workers[i].targetSawmillId = neighId;
    						sl_workers[i].animName = "WalkPouch";
    						up_workers[i].chopTreePhase = 13;
    						up_workers[i].chopHits = 0;
    						
    						
    						
    					}
    					else{
    						sl_workers[i].animName = "IdlePouch";
    						up_workers[i].chopTreePhase = 14;
    						up_workers[i].chopHits = 0;
    					}
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 13){
    			    float rEncl = up_castle[up_workers[i].targetSawmillId].rEnclosed;
    				if(
    					(castlePos[up_workers[i].targetSawmillId] - workers[i].transform.position).sqrMagnitude
    					<
    					(1.0f*rEncl*rEncl)
    				){
    				    int nationId = up_castle[up_workers[i].targetSawmillId].nation-1;
    				    
    				    if(workers_resType[i] == 0){
							rtsm.economy.iron[nationId] = rtsm.economy.iron[nationId] + workers_resAmount[i];
							workers_resAmount[i] = 0;
							if(nationId == 0){
								rtsm.economy.textIron.text = rtsm.economy.iron[0].ToString();
							}
    				    }
    				    if(workers_resType[i] == 1){
							rtsm.economy.gold[nationId] = rtsm.economy.gold[nationId] + workers_resAmount[i];
							workers_resAmount[i] = 0;
							if(nationId == 0){
								rtsm.economy.textGold.text = rtsm.economy.gold[0].ToString();
							}
    				    }
    				    
    				    
    				    
    				    if(minesPos.Count>0){
							nav_workers[i].SetDestination(
									minesPos[up_workers[i].chopTreeId]
								);
							up_workers[i].chopTreePhase = 11;
							sl_workers[i].animName = "Walk";
    					}
    					else{
    					    nav_workers[i].Stop();
    						up_workers[i].chopTreePhase = 15;
							sl_workers[i].animName = "Idle";
    					}
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 14){
    				if(castle.Count > 0){
    					if(kd_castle_ready == false){
							kd_castle = KDTree.MakeFromPoints(castlePos.ToArray());
							kd_castle_ready = true;
						}
						
						int neighId = kd_castle.FindNearest(workers[i].transform.position,1);
						
						nav_workers[i].SetDestination(
							castlePos[
								neighId
							]
						);
						up_workers[i].targetSawmillId = neighId;
						sl_workers[i].animName = "WalkPouch";
						up_workers[i].chopTreePhase = 13;
						up_workers[i].chopHits = 0;
    				}
    			}
    			else if(up_workers[i].chopTreePhase == 15){
    				if(minesPos.Count>0){
    				    if(kd_mines_ready == false){
    						kd_minesPos = KDTree.MakeFromPoints(minesPos.ToArray());
    						kd_mines_ready = true;
    					}
    					int neighId = kd_minesPos.FindNearest(workers[i].transform.position,1);
    					nav_workers[i].SetDestination(
             	        	    minesPos[
             	        	    	neighId
             	        	    ]
             	        	);
             	        up_workers[i].chopTreeId = neighId;
             	        up_workers[i].chopTreePhase = 11;
             	        sl_workers[i].animName = "Walk";
    					
    				}
    			}
    			
    		}
    		yield return new WaitForSeconds(0.1f);
    	}
    
    
    }
    
    
    
    
    
    
    


	
	IEnumerator AssignScripts(){
		bool cont = true;
		while(cont == true){
			
			if(rtsm.diplomacy != null){
			    workers.Clear();
				int NN = rtsm.diplomacy.numberNations;
		
				for(int i=0;i<NN;i++){
		//			workers.Add(new List<GameObject>());
				}
				cont = false;
			}
			
			yield return new WaitForSeconds(0.02f);
		}
	}
}
