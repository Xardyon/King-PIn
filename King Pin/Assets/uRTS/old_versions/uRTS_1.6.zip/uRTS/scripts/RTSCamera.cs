﻿using UnityEngine;
using System.Collections;

public class RTSCamera : MonoBehaviour {
	
	
	public float zoomSpeed = 1.0f;
	public float moveSpeed = 1.0f;
	public float rotationSpeed = 1.0f;
	

	private float ScrollEdge = 0.01f;

    public float minZoomDist = 20.0f;
    public float maxZoomDist = 300.0f;

    private float camHeight;



	


	

	
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		camHeight = transform.position.y - Terrain.activeTerrain.SampleHeight(transform.position);

		if ( Input.GetKey("mouse 2") )

    	{

        

    	}
    	
    	else

    	{

        	if ( Input.GetKey("d") || Input.mousePosition.x >= Screen.width * (1 - ScrollEdge) )

        	{
        	
				transform.Translate(new Vector3(
					Time.deltaTime * moveSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
        			0.0f,
        			Time.deltaTime * -moveSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
        		Space.World);
        
        	}

        	else if ( Input.GetKey("a") || Input.mousePosition.x <= Screen.width * ScrollEdge )

        	{
				transform.Translate(new Vector3(
					Time.deltaTime * -moveSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
					0.0f,
					Time.deltaTime * moveSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World);
       
       	    }

        

        	if ( Input.GetKey("w") || Input.mousePosition.y >= Screen.height * (1 - ScrollEdge) )

        	{

            	transform.Translate(new Vector3(
            		Time.deltaTime * moveSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
            		0.0f,
            		Time.deltaTime * moveSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
            	Space.World);
         
        	}

        	else if ( Input.GetKey("s") || Input.mousePosition.y <= Screen.height * ScrollEdge )

        	{
				transform.Translate(new Vector3(
					Time.deltaTime * -moveSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
					0.0f,
					Time.deltaTime * -moveSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World);
 
        	}

    	}
    	
    	Vector3 fwd = transform.TransformDirection (Vector3.forward);
    	
    	if (Input.GetAxis("Mouse ScrollWheel")> 0){
		
			transform.Translate(new Vector3(
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
	
		
			if(Camera.main.transform.rotation.eulerAngles.x <= 180.0f){
			if (Physics.Raycast (transform.position, fwd, minZoomDist)) {
				transform.Translate(new Vector3(
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
			}
			}
			if(Camera.main.transform.rotation.eulerAngles.x >= 180.0f){
			if (!(Physics.Raycast (transform.position, -fwd, maxZoomDist))) {
				transform.Translate(new Vector3(
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
		  
			}
	    }


		}
		
		if (Input.GetAxis("Mouse ScrollWheel")< 0){
	
		
			transform.Translate(new Vector3(
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)), 
				Space.World
			
			);
		

        
        	if(Camera.main.transform.rotation.eulerAngles.x >= 180.0f){
			if (Physics.Raycast (transform.position, -fwd, minZoomDist)) {
	    
				transform.Translate(new Vector3(
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
			}
			}	
		
			if(Camera.main.transform.rotation.eulerAngles.x <= 180.0f){
			if (!(Physics.Raycast (transform.position, fwd, maxZoomDist))) {
		
				transform.Translate(new Vector3(
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f),
				2*Time.deltaTime * -zoomSpeed *camHeight *Mathf.Sin((Camera.main.transform.rotation.eulerAngles.x)*Mathf.PI/180.0f)*Mathf.Pow(2.0f,0.5f),
				2*Time.deltaTime * zoomSpeed *camHeight *Mathf.Cos((Camera.main.transform.rotation.eulerAngles.y)*Mathf.PI/180.0f)),
				Space.World
			);
			}
		}
		


		}
		
		// ROTATION

    	if (Input.GetMouseButton(1)){
			float h = rotationSpeed * Input.GetAxis ("Mouse X");
			float v = rotationSpeed * Input.GetAxis ("Mouse Y");
			transform.Rotate (0, h, 0, Space.World);

			transform.Rotate (v, 0, 0);

			if((Camera.main.transform.rotation.eulerAngles.x >= 90) &&(Camera.main.transform.rotation.eulerAngles.x <= 180)){
	
				transform.Rotate (-v, 0, 0);
			}
			if(((Camera.main.transform.rotation.eulerAngles.x >= 180)&&(Camera.main.transform.rotation.eulerAngles.x <= 270))||(Camera.main.transform.rotation.eulerAngles.x < 0) ){
	
				transform.Rotate (-v, 0, 0);
			}


    		if((Camera.main.transform.rotation.eulerAngles.z >= 160)&&(Camera.main.transform.rotation.eulerAngles.z <= 200)){
    			transform.Rotate (-v, 0, 0);
    		}
		}
		
		
	}
}
