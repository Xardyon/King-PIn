﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Scores : MonoBehaviour {
	
	[HideInInspector] public List<int> nUnits;
	[HideInInspector] public List<int> nBuildings;
	
	[HideInInspector] public List<int> unitsLost;
	[HideInInspector] public List<int> buildingsLost;
	
	[HideInInspector] public List<float> damageMade;
	[HideInInspector] public List<float> damageObtained;
	
	private List<string> message = new List<string>();
	private string messageTitle = " ";
	
	private int messageId = 1;
	
	private int nNations = 0;
	
	private BattleSystem bs;
	private Diplomacy dip;
	
	void Awake () {
	    bs = GameObject.Find("Terrain").GetComponent<BattleSystem>();
	    dip = GameObject.Find("Terrain").GetComponent<Diplomacy>();
	    
	    nNations = dip.numberNations;
	    
		for(int i=0; i<nNations; i++){
		    
			nUnits.Add(0);
			nBuildings.Add(0);
			
			unitsLost.Add(0);
			buildingsLost.Add(0);
			
			damageMade.Add(0f);
			damageObtained.Add(0f);
			
			message.Add(" ");
		}
	}
	
	// Use this for initialization
	void Start () {
		StartCoroutine(MessageUpdate());
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.T))
		{
            if(messageId==0){
            	messageId=1;
            	bs.displayMessage = false;
            }
            else if(messageId==1){
            	messageId=2;
            }
            else if(messageId==2){
            	messageId=0;
            	bs.displayMessage = true;
            }
		}
		
		// + "; " + countrf[1] + "; " + (curTime - t1 - twaiter).ToString() + "; " + (performance[1]).ToString() + "% ");
	}
	
	
	public IEnumerator MessageUpdate(){
		while(true){
			messageTitle = (
								"Nation              "+
								"n buildings              "+
								"n units              "+
								
								"lost buildings              "+
								"lost units              "+
								
								"damage made              "+
								"damage got              "
							);
			for(int i=0; i<nNations; i++){
				message[i] = (
				              	(i+1).ToString() + "                            "  +
				              	(nBuildings[i]).ToString() + "                            " +
				               	nUnits[i] + "                            " +
				               	
				               	
				               	buildingsLost[i] + "                            " +
				               	unitsLost[i] + "                            " +
				               	
				               	damageMade[i] + "                            " +
								damageObtained[i]
				               	
				             );
			}
			
			
			yield return new WaitForSeconds(0.5f);
		}
	
	}
	
	void OnGUI (){
	
	// Display performance
		if ( messageId == 1 )
    	{
    	    GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * 0.05f, 900f, 20f), messageTitle);
    		for(int i=0; i<nNations; i++){
    			GUI.Label(new Rect(Screen.width * 0.05f, Screen.height * (0.05f*(i+1)+0.1f), 900f, 20f), message[i]);
    		}
    	}
	}
	
	
}
