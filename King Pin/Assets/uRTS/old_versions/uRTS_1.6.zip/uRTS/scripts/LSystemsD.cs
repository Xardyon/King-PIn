﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LSystemsD : MonoBehaviour {
    
    public int numOfPlants = 5;
    private Vector3 plantLocation = new Vector3(0f,0f,0f);
    
    private GameObject treeGo = null;
    
    public int numIterations = 35;
    
    private List<int> numberSegments = new List<int>();
    
    public float segmentBottomRadius = .55f;
	public float segmentTopRadius = .15f;
	
	private float segBottomRadius = 0f;
	private float segTopRadius = 0f;
	
	public float segLength = 1.0f;
    
    private List<float> curBotRadius = new List<float>();
    private List<float> curTopRadius = new List<float>();
    
    private List<Vector3> gvertices = new List<Vector3>();
    private List<Vector3> gnormales = new List<Vector3>();
    private List<Vector2> guvs = new List<Vector2>();
    private List<int> gtriangles = new List<int>();
    
    
    private List<Vector3> lvertices = new List<Vector3>();
    private List<Vector3> lnormales = new List<Vector3>();
    private List<Vector2> luvs = new List<Vector2>();
    private List<int> ltriangles = new List<int>();
    private int ltriOffset = 0;
    
    private List<Vector3> lverticesF = new List<Vector3>();
    private List<Vector3> lnormalesF = new List<Vector3>();
    private List<Vector2> luvsF = new List<Vector2>();
    private List<int> ltrianglesF = new List<int>();
    private int ltriOffsetF = 0;
    
    
    private List<int> topVertices = new List<int>();
    
    private List<int> minVertex = new List<int>();
    private List<int> maxVertex = new List<int>();
    
    private List<int> minTriangle = new List<int>();
    private List<int> maxTriangle = new List<int>();
    
    private int currentSegmentId = 0;
    private int currentSegmentOffset = 0;
    
    private int currentBranchId = 0;
    
    private int verticesOffset = 0;
    private int trianglesOffset = 0;
    
    
    public float startingRot = 3.0f;
    public float endingRot = 3.0f;
    
    private float iniAngle = 0.0f;
    
    
    private List<Vector3> segmentPos = new List<Vector3>();
    
    
    private List<Vector3> segPosBeg = new List<Vector3>();
    private List<Vector3> segPosEnd = new List<Vector3>();
    private List<Vector3> segRotBeg = new List<Vector3>();
    private List<Vector3> segRotEnd = new List<Vector3>();
    
    private List<float> segBotRad = new List<float>();
    private List<float> segTopRad = new List<float>();
    
    private List<int> leafSegment = new List<int>();    
    
    public int nLeafSegments = 3;
    public float leafSize = 3f;
    public int nLeafs = 3;
    
    
    
    private int nBranchesToAdd = 0;
    
    private int nbSides = 18;
    
    private List<int> inhSegId = new List<int>();
    private List<int> inhBranchId = new List<int>();
    
    private List<int> segmentOrder = new List<int>();
    private List<int> branchingOrder = new List<int>();
    
    private List<Vector3> iniPos3 = new List<Vector3>();
    
    private int numberOfBranches;
    private List<Vector3> branchPosB = new List<Vector3>();
    private List<Vector3> branchPosE = new List<Vector3>();
    
    
    private Vector3 iniPos;
    private Vector3 iniPos2;
    
    private Vector3 rotVect;
    
    public Texture2D texture;
    public Texture2D textureLeaf;
    private Texture2D flipTextureLeaf;
    
    
    void Start () {
        for(int i=0;i<numOfPlants;i++){
            CleanArrays();
    		AddPlant ();
    	}
    }
    
    void CleanArrays(){
    	numberSegments.Clear();
    	curBotRadius.Clear();
    	curTopRadius.Clear();
    	
    	gvertices.Clear();
    	gnormales.Clear();
    	guvs.Clear();
    	gtriangles.Clear();
    	
    	topVertices.Clear();
    	minVertex.Clear();
    	maxVertex.Clear();
    	
    	minTriangle.Clear();
    	maxTriangle.Clear();
    	
    	segmentPos.Clear();
    	
    	inhSegId.Clear();
    	inhBranchId.Clear();
    	segmentOrder.Clear();
    	branchingOrder.Clear();
    	
    	iniPos3.Clear();
    	
    	
    	
    	currentBranchId = 0;
    	
    	currentSegmentId = 0;
    	currentSegmentOffset = 0;
    	verticesOffset = 0;
    	trianglesOffset = 0;
    	
    	
    }
    
	void AddPlant () {
	//    plantLocation = new Vector3(Random.Range(300f,1200f),0f,Random.Range(150f,1200f));
	    plantLocation = new Vector3(0f,0f,0f);
	    
	    flipTextureLeaf = FlipTexture(textureLeaf);
	    
		CalculateSkeleton();
		DrawSkeleton();
		
		SetupLeaves();
		
		
		CreateMesh();
		CreateLMesh();
		CreateLFMesh();
		

	}
	
	void Update () {
	
	}
	
	
	Texture2D FlipTexture(Texture2D original){
		Texture2D flipped = new Texture2D(original.width,original.height);
		
		int xN = original.width;
		int yN = original.height;
		
	    
	    for(int i=0;i<xN;i++){
	    	for(int j=0;j<yN;j++){
	    		flipped.SetPixel(xN-i-1, j, original.GetPixel(i,j));
	    	}
	    }
		flipped.Apply();
		
		return flipped;
	}
	
	
	
	
	void CalculateSkeleton(){
	    
	    segBottomRadius = segmentBottomRadius;
	    segTopRadius = segmentTopRadius;
	    
	    numberSegments.Add(numIterations);
	    
        segBottomRadius = segBottomRadius*numIterations/10f;
		numberOfBranches = 0;
		
		
		
		curBotRadius.Add(0f);
		curTopRadius.Add(0f);
		
		inhSegId.Add(currentSegmentId);
		inhBranchId.Add(0);
		
		branchingOrder.Add(0);
		segmentOrder.Add(0);
		
		iniPos = new Vector3(0f,segLength,0f);
		iniPos2 = new Vector3(0f,segLength,0f);
		
		iniPos3.Add(iniPos);

		rotVect = new Vector3(0f,0f,1f);

	//	branchPosB.Add(segmentPos[currentBranchId]);
	//	branchPosE.Add(segmentPos[currentBranchId]);
		segmentPos.Add(new Vector3(0f,0f,0f));
		
		
		

    
		
		curBotRadius[currentBranchId] = segBottomRadius;
		curTopRadius[currentBranchId] = segBottomRadius-(segBottomRadius-segTopRadius)/numberSegments[currentBranchId];
		
		float branchPosibility = 1.0f;
		int branchIsLocked = 0;
		

		
		AddBranch();
		
		Random.seed = 43;
		
		while(nBranchesToAdd>0){
			currentBranchId++;
			
			iniAngle = startingRot;

	    
	        Vector3 randVect = new Vector3(Random.Range(-1,1f),Random.Range(-1,1f),Random.Range(-1,1f));
			rotVect = Vector3.Cross
	    	(
	    		iniPos3[currentBranchId].normalized,
	    		randVect.normalized
	    		
	    													
	    	).normalized;
	    	
	    	

			segBottomRadius = curTopRadius[currentBranchId];
   //         Vector3 prevPos = segmentPos[currentBranchId];
            
            
		    
		    segPosBeg.Add(segmentPos[currentBranchId]);
		    segPosEnd.Add(segmentPos[currentBranchId]);
		    segRotBeg.Add(segmentPos[currentBranchId]-segmentPos[currentBranchId]);
		    segRotEnd.Add(segmentPos[currentBranchId]-segmentPos[currentBranchId]);
		    
		    segBotRad.Add(curTopRadius[currentBranchId]);
		    segTopRad.Add(curTopRadius[currentBranchId]);
		    
		    leafSegment.Add(0);
		    
		    
		    
		    
		    
			currentSegmentId++;
			
			iniPos2 = iniPos3[currentBranchId];
			

		
		    branchPosibility = 1.0f;
			for(int j=1;j<numberSegments[currentBranchId];j++){
		        if(branchIsLocked==0){
		        
		        
		            segmentOrder[currentBranchId]=segmentOrder[currentBranchId]+1;
		            
	//	            prevPos = segmentPos[currentBranchId];
		            Vector3 iniPos22;
		            
		            if(currentBranchId == 1){
		            	if(j==1){
							iniAngle = 0f; 
							iniPos2=RotAround(iniAngle, iniPos2, rotVect); 
							iniPos22 = 0.00001f*iniPos2;
						
						}
						else{
							iniAngle = 0f;
							iniPos2=RotAround(iniAngle, iniPos2, rotVect);
							iniPos22=RotAround(iniAngle, iniPos2, rotVect);
						
						}
		            }
		            else{
					
						if(j==1){
							iniAngle = startingRot; 
							iniPos2=RotAround(iniAngle, iniPos2, rotVect); 
							iniPos22 = 0.00001f*iniPos2;
						
						}
						else{
							iniAngle = endingRot;
							iniPos2=RotAround(iniAngle, iniPos2, rotVect);
							iniPos22=RotAround(iniAngle, iniPos2, rotVect);
						
						}
	    	        }
	    	        
	    	        
			        
					
					currentSegmentOffset = 0;
			        
			        
					curTopRadius[currentBranchId] = segBottomRadius-(segBottomRadius-segTopRadius)*(j+1)/numberSegments[currentBranchId];
		
		

		            
		            
		
					branchPosibility = branchPosibility-0.03f;
					if((j>2)&&(Random.Range(0f,0.58f*numIterations*(numberSegments[currentBranchId]-j))/(numberSegments[currentBranchId]-j)>branchPosibility*(numberSegments[currentBranchId]-j))){
						AddBranch();
						branchPosibility = 1.0f;
					
					//	AddBranch();
					//	branchPosibility = 1.0f;
					
						branchIsLocked = 0;
					}
			
					
					
					segPosBeg.Add(segmentPos[currentBranchId]);
		    		segPosEnd.Add(segmentPos[currentBranchId]+iniPos22);
		    		segRotBeg.Add(segRotEnd[currentSegmentId-1]);
		    		segRotEnd.Add(0.5f*(segPosBeg[currentSegmentId]-segPosEnd[currentSegmentId-1])+
		    		              0.5f*((segPosEnd[currentSegmentId]+iniPos22)-segPosEnd[currentSegmentId]));
		    		

		    		segBotRad.Add(segTopRad[currentSegmentId-1]);
		    		segTopRad.Add(curTopRadius[currentBranchId]);
		    		
		    		if(numberSegments[currentBranchId]-j < nLeafSegments){
		    			leafSegment.Add(numberSegments[currentBranchId]-j);
		    		}
		    		else{
		    			leafSegment.Add(0);
		    		}
		    		
		    		
		    		branchPosB[currentBranchId-1] = segPosBeg[currentSegmentId];
					branchPosE[currentBranchId-1] = segPosEnd[currentSegmentId];
		    		segmentPos[currentBranchId] = segmentPos[currentBranchId]+iniPos22;
					


		    		
					currentSegmentId++;
		
				}

			
			}
			branchIsLocked = 0;
			nBranchesToAdd--;
		}
		

		

		
		
		
		
	}
	
	void DrawSkeleton(){
		for(int i=0;i<segPosBeg.Count;i++){
			DrawCone(segPosEnd[i],segPosBeg[i],segRotBeg[i],segRotEnd[i],segBotRad[i],segTopRad[i]);
		}
	}
	
	
	
	
	
	void SetupLeaves(){

		for(int j=0;j<segPosBeg.Count;j++){
		    if(leafSegment[j]>0){
				for(int i=0;i<nLeafs;i++){
			
				
					float randomizeLeafRot = Random.Range(0f,90f);
				//	float leafVertRot = Random.Range(-30f,70f);
					float leafVertRot = 30f+40*i/nLeafs;
				
					
					DrawLeafDecal(segPosBeg[j]+(1f*i/nLeafs)*(segPosEnd[j]-segPosBeg[j]), (segPosEnd[j]-segPosBeg[j]),randomizeLeafRot+45f,leafVertRot,leafSize);
					DrawLeafDecal(segPosBeg[j]+(1f*i/nLeafs)*(segPosEnd[j]-segPosBeg[j]), (segPosEnd[j]-segPosBeg[j]),randomizeLeafRot+135f,leafVertRot,leafSize);
					DrawLeafDecal(segPosBeg[j]+(1f*i/nLeafs)*(segPosEnd[j]-segPosBeg[j]), (segPosEnd[j]-segPosBeg[j]),randomizeLeafRot-45f,leafVertRot,leafSize);
					DrawLeafDecal(segPosBeg[j]+(1f*i/nLeafs)*(segPosEnd[j]-segPosBeg[j]), (segPosEnd[j]-segPosBeg[j]),randomizeLeafRot-135f,leafVertRot,leafSize);
					
				}
			}
		}
		
		for(int i=0;i<nLeafs;i++){
	//		LeafDecal(new Vector3(3f,-2f*i,0f), new Vector3(0f,1f,0f),0f,0f,leafSize);
	//        LeafDecal2(new Vector3(3f,2f*i,0f), new Vector3(0f,1f,0f),0f,0f,leafSize);
	        
		}
		
		
		
		
	}
	
	
	void DrawLeafDecal(Vector3 posOffset, Vector3 rotDir, float rotAroundBranch, float rotVBranch, float leafSize){
		LeafDecal2(posOffset, rotDir, rotAroundBranch, rotVBranch, leafSize, 0);
		LeafDecal2(posOffset, rotDir, rotAroundBranch, rotVBranch, leafSize, 1);
	}
	
	
	
	void LeafDecal(Vector3 posOffset, Vector3 rotDir, float rotAroundBranch, float rotVBranch, float leafSize){
		

 
		float length = leafSize;
		float width = 0.00001f;
		float height = leafSize;
 
		#region Vertices
		
		
		Vector3 offsetFromBranch = new Vector3( length * 0.5f*Mathf.Cos(rotAroundBranch*Mathf.PI/180f),	0f, height * 0.5f*Mathf.Sin(rotAroundBranch*Mathf.PI/180f) );
		
		
		
		float rotAngle = Vector3.Angle(new Vector3(0f,1f,0f),rotDir);
		//10f;
		Vector3 rotDir2 = Vector3.Cross(new Vector3(0f,1f,0f),rotDir);
		
		
		Vector3 p0 = new Vector3( -length * .5f,	-width * .5f, height * .5f );
		Vector3 p1 = new Vector3( length * .5f, 	-width * .5f, height * .5f );
		Vector3 p2 = new Vector3( length * .5f, 	-width * .5f, -height * .5f );
		Vector3 p3 = new Vector3( -length * .5f,	-width * .5f, -height * .5f );	
 
		Vector3 p4 = new Vector3( -length * .5f,	width * .5f,  height * .5f );
		Vector3 p5 = new Vector3( length * .5f, 	width * .5f,  height * .5f );
		Vector3 p6 = new Vector3( length * .5f, 	width * .5f,  -height * .5f );
		Vector3 p7 = new Vector3( -length * .5f,	width * .5f,  -height * .5f );
		
		
		
		
 
		Vector3[] vertices = new Vector3[]
		{
			// Bottom
			p0, p1, p2, p3,
 
 
			// Top
			p4, p5, p6, p7
		};
		
		for(int i=0;i<vertices.Length;i++){
		    vertices[i] = RotAround(rotVBranch,vertices[i],new Vector3(1f,0f,0f));
		    vertices[i] = RotAround(rotAroundBranch-90f,vertices[i],new Vector3(0f,1f,0f));
			vertices[i] = RotAround(-rotAngle,vertices[i]+offsetFromBranch,rotDir2)+posOffset;
		}
		
		#endregion
 
		#region Normales
		Vector3 up 	= Vector3.up;
		Vector3 down 	= Vector3.down;
		
	//	Vector3 up 	= rotDir;
	//	Vector3 down 	= -rotDir;
		
 
		Vector3[] normales = new Vector3[]
		{
			// Bottom
			down, down, down, down,
 
 
			// Top
			up, up, up, up
		};
//		print(normales[5]);
		#endregion	
 
		#region UVs
		Vector2 _00 = new Vector2( 0f, 0f );
		Vector2 _10 = new Vector2( 1f, 0f );
		Vector2 _01 = new Vector2( 0f, 1f );
		Vector2 _11 = new Vector2( 1f, 1f );
 
		Vector2[] uvs = new Vector2[]
		{
			// Bottom
			_11, _01, _00, _10,
			
 
 
			// Top
			_11, _01, _00, _10,
		//	_11, _00, _01, _10,
			//_10, _00, _01, _11,
		};
		#endregion
 
		#region Triangles
		int[] triangles = new int[]
		{
			// Bottom
			3, 1, 0,
			3, 2, 1,			
 
			// Top
			7, 5, 4,
			7, 6, 5,
			
	
			
		//	3 + 4 * 1, 1 + 4 * 1, 0 + 4 * 1,
		//	3 + 4 * 1, 2 + 4 * 1, 1 + 4 * 1,
 
 
		};
		#endregion
 
 		for(int i=0;i<vertices.Length;i++){
 			lvertices.Add(vertices[i]);
 			lnormales.Add(normales[i]);
 			luvs.Add(uvs[i]);
 		}
  		for(int i=0;i<triangles.Length;i++){
  			ltriangles.Add(triangles[i]+ltriOffset);
  		}
  		
  		ltriOffset = ltriOffset+8;		
  		
 

		
		
	}
	
	
	void LeafDecal2(Vector3 posOffset, Vector3 rotDir, float rotAroundBranch, float rotVBranch, float leafSize, int flipMode){
		

		float length = 3f;
		float width = 3f;
		int resX = 2; // 2 minimum
		int resZ = 2;
 
		#region Vertices		
		Vector3[] vertices = new Vector3[ resX * resZ ];
		for(int z = 0; z < resZ; z++)
		{
			// [ -length / 2, length / 2 ]
			float zPos = ((float)z / (resZ - 1) - .5f) * length;
			for(int x = 0; x < resX; x++)
			{
				// [ -width / 2, width / 2 ]
				float xPos = ((float)x / (resX - 1) - .5f) * width;
				
				
				
				
				
				
			//	vertices[ x + z * resX ] = RotAround(180f,new Vector3( xPos, 0f, zPos ),new Vector3(0f,0f,1f))+posOffset;
				vertices[ x + z * resX ] = new Vector3( xPos, 0f, zPos );
			}
		}
		
		Vector3 offsetFromBranch = new Vector3( length * 0.5f*Mathf.Cos(rotAroundBranch*Mathf.PI/180f),	0f, width * 0.5f*Mathf.Sin(rotAroundBranch*Mathf.PI/180f) );
		
		
		
		float rotAngle = Vector3.Angle(new Vector3(0f,1f,0f),rotDir);
		//10f;
		Vector3 rotDir2 = Vector3.Cross(new Vector3(0f,1f,0f),rotDir);
		
		
		
		for(int i=0;i<vertices.Length;i++){
			if(flipMode==1){
				vertices[i] = RotAround(180f,vertices[i],new Vector3(0f,0f,1f));
			}
		
		    vertices[i] = RotAround(rotVBranch,vertices[i],new Vector3(1f,0f,0f));
		    vertices[i] = RotAround(rotAroundBranch-90f,vertices[i],new Vector3(0f,1f,0f));
			vertices[i] = RotAround(-rotAngle,vertices[i]+offsetFromBranch,rotDir2)+posOffset;
		}
		
		
		#endregion
 
		#region Normales
		Vector3[] normales = new Vector3[ vertices.Length ];
		for( int n = 0; n < normales.Length; n++ )
			normales[n] = Vector3.up;
		#endregion
 
		#region UVs		
		Vector2[] uvs = new Vector2[ vertices.Length ];
		for(int v = 0; v < resZ; v++)
		{
			for(int u = 0; u < resX; u++)
			{
				uvs[ u + v * resX ] = new Vector2( (float)u / (resX - 1), (float)v / (resZ - 1) );
			}
		}
		#endregion
 
		#region Triangles
		int nbFaces = (resX - 1) * (resZ - 1);
		int[] triangles = new int[ nbFaces * 6 ];
		int t = 0;
		for(int face = 0; face < nbFaces; face++ )
		{
			// Retrieve lower left corner from face ind
			int i = face % (resX - 1) + (face / (resZ - 1) * resX);
 
			triangles[t++] = i + resX;
			triangles[t++] = i + 1;
			triangles[t++] = i;
 
			triangles[t++] = i + resX;	
			triangles[t++] = i + resX + 1;
			triangles[t++] = i + 1; 
		}
		#endregion
		
		if(flipMode==0){
			for(int i=0;i<vertices.Length;i++){
				lvertices.Add(vertices[i]);
				lnormales.Add(normales[i]);
				luvs.Add(uvs[i]);
			}
			for(int i=0;i<triangles.Length;i++){
				ltriangles.Add(triangles[i]+ltriOffset);
			}
		
			ltriOffset = ltriOffset+4;		
        }
        else{
        	for(int i=0;i<vertices.Length;i++){
				lverticesF.Add(vertices[i]);
				lnormalesF.Add(normales[i]);
				luvsF.Add(uvs[i]);
			}
			for(int i=0;i<triangles.Length;i++){
				ltrianglesF.Add(triangles[i]+ltriOffsetF);
			}
		
			ltriOffsetF = ltriOffsetF+4;		

        }
		
	}
	
	
	
	
	Vector3 GetNormal(Vector3 a, Vector3 b, Vector3 c) {
        Vector3 side1 = b - a;
        Vector3 side2 = c - a;
        return Vector3.Cross(side1, side2).normalized;
    }
	
	
	
	Vector3 RotVector(float rotAngle, Vector3 original, Vector3 direction){
	    
	    
	    
	    Vector3 cross1 = Vector3.Cross(original,direction);
	    Vector3 cross2 = Vector3.Cross(original,cross1);
	    
	    Vector3 rotatedVector = Quaternion.AngleAxis( rotAngle, cross2)*original;
	    
	
		return rotatedVector;
	
	}
	
	Vector3 RotAround(float rotAngle, Vector3 original, Vector3 direction){
	    
	    
	    
	    Vector3 cross1 = Vector3.Cross(original,direction);
	    
	    Vector3 pr = Vector3.Project(original,direction);
	    Vector3 pr2 = original - pr;
	    
	    
	    Vector3 cross2 = Vector3.Cross(pr2,cross1);
	    
	    Vector3 rotatedVector = (Quaternion.AngleAxis( rotAngle, cross2)*pr2)+pr;
	    
	
		return rotatedVector;
	
	}
	
	Vector3 FaceDirection(Vector3 original, Vector3 direction){
		
		
		return (RotAround(Vector3.Angle(original,direction), original, Vector3.Cross(original,direction)));
	
	}
	
	
	
	void AddBranch(){
	    inhSegId.Add(currentSegmentId);
	    inhBranchId.Add(currentBranchId);
	    
		curBotRadius.Add(curBotRadius[currentBranchId]);
		curTopRadius.Add(curTopRadius[currentBranchId]);
		
		branchPosB.Add(segmentPos[currentBranchId]);
		branchPosE.Add(segmentPos[currentBranchId]);
		segmentPos.Add(segmentPos[currentBranchId]);	
		
		
		nBranchesToAdd++;
		
		branchingOrder.Add(branchingOrder[currentBranchId]+1);
		segmentOrder.Add(0);
		
		if(currentSegmentId==0){
			iniPos3.Add(iniPos2);
		}
		else{
			iniPos3.Add(segPosEnd[currentSegmentId-1]-segPosBeg[currentSegmentId-1]);
		}
		
		numberSegments.Add(numberSegments[currentBranchId]-segmentOrder[currentBranchId]);
		numberOfBranches++;
		
	}
	

	void InheritVertices(){
	
		for(int i=minVertex[currentSegmentId-1];i<maxVertex[currentSegmentId-1];i++){
			if(topVertices[i]==1){
				gvertices[i]=gvertices[i-currentSegmentOffset-1];
			}
		}
	
	}
	
	void InheritVertices2(){
		for(int i=minVertex[currentSegmentId-1];i<maxVertex[currentSegmentId-1];i++){
			if(topVertices[i]==1){
				gvertices[i]=gvertices[i-(minVertex[currentSegmentId-1]-minVertex[inhSegId[currentBranchId]])];
			}
		}
	}
	
	void DrawCone(Vector3 posOffset, Vector3 prevPos, Vector3 rotBeg, Vector3 rotEnd, float bottomRadius, float topRadius){
	

 
	int useBottomCap = 0;
	int useTopCap = 0; 
 
	float height = (posOffset-prevPos).magnitude;
	
	
//	float bottomRadius = curBotRadius[currentBranchId];
//	float topRadius = curTopRadius[currentBranchId];


 
	int nbVerticesCap = nbSides + 1;
	
//	 = iniPos2;
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////	
/////////////////////////////////////////////     Vertices     //////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
//	#region Vertices
 


	int NN = nbVerticesCap + nbVerticesCap + nbSides * 2 + 2;
	
	
	int[] vUsed = new int[NN];
	int[] isTopVertice = new int[NN];
	
	int numUsed = 0;
	
	for(int ii=0;ii<NN;ii++){
		vUsed[ii] = 0;
		isTopVertice[ii] = 0;
	}

 
	// bottom + top + sides
	Vector3[] vertices = new Vector3[nbVerticesCap + nbVerticesCap + nbSides * 2 + 2];
	int vert = 0;
	float _2pi = Mathf.PI * 2f;
 
 
	// Bottom cap
	if(useBottomCap == 1){
		vert = 0;
		vUsed[vert] = 1;
		vertices[vert++] = new Vector3(0f, 0f, 0f);
		numUsed++;
		while( vert <= nbSides )
		{
			float rad = (float)vert / nbSides * _2pi;
			vertices[vert] = new Vector3(Mathf.Cos(rad) * bottomRadius, 0f, Mathf.Sin(rad) * bottomRadius);
			vUsed[vert] = 1;
			
			numUsed++;
			vert++;
		}
	}
 
	// Top cap
	if(useTopCap == 1){
		vert = nbSides+1;
		vUsed[vert] = 1;
		vertices[vert++] = new Vector3(0f, height, 0f);
		numUsed++;
		while (vert <= nbSides * 2 + 1)
		{
			float rad = (float)(vert - nbSides - 1)  / nbSides * _2pi;
			vertices[vert] = new Vector3(Mathf.Cos(rad) * topRadius, height, Mathf.Sin(rad) * topRadius);
			vUsed[vert] = 1;
			numUsed++;
			vert++;
		}
	}


 
	vert = nbSides * 2 + 2; 
	// Sides
	int v = 0;
	while (vert <= vertices.Length - 4 )
	{
		float rad = (float)v / nbSides * _2pi;
		
		
		
		
		Vector3 norm = new Vector3(0f,height,0f);
		Vector3 seed = new Vector3(Mathf.Cos(rad) * topRadius, 0, Mathf.Sin(rad) * topRadius);
		
		Vector3 rotDir = -Vector3.Cross(norm, rotEnd);
		float rotA = Vector3.Angle(norm, rotEnd);
		
		vertices[vert] = RotAround(rotA,seed,rotDir);
		vertices[vert] = vertices[vert]+height*rotEnd.normalized;
		
		
		
		
		
		
		norm = new Vector3(0f,height,0f);
		seed = new Vector3(Mathf.Cos(rad) * bottomRadius, 0, Mathf.Sin(rad) * bottomRadius);
		
		rotDir = -Vector3.Cross(norm, rotBeg);
		rotA = Vector3.Angle(norm, rotBeg);
		
		vertices[vert+1] = RotAround(rotA,seed,rotDir);
	//	vertices[vert+1] = vertices[vert+1]+rotBeg;
		
		
		
		
	//	vertices[vert + 1] = new Vector3(Mathf.Cos(rad) * bottomRadius, 0, Mathf.Sin(rad) * bottomRadius);
		
		isTopVertice[vert + 1] = 1;
		
		vUsed[vert] = 1;
		vUsed[vert+1] = 1;
		
		vert+=2;
		numUsed+=2;
		v++;
	}
	vertices[vert] = vertices[ nbSides * 2 + 2 ];
	vertices[vert + 1] = vertices[nbSides * 2 + 3 ];
	
	isTopVertice[vert + 1] = 1;
	
	vUsed[vert] = 1;
	vUsed[vert+1] = 1;
	
    Vector3[] verticesA = new Vector3[numUsed+2];
    


    int jj = 0;
	for(int ii=0;ii<NN;ii++){
	    if(vUsed[ii] == 1){
			
			if(isTopVertice[ii]==1){
				topVertices.Add(1);
			}
			else{
				topVertices.Add(0);
			}
			
			jj++;
		}
	}
	jj = 0;
	for(int ii=0;ii<NN;ii++){
	    if(vUsed[ii] == 1){
			verticesA[jj] = vertices[ii];
			gvertices.Add(vertices[ii]+posOffset-(posOffset-prevPos));
		//	print(vertices[ii]+posOffset-(posOffset-prevPos));
			jj++;
		}
	}
	


//	#endregion
 
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////    Normales    /////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////// 
 
 
 
//	#region Normales
 
	// bottom + top + sides

	Vector3[] normalesA = new Vector3[verticesA.Length];
	Vector3[] normales = new Vector3[vertices.Length];
	
	
    numUsed=0;
	vert = 0;
    
    for(int ii=0;ii<NN;ii++){
		vUsed[ii] = 0;
	}
 
	// Bottom cap
	if(useBottomCap == 1){
		vert = 0;
		while( vert  <= nbSides )
		{   
			normales[vert] = Vector3.down;
			vUsed[vert] = 1;
			numUsed++;
			vert++;
		}
	}
 
	// Top cap
	if(useTopCap == 1){
		vert = nbSides+1;
		while( vert <= nbSides * 2 + 1 )
		{
		    
			normales[vert] = Vector3.up;
			vUsed[vert] = 1;
			numUsed++;
			vert++;
		}
	}

 
  
	// Sides

	vert = nbSides * 2 + 2;
	v = 0;
	while (vert <= vertices.Length - 4 )
	{			
		float rad = (float)v / nbSides * _2pi;
		float cos = Mathf.Cos(rad);
		float sin = Mathf.Sin(rad);
 
		normales[vert] = new Vector3(cos, 0f, sin);
		normales[vert+1] = normales[vert];
		
		vUsed[vert] = 1;
		vUsed[vert+1] = 1;
 
        numUsed+=2;
		vert+=2;
		v++;
	}
	normales[vert] = normales[ nbSides * 2 + 2 ];
	normales[vert + 1] = normales[nbSides * 2 + 3 ];
	vUsed[vert] = 1;
	vUsed[vert+1] = 1;
    

    
    jj=0;
	for(int ii=0;ii<NN;ii++){
	    if(vUsed[ii] == 1){
			normalesA[jj] = normales[ii];
			gnormales.Add(normales[ii]);
			jj++;
		}
	}

//	#endregion
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////     UVs      //////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////// 
 
 
//	#region UVs
	Vector2[] uvsA = new Vector2[verticesA.Length];
	Vector2[] uvs = new Vector2[vertices.Length];
 
    int[] uUsed = new int[vertices.Length];
    
    for(int ii=0;ii<NN;ii++){
		uUsed[ii] = 0;
	}
 
	// Bottom cap
	numUsed=0;
	
	int u = 0;
	if(useBottomCap == 1){
		u = 0;
        
        uUsed[u] = 1;
		uvs[u++] = new Vector2(0.5f, 0.5f);
		numUsed++;
	
		while (u <= nbSides)
		{
			float rad = (float)u / nbSides * _2pi;
			uvs[u] = new Vector2(Mathf.Cos(rad) * .5f + .5f, Mathf.Sin(rad) * .5f + .5f);
			uUsed[u] = 1;
			numUsed++;
			u++;
		}
	} 
	// Top cap
	if(useTopCap == 1){
		u = nbSides+1;
	    
	    uUsed[u] = 1;
		uvs[u++] = new Vector2(0.5f, 0.5f);
		numUsed++;
		while (u <= nbSides * 2 + 1)
		{
			float rad = (float)u / nbSides * _2pi;
			uvs[u] = new Vector2(Mathf.Cos(rad) * .5f + .5f, Mathf.Sin(rad) * .5f + .5f);
			uUsed[u] = 1;
			numUsed++;
			u++;
		}
	}

 
	u = nbSides * 2 + 2;  
 
	// Sides
	int u_sides = 0;
	while (u <= uvs.Length - 4 )
	{
		float t = (float)u_sides / nbSides;
		uvs[u] = new Vector3(t, 1f);
		uvs[u + 1] = new Vector3(t, 0f);
		uUsed[u] = 1;
		uUsed[u+1] = 1;
		numUsed+=2;
		u += 2;
		u_sides++;
	}
	uvs[u] = new Vector2(1f, 1f);
	uvs[u + 1] = new Vector2(1f, 0f);
	uUsed[u] = 1;
	uUsed[u+1] = 1;
    
    
    jj=0;
	for(int ii=0;ii<NN;ii++){
	    if(uUsed[ii] == 1){
			uvsA[jj] = uvs[ii];
			guvs.Add(uvs[ii]);
			jj++;
		}
	}

//	#endregion 
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////     Triangles      ///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////// 
 
 
//	#region Triangles
	int nbTriangles = nbSides + nbSides + nbSides*2;
	int[] triangles = new int[nbTriangles * 3 + 3];

	int NT = nbTriangles * 3 + 3;
	

	int[] tUsed = new int[NT];
	
	for(int ii=0;ii<NT;ii++){
		tUsed[ii] = 0;
	}
 

    numUsed=0;
	// Bottom cap
	int tri = 0;
	int i = 0;
	
	int missTris = 0;

	
	if(useBottomCap == 1){
		while (tri < nbSides - 1)
		{
			if(useBottomCap == 1){
				triangles[ i ] = 0;
				triangles[ i+1 ] = tri - missTris + 1;
				triangles[ i+2 ] = tri - missTris + 2;
			
				tUsed[i] = 1;
				tUsed[i+1] = 1;
				tUsed[i+2] = 1;
			}
			numUsed+=3;
			tri++;
			i += 3;
		}


	
			triangles[i] = 0;
			triangles[i + 1] = tri - missTris + 1;
			triangles[i + 2] = 1;
		
			tUsed[i] = 1;
			tUsed[i+1] = 1;
			tUsed[i+2] = 1;
		
			numUsed+=3;
	
	
		tri++;
		i += 3;
	}
    
    
    if(useBottomCap == 1){
        if(useTopCap == 1){
    		missTris = 0;
    	}
    	if(useTopCap == 0){
    		missTris = 0;
    	}
    }
    else if(useBottomCap == 0){
        if(useTopCap == 1){
    		missTris = nbSides+1;
    	}
    	else if(useTopCap == 0){
    		missTris = nbSides+1;
    	}
    }
    
    
	tri = nbSides;
	i = 3*tri;
 
	// Top cap
	if(useTopCap == 1){
		while (tri < nbSides*2)
		{
	
			triangles[ i ] = tri - missTris + 2;
			triangles[i + 1] = tri - missTris + 1;
			triangles[i + 2] = nbVerticesCap - missTris;
			
			tUsed[i] = 1;
			tUsed[i+1] = 1;
			tUsed[i+2] = 1;
	        
	        numUsed+=3;
	        
			tri++;
			i += 3;
			
		}

		triangles[i] = nbVerticesCap - missTris + 1;
		triangles[i + 1] = tri - missTris + 1;
		triangles[i + 2] = nbVerticesCap - missTris;	
		
		tUsed[i] = 1;
		tUsed[i+1] = 1;
		tUsed[i+2] = 1;
	    
	    numUsed+=3;
		tri++;
		i += 3;
		tri++;
	}


	
    if(useBottomCap == 1){
        if(useTopCap == 1){
    		missTris = 0;
    	}
    	if(useTopCap == 0){
    		missTris = nbSides+1;
    	}
    }
    else if(useBottomCap == 0){
        if(useTopCap == 1){
    		missTris = nbSides+1;
    	}
    	else if(useTopCap == 0){
    		missTris = nbSides*2+2;
    	}
    }
    
	tri = nbSides*2+2;
	i = 3*tri-3;

    
	// Sides
	while( tri <= nbTriangles )
	{
		triangles[ i ] = tri - missTris + 2;
		triangles[ i+1 ] = tri - missTris + 1;
		triangles[ i+2 ] = tri - missTris + 0;
		
		tUsed[i] = 1;
		tUsed[i+1] = 1;
		tUsed[i+2] = 1;
		
		numUsed+=3;
		tri++;
		i += 3;
 
		triangles[ i ] = tri - missTris + 1;
		triangles[ i+1 ] = tri - missTris + 2;
		triangles[ i+2 ] = tri - missTris + 0;
		
		tUsed[i] = 1;
		tUsed[i+1] = 1;
		tUsed[i+2] = 1;
		
		numUsed+=3;
		tri++;
		i += 3;
	}
	
    int[] trianglesA = new int[numUsed];
    
    jj = 0;
	for(int ii=0;ii<NT;ii++){
	    if(tUsed[ii] == 1){
			trianglesA[jj] = triangles[ii];
			gtriangles.Add(triangles[ii]+verticesOffset);
			jj++;
		}
	}
	
	
	
	
	jj = 0;
	minVertex.Add(verticesOffset);
	for(int ii=0;ii<NN;ii++){
	    
	    if(vUsed[ii] == 1){
			
			jj++;
		}
	}
	maxVertex.Add(verticesOffset+jj);
	verticesOffset = verticesOffset+jj;
	currentSegmentOffset = jj;
	

	
	minTriangle.Add(trianglesOffset);
	jj = 0;
	for(int ii=0;ii<NT;ii++){
	    if(tUsed[ii] == 1){
			
			jj++;
		}
	}
//	print(jj);
	maxTriangle.Add(trianglesOffset+jj);
	trianglesOffset = trianglesOffset+jj;
	
	



//	#endregion

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////


 


	
	}
	
	void CreateMesh(){
	        treeGo = new GameObject("Tree");
	        treeGo.transform.position = plantLocation;
	        
	        if(gvertices.Count>60000){
            int tempCount = 60000;
        	while((tempCount % (nbSides * 2+2))!=0){
        		tempCount--;
        	}
        	
        	
        	List<List<Vector3>> ggvertices = new List<List<Vector3>>();
			List<List<Vector3>> ggnormales = new List<List<Vector3>>();
			List<List<Vector2>> gguvs = new List<List<Vector2>>();
			List<List<int>> ggtriangles = new List<List<int>>();
			
			int maxj = gvertices.Count/tempCount+1;
			for(int j=0;j<maxj;j++){
				ggvertices.Add(new List<Vector3>());
				ggnormales.Add(new List<Vector3>());
				gguvs.Add(new List<Vector2>());
				ggtriangles.Add(new List<int>());
			
			    int mini = j*tempCount;
			    int maxi = (j+1)*tempCount;
			    
			    if(j==maxj-1){
			    	maxi = gvertices.Count;
			    }
			
				for(int i=mini; i<maxi; i++){
					ggvertices[j].Add(gvertices[i]);
					ggnormales[j].Add(gnormales[i]);
					gguvs[j].Add(guvs[i]);
				}
			    
			    int minTri = j*(3*tempCount - tempCount/(nbSides * 2+2)*nbSides/3);
				int maxTri = (j+1)*(3*tempCount - tempCount/(nbSides * 2+2)*nbSides/3);
				
				if(j==maxj-1){
			    	maxTri = gtriangles.Count;
			    }
			
				for(int i=minTri; i<maxTri; i++){
					ggtriangles[j].Add(gtriangles[i]-mini);
				
				}
			    
			    
			    
				GameObject plant = new GameObject("Plant "+"part "+j);
				plant.transform.parent = treeGo.transform;
				
				MeshFilter filter = plant.AddComponent<MeshFilter>();
				Mesh mesh = filter.mesh;
				mesh.Clear();
			
			
				mesh.vertices = ggvertices[j].ToArray();
				mesh.normals = ggnormales[j].ToArray();
				mesh.uv = gguvs[j].ToArray();
				mesh.triangles = ggtriangles[j].ToArray();
 
				mesh.RecalculateBounds();
				mesh.Optimize();
			
				MeshRenderer renderer = plant.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
				renderer.material.shader = Shader.Find ("Diffuse");
				Texture2D tex = new Texture2D(1, 1);
				tex.SetPixel(0, 0, Color.green);
				tex.Apply();
				renderer.material.mainTexture = texture;
				renderer.material.mainTextureOffset = new Vector2(Random.Range(0f,1024f), Random.Range(0f,1024f));
				renderer.material.mainTextureScale = new Vector2(3, 1);
				renderer.material.color = Color.white;
				
				
				
				
			
			}
        }
		
		else{
			GameObject plant = new GameObject("Plant");
			plant.transform.parent = treeGo.transform;
			MeshFilter filter = plant.AddComponent<MeshFilter>();
			Mesh mesh = filter.mesh;
			mesh.Clear();
			
			mesh.vertices = gvertices.ToArray();
			mesh.normals = gnormales.ToArray();
			mesh.uv = guvs.ToArray();
			mesh.triangles = gtriangles.ToArray();
 
			mesh.RecalculateBounds();
			mesh.Optimize();
			
			MeshRenderer renderer = plant.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
			renderer.material.shader = Shader.Find ("Diffuse");
			Texture2D tex = new Texture2D(1, 1);
			tex.SetPixel(0, 0, Color.green);
			tex.Apply();
			renderer.material.mainTexture = texture;
			renderer.material.mainTextureOffset = new Vector2(Random.Range(0f,1024f), Random.Range(0f,1024f));
			renderer.material.mainTextureScale = new Vector2(3, 1);
			renderer.material.color = Color.white;
			
		//	plant.transform.position = plantLocation;
			
		}
	}
	
	
	void CreateLMesh(){
	
	        if(lvertices.Count>60000){
            int tempCount = 60000;
        	while((tempCount % (8))!=0){
        		tempCount--;
        	}
        	
        	
        	List<List<Vector3>> ggvertices = new List<List<Vector3>>();
			List<List<Vector3>> ggnormales = new List<List<Vector3>>();
			List<List<Vector2>> gguvs = new List<List<Vector2>>();
			List<List<int>> ggtriangles = new List<List<int>>();
			
			int maxj = lvertices.Count/tempCount+1;
			for(int j=0;j<maxj;j++){
				ggvertices.Add(new List<Vector3>());
				ggnormales.Add(new List<Vector3>());
				gguvs.Add(new List<Vector2>());
				ggtriangles.Add(new List<int>());
			
			    int mini = j*tempCount;
			    int maxi = (j+1)*tempCount;
			    
			    if(j==maxj-1){
			    	maxi = lvertices.Count;
			    }

				for(int i=mini; i<maxi; i++){
					ggvertices[j].Add(lvertices[i]);
					ggnormales[j].Add(lnormales[i]);
					gguvs[j].Add(luvs[i]);
				}
			    
			    
			    int minTri = j*tempCount*3/2;
			    if(j==0){
			    	minTri=0;
			    }
				int maxTri = (j+1)*tempCount*3/2;
				
				if(j==maxj-1){
			    	maxTri = ltriangles.Count;
			    }
			
				for(int i=minTri; i<maxTri; i++){
					ggtriangles[j].Add(ltriangles[i]-mini);
				
				}
			    
			    
			    
				GameObject plant = new GameObject("Leaf "+"part "+j);
				plant.transform.parent = treeGo.transform;
				MeshFilter filter = plant.AddComponent<MeshFilter>();
				Mesh mesh = filter.mesh;
				mesh.Clear();
			
			
				mesh.vertices = ggvertices[j].ToArray();
				mesh.normals = ggnormales[j].ToArray();
				mesh.uv = gguvs[j].ToArray();
				mesh.triangles = ggtriangles[j].ToArray();
 
				mesh.RecalculateBounds();
				mesh.Optimize();
			
				
				MeshRenderer renderer = plant.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
			//	renderer.material.shader = Shader.Find ("Particles/Alpha Blended");
				renderer.material.shader = Shader.Find ("Unlit/Transparent Cutout");
				Texture2D tex = new Texture2D(1, 1);
				tex.SetPixel(0, 0, Color.clear);
				tex.Apply();
				renderer.material.mainTexture = textureLeaf;
				
		//		plant.transform.position = plantLocation;
				
				
			
			}
        }
		
		else{
			GameObject plant = new GameObject("Leaf");
			plant.transform.parent = treeGo.transform;
			MeshFilter filter = plant.AddComponent<MeshFilter>();
			Mesh mesh = filter.mesh;
			mesh.Clear();
			
			
			mesh.vertices = lvertices.ToArray();
			mesh.normals = lnormales.ToArray();
			mesh.uv = luvs.ToArray();
			mesh.triangles = ltriangles.ToArray();
 
			mesh.RecalculateBounds();
			mesh.Optimize();
			

			
			
			MeshRenderer renderer = plant.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
	//		renderer.material.shader = Shader.Find ("Particles/Alpha Blended");
			renderer.material.shader = Shader.Find ("Unlit/Transparent Cutout");
			Texture2D tex = new Texture2D(1, 1);
			tex.SetPixel(0, 0, Color.clear);
			tex.Apply();
		//	renderer.material.mainTexture = textureLeaf;
			renderer.material.mainTexture = textureLeaf;
			
			
			
//			plant.transform.position = plantLocation;
			
		}
	}
	
	void CreateLFMesh(){
	
	        if(lvertices.Count>60000){
            int tempCount = 60000;
        	while((tempCount % (8))!=0){
        		tempCount--;
        	}
        	
        	
        	List<List<Vector3>> ggvertices = new List<List<Vector3>>();
			List<List<Vector3>> ggnormales = new List<List<Vector3>>();
			List<List<Vector2>> gguvs = new List<List<Vector2>>();
			List<List<int>> ggtriangles = new List<List<int>>();
			
			int maxj = lvertices.Count/tempCount+1;
			for(int j=0;j<maxj;j++){
				ggvertices.Add(new List<Vector3>());
				ggnormales.Add(new List<Vector3>());
				gguvs.Add(new List<Vector2>());
				ggtriangles.Add(new List<int>());
			
			    int mini = j*tempCount;
			    int maxi = (j+1)*tempCount;
			    
			    if(j==maxj-1){
			    	maxi = lverticesF.Count;
			    }

				for(int i=mini; i<maxi; i++){
					ggvertices[j].Add(lverticesF[i]);
					ggnormales[j].Add(lnormalesF[i]);
					gguvs[j].Add(luvsF[i]);
				}
			    
			    
			    int minTri = j*tempCount*3/2;
			    if(j==0){
			    	minTri=0;
			    }
				int maxTri = (j+1)*tempCount*3/2;
				
				if(j==maxj-1){
			    	maxTri = ltriangles.Count;
			    }
			
				for(int i=minTri; i<maxTri; i++){
					ggtriangles[j].Add(ltrianglesF[i]-mini);
				
				}
			    
			    
			    
				GameObject plant = new GameObject("LeafBack "+"part "+j);
				plant.transform.parent = treeGo.transform;
				MeshFilter filter = plant.AddComponent<MeshFilter>();
				Mesh mesh = filter.mesh;
				mesh.Clear();
			
			
				mesh.vertices = ggvertices[j].ToArray();
				mesh.normals = ggnormales[j].ToArray();
				mesh.uv = gguvs[j].ToArray();
				mesh.triangles = ggtriangles[j].ToArray();
 
				mesh.RecalculateBounds();
				mesh.Optimize();
			
				
				MeshRenderer renderer = plant.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
			//	renderer.material.shader = Shader.Find ("Particles/Alpha Blended");
				renderer.material.shader = Shader.Find ("Unlit/Transparent Cutout");
				Texture2D tex = new Texture2D(1, 1);
				tex.SetPixel(0, 0, Color.clear);
				tex.Apply();
				renderer.material.mainTexture = flipTextureLeaf;
				
		//		plant.transform.position = plantLocation;
				
				
			
			}
        }
		
		else{
			GameObject plant = new GameObject("LeafBack");
			plant.transform.parent = treeGo.transform;
			MeshFilter filter = plant.AddComponent<MeshFilter>();
			Mesh mesh = filter.mesh;
			mesh.Clear();
			
			
			mesh.vertices = lverticesF.ToArray();
			mesh.normals = lnormalesF.ToArray();
			mesh.uv = luvsF.ToArray();
			mesh.triangles = ltrianglesF.ToArray();
 
			mesh.RecalculateBounds();
			mesh.Optimize();
			

			
			
			MeshRenderer renderer = plant.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
	//		renderer.material.shader = Shader.Find ("Particles/Alpha Blended");
			renderer.material.shader = Shader.Find ("Unlit/Transparent Cutout");
			Texture2D tex = new Texture2D(1, 1);
			tex.SetPixel(0, 0, Color.clear);
			tex.Apply();
		//	renderer.material.mainTexture = textureLeaf;
			renderer.material.mainTexture = flipTextureLeaf;
			
			
			
//			plant.transform.position = plantLocation;
			
		}
	}
	
	
}
